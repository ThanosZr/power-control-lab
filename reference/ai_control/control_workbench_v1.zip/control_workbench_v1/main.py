"""Launch the Adaptive Inverse Control Workbench GUI:  python main.py"""
from __future__ import annotations

import bootstrap  # noqa: F401  (registers plants, schemes, scenarios, exporters)
from gui.app import ControlWorkbenchGUI


def main() -> None:
    app = ControlWorkbenchGUI()
    app.protocol("WM_DELETE_WINDOW", app.on_close)
    app.mainloop()


if __name__ == "__main__":
    main()
