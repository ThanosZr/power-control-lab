"""Live block diagram of the indirect inverse-control loop — the picture on the
slide, drawn with the current signal values flowing through it.

    r --->(Σ)--- e --->[ ANN1  F⁻¹ ]--- u --->[ System F ]---+---> y
           ^-                                |               |
           |                                 v               |
           |                          [ ANN2 emulator ]--ŷ-->(Σ)--- e*
           |                                                  (trains ANN2)
           +--------------------- y (feedback) ---------------+

`draw_diagram(ax, signals)` where `signals` carries r, u, y, y_hat, e, e_star.
Pure matplotlib patches/text so it renders identically on the Tk canvas and in a
head-less PNG.
"""
from __future__ import annotations

from typing import Dict

from matplotlib.patches import Circle, FancyArrowPatch, FancyBboxPatch


def _box(ax, x, y, w, h, text, fc, ec="#333", fs=10):
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.02,rounding_size=0.06",
                                fc=fc, ec=ec, lw=1.6, zorder=3))
    ax.text(x + w / 2, y + h / 2, text, ha="center", va="center",
            fontsize=fs, zorder=4, weight="bold")


def _sum(ax, x, y, r=0.22):
    ax.add_patch(Circle((x, y), r, fc="white", ec="#333", lw=1.6, zorder=3))
    ax.text(x, y, "Σ", ha="center", va="center", fontsize=11, zorder=4)


def _arrow(ax, p0, p1, color="#333", style="-", lw=1.6):
    ax.add_patch(FancyArrowPatch(p0, p1, arrowstyle="-|>", mutation_scale=14,
                                 color=color, lw=lw, linestyle=style, zorder=2))


def _sig(ax, x, y, name, val, color="#0b6"):
    ax.text(x, y + 0.16, name, ha="center", va="bottom", fontsize=9,
            color=color, weight="bold", zorder=5)
    ax.text(x, y - 0.18, f"{val:+.2f}", ha="center", va="top", fontsize=8.5,
            color="#222", zorder=5)


def draw_diagram(ax, signals: Dict[str, float]) -> None:
    s = signals or {}
    r = s.get("r", 0.0); u = s.get("u", 0.0); y = s.get("y", 0.0)
    yh = s.get("y_hat", 0.0); e = s.get("e", 0.0); es = s.get("e_star", 0.0)

    ax.clear()
    ax.set_xlim(0, 10.5); ax.set_ylim(0, 6.2)
    ax.set_aspect("equal", adjustable="box"); ax.axis("off")
    ax.set_title("Adaptive inverse control — live loop + EV control variables", fontsize=11)

    # main forward path -----------------------------------------------------
    ax.text(0.35, 4.6, "reference", fontsize=8.5, color="#0b6", ha="center")
    _arrow(ax, (0.35, 4.3), (1.55, 4.3))                 # r -> Σ
    _sig(ax, 0.95, 4.3, "r", r)
    _sum(ax, 1.8, 4.3)
    ax.text(1.55, 4.62, "+", fontsize=11)
    ax.text(1.62, 3.92, "−", fontsize=13)
    _arrow(ax, (2.02, 4.3), (3.1, 4.3))                  # e -> controller
    _sig(ax, 2.55, 4.3, "e", e, color="#d62728")
    _box(ax, 3.1, 3.8, 1.9, 1.0, "ANN 1\ncontroller  F⁻¹", "#ffe0e0")
    _arrow(ax, (5.0, 4.3), (6.2, 4.3))                   # u -> plant
    _sig(ax, 5.6, 4.3, "u", u, color="#1f77b4")
    _box(ax, 6.2, 3.8, 1.9, 1.0, "System  F\n(motor)", "#e3eefc")
    _arrow(ax, (8.1, 4.3), (9.7, 4.3))                   # y out
    _sig(ax, 9.0, 4.3, "y", y)
    ax.add_patch(Circle((9.7, 4.3), 0.04, fc="#333"))    # tap node

    # feedback y -> Σ -------------------------------------------------------
    ax.plot([9.7, 9.7], [4.3, 0.7], color="#333", lw=1.4, zorder=1)
    ax.plot([9.7, 1.8], [0.7, 0.7], color="#333", lw=1.4, zorder=1)
    _arrow(ax, (1.8, 0.7), (1.8, 4.08))                  # up into Σ (−)

    # emulator branch -------------------------------------------------------
    ax.plot([5.6, 5.6], [4.3, 2.4], color="#1f77b4", lw=1.3, zorder=1)  # tap u
    _arrow(ax, (5.6, 2.4), (6.2, 2.4))                   # u -> emulator
    _box(ax, 6.2, 1.9, 1.9, 1.0, "ANN 2\nemulator", "#eee0ff")
    _arrow(ax, (8.1, 2.4), (9.0, 2.4))                   # ŷ -> Σ2
    _sig(ax, 8.55, 2.4, "ŷ", yh, color="#9467bd")
    _sum(ax, 9.25, 2.4)
    ax.text(9.0, 2.72, "+", fontsize=10)
    # y into Σ2 (from feedback line tap)
    ax.plot([9.7, 9.25], [3.2, 3.2], color="#333", lw=1.2, zorder=1)
    _arrow(ax, (9.25, 3.2), (9.25, 2.62))
    ax.text(9.35, 2.95, "y", fontsize=8.5)
    _arrow(ax, (9.47, 2.4), (10.1, 2.4))                 # e* out
    _sig(ax, 9.9, 2.4, "e*", es, color="#e67700")
    ax.text(8.1, 1.4, "e*  trains ANN 2  (e* = y − ŷ)", fontsize=8, color="#e67700")


    # EV / multi-objective control variables panel -------------------------
    ev_keys = [
        ("SOC", s.get("soc_pct"), "%"),
        ("Vbat", s.get("v_bat"), "V"),
        ("Ibat", s.get("i_bat"), "A"),
        ("Pbat", None if s.get("p_bat_W") is None else s.get("p_bat_W") / 1000.0, "kW"),
        ("Torque", s.get("torque"), "Nm"),
        ("Load", s.get("load_torque"), "Nm"),
        ("km/kWh", s.get("km_per_kwh_live"), ""),
        ("Nm/kW", s.get("nm_per_kw_live"), ""),
    ]
    if any(v is not None for _, v, _ in ev_keys):
        _box(ax, 0.35, 1.25, 4.25, 1.25, "", "#f5f5f5", ec="#777", fs=8)
        ax.text(0.55, 2.28, "Control variables / EV metrics", fontsize=8.5,
                weight="bold", color="#333", ha="left")
        x0, y0 = 0.55, 2.02
        for idx, (name, val, unit) in enumerate(ev_keys):
            row = idx // 4; col = idx % 4
            xx = x0 + col * 1.02; yy = y0 - row * 0.38
            txt = "—" if val is None else f"{val:.2f}{unit}"
            ax.text(xx, yy, f"{name}: {txt}", fontsize=7.6, ha="left", color="#222")

    # indirect training path: e back-propagated through ANN2 into ANN1 ------
    _arrow(ax, (7.15, 1.9), (4.05, 3.8), color="#d62728", style=(0, (4, 3)), lw=1.3)
    ax.text(5.0, 2.2, "∂ŷ/∂u  back-prop\n(e through ANN 2 → ANN 1)",
            fontsize=8, color="#d62728", ha="center")
