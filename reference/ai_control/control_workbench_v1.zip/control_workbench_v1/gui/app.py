"""The Tk workbench window for the control domain.

Like the TSP workbench it is generic: it discovers plants, schemes, scenarios,
their step graphs, their layers and their results through the registries and the
ControlScheme interface. Adding a plant / scheme / scenario / exporter needs
**no change here**.

Four synchronised views of the live loop:
  • Loop diagram — the slide, with signal values flowing
  • Circuit      — armature loop with animated current
  • 3-D motor    — rotor spinning at the controlled speed
  • Signals      — reference/output, error, control, emulator time-series
"""
from __future__ import annotations

import tkinter as tk
from tkinter import filedialog, messagebox, ttk
from typing import Dict, List, Optional

import matplotlib
matplotlib.use("TkAgg")
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from matplotlib.figure import Figure

from core.registry import (exporters, plant_classes, scenario_names,
                           scheme_classes)
from core.render import render_signals
from core.scheme import DONE, LOCKED, READY, RUNNING, DrawContext
from core.session import Session
from gui.circuit import draw_circuit
from gui.diagram import draw_diagram
from gui.motor3d import draw_motor3d

STATUS_COLOR = {LOCKED: "#d9d9d9", READY: "#cfe3ff", RUNNING: "#fff1b8", DONE: "#c8efc8"}
STATUS_LABEL = {LOCKED: "LOCKED", READY: "READY", RUNNING: "RUNNING", DONE: "DONE"}

MODE_TRAIN = "Train (offline)"
MODE_RUN_REF = "Run · follow reference (loop)"
MODE_RUN_LIVE = "Run · live target ω"
MODES = [MODE_TRAIN, MODE_RUN_REF, MODE_RUN_LIVE]


class ControlWorkbenchGUI(tk.Tk):
    def __init__(self) -> None:
        super().__init__()
        self.title("Multi-Objective AI Control Workbench for Electric Drives")
        self.geometry("1600x980")

        # instance controls
        self.plant_var = tk.StringVar(value=plant_classes()[0].id)
        self.scenario_var = tk.StringVar(value="multistep")
        self.seed_var = tk.IntVar(value=7)
        self.dt_var = tk.DoubleVar(value=0.1)
        self.dur_var = tk.DoubleVar(value=12.0)

        self.active_scheme_var = tk.StringVar(value=scheme_classes()[0].id)
        self.speed_var = tk.IntVar(value=20)
        self.step_combo_var = tk.StringVar()
        self.live_var = tk.BooleanVar(value=False)
        self.setpoint_var = tk.DoubleVar(value=0.0)
        self.mode_var = tk.StringVar(value=MODE_TRAIN)
        self.learn_var = tk.BooleanVar(value=True)

        # a few exposed scheme knobs (Settings)
        self.p_alpha = tk.DoubleVar(value=0.5)
        self.p_excite = tk.IntVar(value=2000)
        self.p_epochs_emu = tk.IntVar(value=80)
        self.p_epochs_ctrl = tk.IntVar(value=80)
        self.p_kp = tk.DoubleVar(value=2.5)
        self.p_ki = tk.DoubleVar(value=6.0)
        self.p_kd = tk.DoubleVar(value=0.05)

        # runtime
        self.session: Optional[Session] = None
        self.layer_vars: Dict[str, tk.BooleanVar] = {}
        self.playing = False
        self.after_id: Optional[str] = None
        self.last_signals: Dict[str, float] = {}
        self.last_viz: Dict[str, float] = {}
        self.phase = 0.0       # circuit animation cursor
        self.angle = 0.0       # 3-D shaft angle

        self._build_layout()
        self.rebuild_session()

    # ================================================================== #
    def _build_layout(self) -> None:
        left = ttk.Frame(self); left.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        right = ttk.Frame(self, width=540); right.pack(side=tk.RIGHT, fill=tk.Y)
        right.pack_propagate(False)

        # ---- instance bar
        bar = ttk.Frame(left); bar.pack(side=tk.TOP, fill=tk.X, padx=8, pady=6)
        ttk.Label(bar, text="Plant").pack(side=tk.LEFT)
        ttk.Combobox(bar, textvariable=self.plant_var, state="readonly", width=22,
                     values=[c.id for c in plant_classes()]).pack(side=tk.LEFT, padx=3)
        ttk.Label(bar, text="Scenario").pack(side=tk.LEFT)
        ttk.Combobox(bar, textvariable=self.scenario_var, state="readonly", width=11,
                     values=scenario_names()).pack(side=tk.LEFT, padx=3)
        ttk.Label(bar, text="seed").pack(side=tk.LEFT)
        ttk.Spinbox(bar, from_=0, to=999999, textvariable=self.seed_var, width=7).pack(side=tk.LEFT, padx=3)
        ttk.Label(bar, text="dt").pack(side=tk.LEFT)
        ttk.Spinbox(bar, from_=0.01, to=0.5, increment=0.01, textvariable=self.dt_var, width=5).pack(side=tk.LEFT, padx=3)
        ttk.Label(bar, text="dur").pack(side=tk.LEFT)
        ttk.Spinbox(bar, from_=2, to=60, increment=1, textvariable=self.dur_var, width=5).pack(side=tk.LEFT, padx=3)
        ttk.Button(bar, text="Rebuild", command=self.rebuild_session).pack(side=tk.LEFT, padx=5)
        ttk.Button(bar, text="Settings", command=self.open_settings).pack(side=tk.LEFT, padx=2)

        # ---- scheme + step control
        ctrl = ttk.LabelFrame(left, text="Scheme control")
        ctrl.pack(side=tk.TOP, fill=tk.X, padx=8, pady=(0, 4))
        row1 = ttk.Frame(ctrl); row1.pack(side=tk.TOP, fill=tk.X, padx=6, pady=4)
        ttk.Label(row1, text="Active scheme").pack(side=tk.LEFT)
        self.scheme_combo = ttk.Combobox(row1, textvariable=self.active_scheme_var,
                                         state="readonly", width=24,
                                         values=[c.id for c in scheme_classes()])
        self.scheme_combo.pack(side=tk.LEFT, padx=5)
        self.scheme_combo.bind("<<ComboboxSelected>>", lambda e: self._on_scheme_change())
        ttk.Label(row1, text="Step").pack(side=tk.LEFT, padx=(12, 2))
        self.step_combo = ttk.Combobox(row1, textvariable=self.step_combo_var,
                                       state="readonly", width=46)
        self.step_combo.pack(side=tk.LEFT, padx=4)
        self.step_combo.bind("<<ComboboxSelected>>", lambda e: self._on_step_select())

        self.step_strip = ttk.Frame(ctrl); self.step_strip.pack(side=tk.TOP, fill=tk.X, padx=6, pady=2)

        row2 = ttk.Frame(ctrl); row2.pack(side=tk.TOP, fill=tk.X, padx=6, pady=4)
        for txt, cmd in [("▶ Step", self.do_step), ("Run step", self.do_run_step),
                         ("Run all", self.do_run_all), ("Reset this", self.do_reset_scheme)]:
            ttk.Button(row2, text=txt, command=cmd).pack(side=tk.LEFT, padx=3)
        self.play_btn = ttk.Button(row2, text="Play", command=self.toggle_play)
        self.play_btn.pack(side=tk.LEFT, padx=(14, 3))
        ttk.Label(row2, text="delay ms").pack(side=tk.LEFT)
        ttk.Spinbox(row2, from_=1, to=500, textvariable=self.speed_var, width=5).pack(side=tk.LEFT)

        # ---- mode row: Train vs continuous Run (until Stop), live target slider
        row3 = ttk.Frame(ctrl); row3.pack(side=tk.TOP, fill=tk.X, padx=6, pady=(0, 5))
        ttk.Label(row3, text="Mode").pack(side=tk.LEFT)
        self.mode_combo = ttk.Combobox(row3, textvariable=self.mode_var, state="readonly",
                                       width=26, values=MODES)
        self.mode_combo.pack(side=tk.LEFT, padx=4)
        self.mode_combo.bind("<<ComboboxSelected>>", lambda e: self._on_mode_change())
        ttk.Checkbutton(row3, text="keep learning", variable=self.learn_var,
                        command=self._apply_learning).pack(side=tk.LEFT, padx=10)
        self.setpoint_scale = tk.Scale(row3, from_=-20, to=20, resolution=0.1,
                                       orient=tk.HORIZONTAL, length=300,
                                       variable=self.setpoint_var, command=self._on_setpoint,
                                       showvalue=True, label="target ω [rad/s]")
        self.setpoint_scale.pack(side=tk.LEFT, padx=6)

        # ---- notebook with the four views
        self.nb = ttk.Notebook(left); self.nb.pack(side=tk.TOP, fill=tk.BOTH, expand=True, padx=8, pady=6)
        self.fig_diagram = Figure(figsize=(7, 4.6), dpi=100)
        self.fig_circuit = Figure(figsize=(7, 4.6), dpi=100)
        self.fig_motor = Figure(figsize=(7, 4.6), dpi=100)
        self.fig_signals = Figure(figsize=(7, 4.6), dpi=100)
        self.ax_diagram = self.fig_diagram.add_subplot(111)
        self.ax_circuit = self.fig_circuit.add_subplot(111)
        self.ax_motor = self.fig_motor.add_subplot(111, projection="3d")
        self.canvases = {}
        for fig, name in [(self.fig_diagram, "Loop diagram"), (self.fig_circuit, "Circuit"),
                          (self.fig_motor, "3-D motor"), (self.fig_signals, "Signals")]:
            tab = ttk.Frame(self.nb); self.nb.add(tab, text=name)
            cv = FigureCanvasTkAgg(fig, master=tab)
            cv.get_tk_widget().pack(side=tk.TOP, fill=tk.BOTH, expand=True)
            self.canvases[name] = cv
        self.nb.bind("<<NotebookTabChanged>>", lambda e: self.redraw())

        # ---- right: state + layers + comparison + export
        self.layer_frame = ttk.LabelFrame(right, text="Signal layers")
        self.layer_frame.pack(side=tk.TOP, fill=tk.X, padx=6, pady=4)

        sf = ttk.LabelFrame(right, text="State / cost"); sf.pack(side=tk.TOP, fill=tk.BOTH, expand=True, padx=6, pady=4)
        self.state_text = tk.Text(sf, height=14, width=62, font=("TkFixedFont", 9))
        self.state_text.pack(side=tk.TOP, fill=tk.BOTH, expand=True)

        cf = ttk.LabelFrame(right, text="Comparison"); cf.pack(side=tk.TOP, fill=tk.X, padx=6, pady=4)
        cols = ("scheme", "plant", "rmse", "km/kWh", "Nm/kW", "Wh/km", "SOC%", "Irms", "effort", "grads", "ms")
        self.tree = ttk.Treeview(cf, columns=cols, show="headings", height=6)
        for c, w in zip(cols, (120, 95, 55, 65, 60, 60, 55, 55, 55, 60, 50)):
            self.tree.heading(c, text=c); self.tree.column(c, width=w, anchor=tk.CENTER)
        self.tree.pack(side=tk.TOP, fill=tk.X)

        ef = ttk.Frame(right); ef.pack(side=tk.TOP, fill=tk.X, padx=6, pady=4)
        self.export_var = tk.StringVar(value=list(exporters().keys())[0])
        ttk.Combobox(ef, textvariable=self.export_var, state="readonly", width=20,
                     values=list(exporters().keys())).pack(side=tk.LEFT, padx=2)
        ttk.Button(ef, text="Export", command=self.do_export).pack(side=tk.LEFT, padx=2)
        ttk.Button(ef, text="Save run", command=self.do_save).pack(side=tk.LEFT, padx=2)
        ttk.Button(ef, text="Load run", command=self.do_load).pack(side=tk.LEFT, padx=2)

    # ================================================================== #
    # session lifecycle
    # ================================================================== #
    def _scheme_params(self) -> Dict[str, dict]:
        return {
            "iaic": {"ref_model_alpha": self.p_alpha.get(),
                     "excite_steps": self.p_excite.get(),
                     "epochs_emu": self.p_epochs_emu.get(),
                     "epochs_ctrl": self.p_epochs_ctrl.get()},
            "pid": {"kp": self.p_kp.get(), "ki": self.p_ki.get(), "kd": self.p_kd.get()},
        }

    def rebuild_session(self) -> None:
        self.stop_play()
        self.session = Session(plant_id=self.plant_var.get(),
                               scenario_id=self.scenario_var.get(),
                               dt=float(self.dt_var.get()),
                               duration=float(self.dur_var.get()),
                               seed=int(self.seed_var.get()),
                               scheme_params=self._scheme_params())
        self.last_signals, self.last_viz = {}, {}
        self.phase = self.angle = 0.0
        # size the live-target slider to this plant's reachable output range
        ylo, yhi = self._scheme().plant.y_range()
        span = max(abs(ylo), abs(yhi))
        self.setpoint_scale.config(from_=round(-span, 1), to=round(span, 1))
        self.mode_var.set(MODE_TRAIN)
        for sc in self.session.scheme_list():
            sc.set_setpoint(None)
            sc.run_continuous = False
        self._on_scheme_change()

    def _scheme(self):
        return self.session.schemes[self.active_scheme_var.get()]

    def _on_scheme_change(self) -> None:
        sc = self._scheme()
        self.mode_var.set(MODE_TRAIN)
        self._rebuild_layers()
        self._refresh_step_combo(); self._refresh_step_strip()
        self.redraw(); self.update_state(); self._refresh_tree()

    # ---- step combo + dependency strip -------------------------------- #
    def _step_disp(self, scheme, step_id) -> str:
        st = scheme._step(step_id)
        needs = ("needs: " + ", ".join(st.requires)) if st.requires else "no prereqs"
        return f"{st.label} · {needs} · [{STATUS_LABEL[scheme.status(step_id)]}]"

    def _refresh_step_combo(self) -> None:
        sc = self._scheme()
        vals = [self._step_disp(sc, s.id) for s in sc.steps()]
        self.step_combo["values"] = vals
        ids = [s.id for s in sc.steps()]
        if sc.active_step_id in ids:
            self.step_combo_var.set(vals[ids.index(sc.active_step_id)])

    def _refresh_step_strip(self) -> None:
        for w in self.step_strip.winfo_children():
            w.destroy()
        sc = self._scheme()
        for i, s in enumerate(sc.steps()):
            if i:
                ttk.Label(self.step_strip, text="→").pack(side=tk.LEFT)
            mark = "▸" if s.id == sc.active_step_id else " "
            lbl = tk.Label(self.step_strip, text=f"{mark}{s.label}",
                           bg=STATUS_COLOR[sc.status(s.id)], padx=6, pady=2,
                           relief=tk.RIDGE, font=("TkDefaultFont", 8))
            lbl.pack(side=tk.LEFT, padx=1)
            lbl.bind("<Button-1>", lambda e, sid=s.id: self._select_step(sid))

    def _select_step(self, sid) -> None:
        self._scheme().active_step_id = sid
        self._refresh_step_combo(); self._refresh_step_strip(); self.update_state()

    def _on_step_select(self) -> None:
        sc = self._scheme()
        ids = [s.id for s in sc.steps()]
        try:
            sc.active_step_id = ids[self.step_combo["values"].index(self.step_combo_var.get())]
        except ValueError:
            pass
        self._refresh_step_strip(); self.update_state()

    # ---- layers ------------------------------------------------------- #
    def _rebuild_layers(self) -> None:
        for w in self.layer_frame.winfo_children():
            w.destroy()
        self.layer_vars = {}
        sc = self._scheme()
        for ls in sc.layers():
            v = tk.BooleanVar(value=ls.default_on)
            self.layer_vars[ls.id] = v
            ttk.Checkbutton(self.layer_frame, text=ls.label, variable=v,
                            command=self.redraw).pack(side=tk.LEFT, padx=4)

    def _layer_on(self) -> Dict[str, bool]:
        return {k: v.get() for k, v in self.layer_vars.items()}

    # ================================================================== #
    # run controls
    # ================================================================== #
    def _post(self, frames) -> None:
        if frames:
            f = frames[-1] if isinstance(frames, list) else frames
            if getattr(f, "signals", None):
                self.last_signals = f.signals
            if getattr(f, "viz", None):
                self.last_viz = f.viz
        self._refresh_step_combo(); self._refresh_step_strip()
        self.redraw(); self.update_state(); self._refresh_tree()

    def do_step(self) -> None:
        self._post(self._scheme().micro_step())

    def do_run_step(self) -> None:
        self._stop_continuous()          # one pass, not free-run
        sc = self._scheme()
        self._post(sc.run_step(sc.active_step_id))

    def do_run_all(self) -> None:
        self._stop_continuous()
        self._post(self._scheme().run_all())

    def do_reset_scheme(self) -> None:
        self.stop_play()
        self._stop_continuous()
        self.mode_var.set(MODE_TRAIN)
        self._scheme().reset()
        self.last_signals, self.last_viz = {}, {}
        self._post(None)

    def do_train_offline(self) -> None:
        """Run every step except the final live/online one (no-op for PID)."""
        self.stop_play()
        sc = self._scheme()
        for st in sc.steps()[:-1]:
            if not sc.is_step_done(st.id):
                sc.run_step(st.id)
        self._post(None)

    # ---- mode handling ------------------------------------------------- #
    def _offline_done(self, sc) -> bool:
        return all(sc.is_step_done(s.id) for s in sc.steps()[:-1])

    def _stop_continuous(self) -> None:
        sc = self._scheme()
        sc.set_setpoint(None)
        sc.run_continuous = False

    def _apply_learning(self) -> None:
        sc = self._scheme()
        on = self.learn_var.get()
        if hasattr(sc, "adapt_emu"):
            sc.adapt_emu = on
            sc.adapt_ctrl = on

    def _apply_mode(self) -> bool:
        """Configure the active scheme for the chosen mode. Returns False (and
        reverts to Train) if a Run mode is picked before the controller exists."""
        sc = self._scheme()
        mode = self.mode_var.get()
        self._apply_learning()
        if mode == MODE_TRAIN:
            self._stop_continuous()
            sc.active_step_id = sc.next_ready_step() or sc.steps()[0].id
            return True
        # Run modes need a trained controller (iaic)
        if not self._offline_done(sc):
            self.mode_var.set(MODE_TRAIN)
            messagebox.showinfo("Run mode",
                                "Train first: press 'Run all' once, or run the "
                                "offline steps, then choose a Run mode.")
            return False
        last = sc.steps()[-1].id
        sc._done_steps.discard(last)
        sc.online_k = 0
        sc.k = 0
        sc.active_step_id = last
        if mode == MODE_RUN_REF:
            sc.set_setpoint(None); sc.run_continuous = True
        else:                                   # MODE_RUN_LIVE
            sc.run_continuous = False; sc.set_setpoint(float(self.setpoint_var.get()))
        return True

    def _on_mode_change(self) -> None:
        self.stop_play()
        self._apply_mode()
        self._refresh_step_combo(); self._refresh_step_strip(); self.update_state()

    def _on_setpoint(self, _val) -> None:
        if self.mode_var.get() == MODE_RUN_LIVE:
            self._scheme().set_setpoint(float(self.setpoint_var.get()))

    def toggle_play(self) -> None:
        if self.playing:
            self.stop_play()
        else:
            if not self._apply_mode():
                return
            self.playing = True
            self.play_btn.config(text="Stop")
            self._tick()

    def stop_play(self) -> None:
        self.playing = False
        if hasattr(self, "play_btn"):
            self.play_btn.config(text="Play")
        if self.after_id is not None:
            try:
                self.after_cancel(self.after_id)
            except Exception:
                pass
            self.after_id = None

    def _tick(self) -> None:
        if not self.playing:
            return
        sc = self._scheme()
        # In Train mode, stop once the offline steps are all done.
        if self.mode_var.get() == MODE_TRAIN and self._offline_done(sc):
            self.stop_play(); self._post(None); return
        f = sc.micro_step()
        if f is None:                 # replay reached its end (Train finished)
            self.stop_play(); self._post(None); return
        if getattr(f, "signals", None):
            self.last_signals = f.signals
        if getattr(f, "viz", None):
            self.last_viz = f.viz
        self._refresh_step_strip()
        self.redraw(light=True); self.update_state()
        self.after_id = self.after(int(self.speed_var.get()), self._tick)

    # ================================================================== #
    # drawing
    # ================================================================== #
    def redraw(self, light: bool = False) -> None:
        name = self.nb.tab(self.nb.select(), "text") if self.nb.tabs() else "Signals"
        # advance animation cursors from the live viz
        dt = float(self.dt_var.get())
        i_max = max(self.last_viz.get("i_max", 1.0), 1e-6)
        self.phase = (self.phase + 0.04 + 0.25 * (self.last_viz.get("current", 0.0) / i_max)) % 1.0
        self.angle = (self.angle + self.last_viz.get("speed", 0.0) * dt) % (2 * 3.141592653589793)

        if name == "Loop diagram":
            merged = {**self.last_signals, **self.last_viz}
            draw_diagram(self.ax_diagram, merged)
            self.canvases[name].draw_idle()
        elif name == "Circuit":
            draw_circuit(self.ax_circuit, self.last_viz, self.phase)
            self.canvases[name].draw_idle()
        elif name == "3-D motor":
            draw_motor3d(self.ax_motor, self.last_viz, self.angle)
            self.canvases[name].draw_idle()
        elif name == "Signals":
            render_signals(self.fig_signals, self._scheme(), self._layer_on())
            self.canvases[name].draw_idle()

    # ================================================================== #
    # state panel + comparison
    # ================================================================== #
    def update_state(self, *_args) -> None:
        sc = self._scheme()
        c = sc.cost
        lines = [f"Scheme : {sc.name}",
                 f"Plant  : {sc.plant.name}",
                 f"Active step : {sc.active_step_id}",
                 "",
                 "Honest cost",
                 f"  sim steps     : {c.sim_steps}",
                 f"  grad updates  : {c.grad_updates}",
                 f"  forward evals : {c.forward_evals}",
                 f"  train epochs  : {c.epochs}",
                 f"  elapsed ms    : {c.elapsed_ms:.1f}"]
        if self.last_signals:
            s = self.last_signals
            lines += ["", "Live signals",
                      f"  r={s.get('r',0):+.3f}  y={s.get('y',0):+.3f}  u={s.get('u',0):+.3f}",
                      f"  e={s.get('e',0):+.3f}  e*={s.get('e_star',0):+.3f}  ŷ={s.get('y_hat',0):+.3f}"]
        if self.last_viz and ("soc_pct" in self.last_viz or "p_bat_W" in self.last_viz):
            v = self.last_viz
            lines += ["", "EV / battery / load",
                      f"  SOC={v.get('soc_pct',0):.2f}%  Vbat={v.get('v_bat',0):.2f} V  Ibat={v.get('i_bat',0):.2f} A",
                      f"  Pbat={v.get('p_bat_W',0)/1000.0:.3f} kW  torque={v.get('torque',0):.3f} Nm  load={v.get('load_torque',0):.3f} Nm",
                      f"  dist={v.get('distance_km',0):.4f} km  E={v.get('energy_kwh',0):.5f} kWh",
                      f"  km/kWh={v.get('km_per_kwh_live',0):.2f}  Wh/km={v.get('wh_per_km_live',0):.2f}  Nm/kW={v.get('nm_per_kw_live',0):.2f}"]
        m = sc.metrics()
        if m:
            lines += ["", "Tracking metrics",
                      f"  RMSE={m['rmse']:.3f}  sse={m['sse']:.3f}",
                      f"  overshoot={m['overshoot_pct']:.1f}%  effort={m['control_effort']:.2f}"]
            if "km_per_kwh" in m or "nm_per_kw" in m:
                lines += ["", "Energy metrics",
                          f"  km/kWh={m.get('km_per_kwh',0):.3f}  Wh/km={m.get('wh_per_km',0):.3f}",
                          f"  Nm/kW={m.get('nm_per_kw',0):.3f}  Irms={m.get('rms_current_a',0):.3f} A",
                          f"  final SOC={m.get('final_soc_pct',0):.2f}%  drop={m.get('soc_drop_pctpts',0):.4f} pct-pts"]
        self.state_text.delete("1.0", tk.END)
        self.state_text.insert(tk.END, "\n".join(lines))

    def _refresh_tree(self) -> None:
        for r in self.tree.get_children():
            self.tree.delete(r)
        for row in self.session.comparison_rows():
            gap = row.get("gap_pct")
            self.tree.insert("", tk.END, values=(
                row.get("scheme", ""), row.get("plant", ""),
                row.get("rmse", ""), row.get("km_per_kwh", ""),
                row.get("nm_per_kw", ""), row.get("wh_per_km", ""),
                row.get("final_soc_pct", ""), row.get("rms_current_a", ""),
                row.get("control_effort", ""), row.get("grad_updates", ""),
                row.get("ms", "")))

    # ================================================================== #
    # export / save / load / settings
    # ================================================================== #
    def do_export(self) -> None:
        label = self.export_var.get()
        spec = exporters()[label]
        path = filedialog.asksaveasfilename(defaultextension="." + spec["ext"],
                                            filetypes=[(label, "*." + spec["ext"])])
        if not path:
            return
        try:
            if label == "Signal plot (PNG)":
                spec["fn"](self.session, path, scheme_id=self.active_scheme_var.get(),
                           layer_on=self._layer_on())
            elif label == "Signals (CSV)":
                spec["fn"](self.session, path, scheme_id=self.active_scheme_var.get())
            else:
                spec["fn"](self.session, path)
            messagebox.showinfo("Export", f"Wrote {path}")
        except Exception as ex:
            messagebox.showerror("Export failed", str(ex))

    def do_save(self) -> None:
        path = filedialog.asksaveasfilename(defaultextension=".json")
        if path:
            self.session.save(path); messagebox.showinfo("Save", f"Saved {path}")

    def do_load(self) -> None:
        path = filedialog.askopenfilename(filetypes=[("Session", "*.json")])
        if not path:
            return
        try:
            self.session = Session.load(path)
            self.plant_var.set(self.session.plant_id)
            self.scenario_var.set(self.session.scenario_id)
            self._on_scheme_change()
            messagebox.showinfo("Load", f"Loaded {path}")
        except Exception as ex:
            messagebox.showerror("Load failed", str(ex))

    def open_settings(self) -> None:
        win = tk.Toplevel(self); win.title("Settings"); win.geometry("360x320")
        def row(parent, label, var, frm, to, inc=1):
            f = ttk.Frame(parent); f.pack(side=tk.TOP, fill=tk.X, padx=8, pady=3)
            ttk.Label(f, text=label, width=22).pack(side=tk.LEFT)
            ttk.Spinbox(f, from_=frm, to=to, increment=inc, textvariable=var, width=10).pack(side=tk.LEFT)
        ttk.Label(win, text="Indirect inverse (iaic)", font=("TkDefaultFont", 9, "bold")).pack(pady=(8, 0))
        row(win, "ref-model alpha", self.p_alpha, 0.05, 1.0, 0.05)
        row(win, "excitation steps", self.p_excite, 200, 8000, 100)
        row(win, "emulator epochs", self.p_epochs_emu, 5, 300, 5)
        row(win, "controller epochs", self.p_epochs_ctrl, 5, 300, 5)
        ttk.Label(win, text="PID baseline", font=("TkDefaultFont", 9, "bold")).pack(pady=(10, 0))
        row(win, "kp", self.p_kp, 0.0, 50.0, 0.1)
        row(win, "ki", self.p_ki, 0.0, 50.0, 0.1)
        row(win, "kd", self.p_kd, 0.0, 5.0, 0.01)
        ttk.Button(win, text="Apply & rebuild",
                   command=lambda: (self.rebuild_session(), win.destroy())).pack(pady=12)

    def on_close(self) -> None:
        self.stop_play()
        self.destroy()
