# Adaptive Inverse Control Workbench — ARCHITECTURE

> Single source of truth. Read this first before changing code. It mirrors the
> plugin design of the TSP workbench it was ported from: a generic GUI/CLI that
> discovers everything through contracts + registries, so adding a plant, a
> control scheme, a reference or an exporter needs **no GUI changes**.

## 1. What this program is

A desktop workbench (tkinter + matplotlib) that runs, animates and compares
**speed-control schemes** on the same reference trajectory and plant:

* **Indirect adaptive inverse** (`iaic`) — the scheme on the Boutalis slide. Two
  neural networks: an **emulator** (ANN 2) that learns the forward dynamics, and
  an **inverse controller** (ANN 1) whose output error is back-propagated
  *through the emulator*. Trained off-line, then adapted on-line every step.
* **PID baseline** (`pid`) — a classical fixed-gain controller for comparison.

Both drive a pluggable **plant**: a **DC motor** (`dc`) or a simplified
**induction motor** (`im`). The same scheme controls either with zero
scheme-side changes — that is the point of the plant contract.

Four synchronised live views: the loop **block diagram** (the slide), the
armature **circuit** with animated current, a **3-D rotor** spinning at the
controlled speed, and the **signal** time-series.

## 2. Module map

```
main.py                 GUI entry point (import bootstrap; launch window)
cli.py                  headless runner: run, benchmark, export, save
bootstrap.py            imports side-effect modules so the registries fill

core/
  nn.py                 tiny numpy MLP; tanh hidden, linear out; input_grad (Jacobian)
  plant.py              THE PLANT CONTRACT: Plant base, RK4 integration, measured()
  scheme.py             THE SCHEME CONTRACT: Step, CostMeter, SimFrame, LayerSpec,
                        ControlScheme base, DrawContext, status constants
  registry.py           register/lookup for plants, schemes, scenarios, exporters
  scenario.py           reference-trajectory generators (step/multistep/sine/staircase)
  session.py            Session: plant + reference + every scheme; save/load JSON
  render.py             one signal-plot path (GUI 'Signals' tab + PNG exporter)
  export.py             exporters (Signals CSV, Metrics CSV, Plot PNG, Session JSON)

plants/
  dc_motor.py           DCMotorPlant        (id="dc")
  induction_motor.py    InductionMotorPlant (id="im")

schemes/
  pid.py                PIDControl              (id="pid") + shared time-series drawer
  indirect_inverse.py   IndirectInverseControl  (id="iaic")

gui/
  app.py                ControlWorkbenchGUI — generic over registered plants/schemes
  diagram.py            live block diagram (the slide) with signal values
  circuit.py            armature circuit + animated current carriers
  motor3d.py            3-D rotor spun by the integrated shaft angle
```

Dependency direction: `gui` and `cli` depend on `core` + `plants` + `schemes`;
`core` never imports `gui`. `render.py` only needs the scheme's recorded log, so
the GUI canvas and the PNG exporter share it.

## 3. The Plant contract (`core/plant.py`)

A plant is the "System (F)" box. Subclass `Plant`, set the labels + `PARAMS`,
implement the dynamics, decorate with `@register_plant`.

| member | meaning |
|--------|---------|
| `id / name` | key + UI label |
| `input_name/unit`, `output_name/unit` | signal labels for axes/diagram |
| `PARAMS` | default numeric parameters (editable in Settings) |
| `initial_state()` | state vector at reset |
| `deriv(x, u)` | continuous dynamics ẋ = f(x, u) |
| `output()` | measured output y (what we track) |
| `measured()` | vector fed to the nets; **first entry is the output** |
| `measured_scale()` | per-entry normalisers for `measured()` |
| `u_range()`, `y_range()` | input/output bounds (clipping + NN scaling) |
| `viz_state()` | physical quantities for the circuit/3-D/diagram |

`step(u, dt)` is provided: RK4 with `substeps` sub-integrations so stiff
electrical dynamics stay stable at the GUI's animation timestep. `clone()`
gives each scheme its **own** plant instance (plants are stateful, unlike the
TSP point cloud, so they must not be shared).

> Why `measured()` exposes the full state (speed **and** current): voltage→speed
> is relative-degree-2, so a one-step inverse from the output alone is
> near-singular. Feeding the measured state makes the one-step map
> well-conditioned. See the Changelog.

## 4. The ControlScheme contract (`core/scheme.py`)

Twin of the TSP `Algorithm`. Subclass `ControlScheme`, set `id/name/color/STEPS`,
implement the bodies, decorate with `@register_scheme`.

### 4.1 Step graph
`Step(id, label, requires=[...], produces=[...], description="", rerunnable=False)`.
`requires` lists step ids that must be DONE first — exactly what the GUI renders
as the colour-coded dependency strip and the step dropdown. `status(step_id)` →
`LOCKED / READY / RUNNING / DONE`. For `iaic` the graph *is* the method:
`excite → emulator → controller → online`.

### 4.2 Execution
* `micro_step() -> SimFrame|None` — the finest animatable unit (one excitation
  sample, one training epoch, or one closed-loop time step). Drives `Play` and
  `▶ Step`. Auto-advances the active-step cursor when a step finishes.
* `run_step(step_id)` / `run_all()` / `reset()` — as in the TSP contract.

### 4.3 Honest cost — `CostMeter`
Tracks the work that actually happened, separately: `sim_steps` (plant
integrations), `grad_updates` (SGD weight updates), `forward_evals` (network
passes), `epochs` (offline training epochs), `elapsed_ms` (wall-clock). A
"10000-step" run no longer hides that each online step also does two forward
passes, a Jacobian and two weight updates.

### 4.4 Results / comparison
`result()` is a JSON-serialisable snapshot (recorded log, metrics, MSE
histories, network weights). `metrics()` computes RMSE, steady-state error,
overshoot and control effort from the log. `comparison_rows()` yields one row
per scheme; `Session.comparison_rows` adds `gap_pct` versus the best (lowest)
RMSE.

### 4.5 Drawing
`layers()` lists toggleable signal layers (the GUI builds a checkbox each);
`draw_signals(fig, ctx)` renders the time-series. The diagram/circuit/3-D views
read the per-frame `SimFrame.signals` / `SimFrame.viz`, so they animate straight
from the live loop.

## 5. The indirect-inverse method (`schemes/indirect_inverse.py`)

Regressors (normalised): emulator `[state(k), u(k)] → y(k+1)`; controller
`[y_target(k+1), state(k)] → u(k)`.

* **excite** — drive a private plant clone with a random staircase + dither;
  record `(state, u, y)`.
* **emulator** — SGD-train ANN 2 to minimise `e* = y − ŷ`.
* **controller** — initialise ANN 1 by **direct inverse modelling** on the data
  (correctly scaled, unlike back-prop through the small plant gain).
* **online** — close the loop on the reference. Each step: controller → `u`,
  emulator predicts `ŷ`, plant advances, then **both** nets adapt — the emulator
  on `e*`, and the controller on the tracking error pushed **through the
  emulator** (`∂ŷ/∂u`, Jacobian-normalised so a small gain can't stall it). A
  reference-model target `y_target = y + clip(α·(r − y))` keeps each one-step
  request reachable, i.e. on the manifold the controller was trained on.

## 6. Save / load (`SESSION_VERSION = 1`)

JSON written by `Session.save`: `version`, `saved_at`, `instance`
(plant_id/params, scenario_id, dt, duration, seed), `scheme_params`, `results`
(each scheme's `result()`), `history`. `Session.from_dict` rebuilds the plant +
reference, recreates each registered scheme, and calls `load_result`. Unknown
scheme ids are ignored, so old saves still load after you add schemes.

## 7. GUI overview (`gui/app.py`)

* **Instance bar** — plant, scenario, seed, dt, duration, Rebuild, Settings.
* **Scheme control** — active-scheme dropdown; step dropdown (`label · needs: … ·
  [STATUS]`); colour-coded dependency strip; `▶ Step / Run step / Run all / Reset
  this`; `Play/Stop` + delay. A **Mode** dropdown separates *Train (offline)*
  from two continuous *Run* modes — *follow reference (loop)* and *live target
  ω* (slider) — and a **keep learning** toggle turns on-line adaptation on/off.
  In a Run mode `Play` runs until `Stop` (the online loop free-runs on the held
  set-point or cycles the reference; rolling log cap keeps memory bounded). The
  replay buttons force a single pass so they never clash with a Run.
* **Notebook** — Loop diagram / Circuit / 3-D motor / Signals; only the visible
  tab is redrawn each Play tick; circuit phase and 3-D angle integrate from the
  live current/speed.
* **Right panel** — signal-layer toggles, State/cost text (the honest
  `CostMeter` + live signals + metrics), comparison table, export/save/load.

## 8. CLI (`cli.py`)

```
python cli.py run --plant dc --scenario multistep --schemes iaic pid --plot p.png --metrics m.csv
python cli.py benchmark --plant im --scenario staircase --scheme iaic --seeds 0-5
```

Same core, so any registered plant/scheme/exporter is available head-less.

## 9. How to extend

* **New plant** — subclass `Plant`, implement `deriv/output/measured/…`,
  `@register_plant`, add an import to `bootstrap.py`. It appears in the plant
  dropdown and every scheme can control it.
* **New scheme** — subclass `ControlScheme`, declare `STEPS`, implement the
  bodies + `comparison_rows/layers/draw_signals`, `@register_scheme`, import in
  `bootstrap.py`.
* **New reference** — decorate `f(duration, dt, seed) -> np.ndarray` with
  `@register_scenario("name")`.
* **New exporter** — decorate `f(session, path)` with
  `@register_exporter("Label", "ext")`.

## Conventions

* `core` stays framework-free except `render.py` (matplotlib only).
* `measured()[0]` is always the tracked output.
* Colours: PID = green family, indirect inverse = red family — keep new schemes
  visually distinct.

## Changelog

* **v1** — Initial control port of the TSP workbench plugin architecture. Plant
  contract + DC/induction motors; ControlScheme contract with the
  excite→emulator→controller→online step graph; honest `CostMeter`; PID
  baseline; four self-drawing views (diagram/circuit/3-D/signals); Session
  save/load; CSV/PNG/JSON exporters; CLI run + benchmark. Control loop runs at
  dt = 0.1 s (meaningful per-step speed authority); networks see the measured
  state and use a clipped reference-model target so the one-step inverse is
  well-conditioned; controller initialised by direct inverse modelling and
  adapted on-line by the indirect (through-emulator, Jacobian-normalised) rule.

* **v1.1** — Live set-point: `ControlScheme.set_setpoint(value)` makes the
  online loop track a held target instead of the pre-baked reference (free-run
  with a rolling log cap). GUI adds **Train offline** and a **Live target ω**
  slider, so after training you can command a speed and watch it be reached;
  the replay buttons (Run step/all/Reset) clear live mode to avoid free-run.
  To track *torque/current* instead of speed, make a plant or scheme whose
  `measured()[0]` is current and tracking follows from the same machinery.

* **v1.2** — Modes + continuous operation. `ControlScheme.run_continuous`: the
  online loop cycles the reference forever instead of terminating, so `Play`
  runs until `Stop`. GUI gains a **Mode** dropdown (Train / Run-reference /
  Run-live) and a **keep learning** toggle; replay buttons force single-pass.
  Default `lr_ctrl_online` lowered to 0.02 — gentle on-line adaptation tracks
  arbitrary live set-points accurately and stays stable over long runs (the
  earlier 0.08 could drift on large set-point jumps).

* **v1.3 / EV v0.1** — Added `evdc`, a system-level EV drive plant containing
  battery SOC, SOC-dependent internal resistance/voltage sag, simplified
  bidirectional buck/boost converter envelope, DC motor dynamics, vehicle
  equivalent inertia and variable road-load torque. Added `urban` reference
  scenario, EV metrics (`km/kWh`, `Wh/km`, `Nm/kW`, RMS current, SOC drop,
  voltage sag), dynamic signal CSV export, and a first-tab live variable panel
  for SOC, battery power, torque and load. This is the first step toward a
  modular multi-objective AI drive-control framework.
