"""Headless runner — same core as the GUI, so every registered plant / scheme /
exporter works without a display.

Examples
--------
  python cli.py run --plant dc --scenario multistep --schemes iaic pid \\
      --plot out.png --metrics m.csv --save s.json
  python cli.py benchmark --plant dc --scenario staircase --seeds 0-5
"""
from __future__ import annotations

import argparse

import bootstrap  # noqa: F401
from core.export import export_plot_png
from core.registry import exporters, get_scheme, plant_ids, scheme_classes, scenario_names
from core.session import Session


def _run(args) -> None:
    sess = Session(plant_id=args.plant, scenario_id=args.scenario,
                   dt=args.dt, duration=args.duration, seed=args.seed)
    chosen = args.schemes or [c.id for c in scheme_classes()]
    for sid in chosen:
        scheme = sess.schemes[sid]
        scheme.run_all()
        m = scheme.metrics()
        extra = ""
        if "km_per_kwh" in m:
            extra = (f"  km/kWh={m.get('km_per_kwh', float('nan')):.3f}"
                     f"  Nm/kW={m.get('nm_per_kw', float('nan')):.3f}"
                     f"  SOC={m.get('final_soc_pct', float('nan')):.2f}%")
        print(f"[{sid:5}] {scheme.name:28} "
              f"RMSE={m.get('rmse', float('nan')):.4f}  "
              f"sse={m.get('sse', float('nan')):.4f}  "
              f"overshoot={m.get('overshoot_pct', 0):.1f}%"
              f"{extra}  "
              f"grad_updates={scheme.cost.grad_updates}  "
              f"{scheme.cost.elapsed_ms:.0f} ms")
    if args.plot:
        export_plot_png(sess, args.plot, scheme_id=chosen[0])
        print("plot ->", args.plot)
    if args.metrics:
        exporters()["Metrics table (CSV)"]["fn"](sess, args.metrics)
        print("metrics ->", args.metrics)
    if args.save:
        sess.save(args.save)
        print("session ->", args.save)


def _benchmark(args) -> None:
    lo, hi = (args.seeds.split("-") + [args.seeds])[:2]
    seeds = range(int(lo), int(hi) + 1)
    rmses = []
    for s in seeds:
        sess = Session(plant_id=args.plant, scenario_id=args.scenario,
                       dt=args.dt, duration=args.duration, seed=s)
        sc = sess.schemes[args.scheme]
        sc.run_all()
        m = sc.metrics()
        rmses.append(m.get("rmse", float("nan")))
        print(f"seed {s:3}: RMSE={m.get('rmse', float('nan')):.4f}")
    import statistics
    print(f"\n{args.scheme} on {args.plant}/{args.scenario}: "
          f"mean RMSE={statistics.mean(rmses):.4f} "
          f"(±{statistics.pstdev(rmses):.4f}) over {len(rmses)} seeds")


def main() -> None:
    ap = argparse.ArgumentParser(description="Adaptive Inverse Control Workbench (headless)")
    sub = ap.add_subparsers(dest="cmd", required=True)

    r = sub.add_parser("run")
    r.add_argument("--plant", default="dc", choices=plant_ids())
    r.add_argument("--scenario", default="multistep", choices=scenario_names())
    r.add_argument("--schemes", nargs="*", default=None)
    r.add_argument("--dt", type=float, default=0.1)
    r.add_argument("--duration", type=float, default=12.0)
    r.add_argument("--seed", type=int, default=7)
    r.add_argument("--plot"); r.add_argument("--metrics"); r.add_argument("--save")
    r.set_defaults(func=_run)

    b = sub.add_parser("benchmark")
    b.add_argument("--plant", default="dc", choices=plant_ids())
    b.add_argument("--scenario", default="staircase", choices=scenario_names())
    b.add_argument("--scheme", default="iaic")
    b.add_argument("--dt", type=float, default=0.1)
    b.add_argument("--duration", type=float, default=12.0)
    b.add_argument("--seeds", default="0-5")
    b.set_defaults(func=_benchmark)

    args = ap.parse_args()
    args.func(args)


if __name__ == "__main__":
    main()
