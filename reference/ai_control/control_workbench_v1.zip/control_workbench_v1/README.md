# Adaptive Inverse Control Workbench

An exploratory, part-time desktop/CLI workbench that implements the **Indirect
Learning Adaptive Inverse Control** scheme (ANN emulator + ANN inverse
controller) and applies it to a **DC motor**, with a plugin architecture so other
plants (an **induction motor** is included) and other schemes (a **PID baseline**
is included) drop in without touching the GUI. A first EV/DC drive extension adds
a battery + simplified boost converter + vehicle load and reports standard EV
energy metrics.

> **Status.** Concept prototype, not a validated simulator. The plant models are
> control-level and approximate; the intended direction is high-fidelity physics
> in MATLAB/Simulink behind the same `Plant` interface.

## Install & run

```bash
pip install -r requirements.txt   # numpy, matplotlib (tkinter ships with Python)
python main.py                    # launch the GUI
```

Pick a plant and scenario, then **Play** (step by step) or **Run all**. Switch the
active scheme to compare `iaic` against `pid` in the table.

## Headless examples

```bash
python cli.py run --plant dc --scenario multistep --schemes iaic pid --plot out.png --metrics m.csv
python cli.py run --plant im --scenario multistep --schemes iaic pid
python cli.py benchmark --plant dc --scenario staircase --scheme iaic --seeds 0-5
```

## The method in one paragraph

The **emulator** (ANN 2) learns the plant's forward dynamics so its prediction
error `e* = y − ŷ → 0`. The **controller** (ANN 1) has no target of its own, so
its tracking error `e = r − y` is back-propagated **through the emulator**, which
supplies `∂ŷ/∂u`. Both nets train off-line and then keep adapting on-line. The
networks see the measured state (speed and current) and are asked for a reachable
one-step reference-model target, so the inverse stays well-conditioned.

## Extending

Add a plant / scheme / scenario / exporter = one small class or function plus a
one-line import in `bootstrap.py`. The GUI updates itself. See **ARCHITECTURE.md**.
