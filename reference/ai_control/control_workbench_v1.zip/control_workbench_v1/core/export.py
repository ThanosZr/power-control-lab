"""Exporters. Each self-registers so it appears in the GUI export menu and the
CLI. Add a format = one decorated function."""
from __future__ import annotations

import csv
import json

from core.registry import register_exporter
from core.render import render_signals


@register_exporter("Signals (CSV)", "csv")
def export_signals_csv(session, path: str, scheme_id: str = "iaic") -> None:
    scheme = session.schemes.get(scheme_id) or next(iter(session.schemes.values()))
    log = scheme.log
    preferred = ["t", "r", "y", "u", "e", "e_star", "y_hat", "i_arm",
                 "current", "torque", "load_torque", "soc_pct", "v_bat",
                 "i_bat", "p_bat_W", "energy_kwh", "distance_km",
                 "km_per_kwh_live", "wh_per_km_live", "nm_per_kw_live"]
    keys = [k for k in preferred if log.get(k)]
    keys += [k for k in sorted(log.keys()) if k not in keys and log.get(k)]
    n = min(len(log[k]) for k in keys) if keys else 0
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(keys)
        for k in range(n):
            w.writerow([f"{log[c][k]:.6f}" for c in keys])


@register_exporter("Metrics table (CSV)", "csv")
def export_metrics_csv(session, path: str) -> None:
    rows = session.comparison_rows()
    cols = ["scheme", "variant", "plant", "rmse", "gap_pct", "sse",
            "overshoot_pct", "control_effort", "km_per_kwh", "wh_per_km",
            "nm_per_kw", "rms_current_a", "final_soc_pct", "soc_drop_pctpts",
            "peak_torque_nm", "mean_v_sag", "sim_steps", "grad_updates", "ms"]
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(cols)
        for r in rows:
            w.writerow([r.get(c, "") for c in cols])


@register_exporter("Signal plot (PNG)", "png")
def export_plot_png(session, path: str, scheme_id: str = "iaic", layer_on=None) -> None:
    import matplotlib
    matplotlib.use("Agg", force=False)
    from matplotlib.figure import Figure
    scheme = session.schemes.get(scheme_id) or next(iter(session.schemes.values()))
    fig = Figure(figsize=(9, 7), dpi=130)
    render_signals(fig, scheme, layer_on=layer_on)
    fig.savefig(path, bbox_inches="tight")


@register_exporter("Session (JSON)", "json")
def export_session_json(session, path: str) -> None:
    with open(path, "w", encoding="utf-8") as f:
        json.dump(session.to_dict(), f, indent=2)
