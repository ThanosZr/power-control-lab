# How to Run — EVDC Control Workbench

This guide explains how to run the first EV/DC extension of the control workbench.

The project includes a simplified EV-style simulation stack:

```text
Battery + simplified buck/boost converter + DC motor + variable load + EV metrics
```

The main EV plant is:

```text
evdc
```

The main EV scenario is:

```text
urban
```

---

## 1. Open a terminal in the project folder

Example on Windows:

```bat
cd C:\Users\Thanos_Z\Desktop\control_workbench_evdc_v0_2
```

or, if you renamed/extracted a newer folder:

```bat
cd C:\Users\Thanos_Z\Desktop\control_workbench_evdc_v0_3
```

---

## 2. Install requirements

Run:

```bat
pip install -r requirements.txt
```

Expected dependencies are minimal:

```text
numpy
matplotlib
```

If Anaconda already has them installed, you may see messages like:

```text
Requirement already satisfied
```

That is fine.

---

## 3. Check that the EVDC plant exists

Before running the GUI, check that the folder contains the new EV plant file.

Run:

```bat
dir plants
```

You should see at least:

```text
ev_dc_drive.py
dc_motor.py
induction_motor.py
__init__.py
```

If `ev_dc_drive.py` is missing, then you are running an incomplete or older extracted folder. Extract the latest zip again and run from the correct directory.

---

## 4. Run diagnostics

Run:

```bat
python diagnose.py
```

This checks that the important modules can be imported and that the local project path is being resolved correctly.

If this fails with something like:

```text
ModuleNotFoundError: No module named 'plants.ev_dc_drive'
```

then Python cannot see the EVDC plant file. Check step 3 again.

---

## 5. Smoke test without GUI

Before opening the GUI, run a short command-line simulation.

Run:

```bat
python cli.py run --plant evdc --scenario urban --schemes pid --duration 2 --dt 0.1 --metrics ev_metrics.csv --plot ev_plot.png
```

This should create two files in the project folder:

```text
ev_metrics.csv
ev_plot.png
```

The CSV contains summary metrics such as:

```text
km/kWh
Wh/km
Nm/kW
RMS current
SOC drop
final SOC
battery voltage sag
peak torque
```

The PNG contains a quick plot of the run.

---

## 6. Run a longer comparison from CLI

Example with both PID and IAIC schemes:

```bat
python cli.py run --plant evdc --scenario urban --schemes iaic pid --duration 8 --dt 0.1 --metrics ev_metrics.csv --plot ev_plot.png
```

Use this when you want quick results without opening the GUI.

---

## 7. Open the GUI

Run:

```bat
python main.py
```

Then select:

```text
Plant    = evdc
Scenario = urban
Scheme   = pid or iaic
```

Recommended first GUI run:

```text
Plant    = evdc
Scenario = urban
Scheme   = pid
```

Then compare with:

```text
Scheme = iaic
```

---

## 8. What the EVDC extension models

The EVDC plant is not a detailed transistor-level converter simulation. It is a control-level EV/DC model intended for fast controller experiments.

It includes:

- battery open-circuit voltage affected by SOC,
- internal resistance and voltage sag,
- simplified buck/boost converter voltage envelope,
- DC motor armature dynamics,
- variable external load torque,
- rolling resistance,
- aerodynamic drag,
- road grade disturbance,
- distance integration,
- energy integration,
- EV metrics such as km/kWh and Nm/kW.

---

## 9. Important metrics

### km/kWh

Energy efficiency of the simulated drive:

```text
km/kWh = distance travelled / battery energy used
```

Higher is better.

### Wh/km

Energy consumption per distance:

```text
Wh/km = battery energy used / distance travelled
```

Lower is better.

### Nm/kW

Torque produced per electrical battery power:

```text
Nm/kW = motor torque / battery power in kW
```

This helps compare how much torque the system produces for each kW drawn from the battery.

### RMS current

Higher RMS current usually means higher copper and battery losses.

### SOC drop

How much battery state-of-charge was consumed during the run.

### Voltage sag

The drop between open-circuit battery voltage and loaded terminal voltage due to internal resistance.

---

## 10. Common issue: missing EVDC plant

Error:

```text
ModuleNotFoundError: No module named 'plants.ev_dc_drive'
```

Cause:

```text
plants/ev_dc_drive.py is missing from the extracted project folder.
```

Fix:

1. Delete or ignore the incomplete folder.
2. Extract the latest zip again.
3. Open a terminal inside the extracted project folder.
4. Run:

```bat
dir plants
```

Confirm that this file exists:

```text
ev_dc_drive.py
```

Then rerun:

```bat
python diagnose.py
```

and then:

```bat
python main.py
```

---

## 11. Recommended first workflow

Run these commands in order:

```bat
pip install -r requirements.txt
```

```bat
dir plants
```

```bat
python diagnose.py
```

```bat
python cli.py run --plant evdc --scenario urban --schemes pid --duration 2 --dt 0.1 --metrics ev_metrics.csv --plot ev_plot.png
```

```bat
python main.py
```

---

## 12. Project direction

This EVDC version is the first step toward a multi-objective AI control workbench.

Current focus:

```text
battery + converter envelope + DC motor + variable load + EV metrics
```

Next possible extensions:

- SOC-aware supervisory controller,
- harmonic/ripple compensation module,
- multi-stage ANN emulator/inverse controller pairs,
- Pareto plots for torque/kW vs km/kWh,
- Eco / Balanced / Performance modes,
- MATLAB/Simulink export or parallel validation.

---

## v0.4 GUI EV/DC controls

In v0.4 the GUI exposes more than the live target speed `ω`.

Under **Scheme control** you should see:

```text
EV/DC plant variables — applied on Rebuild
```

You can change:

```text
SOC0 %
payload kg
grade %
grade ripple %
capacity Ah
load base Nm
load amp Nm
boost max
Vout max V
```

These are plant parameters, not live controller references. After changing them, press:

```text
Apply/Rebuild
```

or the top:

```text
Rebuild
```

Then run/train the controller again.

The live `target ω [rad/s]` slider still exists, but it only changes the online speed target in live run mode. The new EV/DC panel changes the battery/load/converter operating condition so you can compare `km/kWh`, `Wh/km`, `Nm/kW`, RMS current and SOC drop across scenarios.

### Example CLI run with EV/DC parameter overrides

```bat
python cli.py run --plant evdc --scenario urban --schemes pid --duration 8 --dt 0.1 --soc0 60 --payload 40 --grade 3 --load-amp 0.8 --boost 1.6 --vout-max 90 --metrics ev_metrics.csv --plot ev_plot.png
```

---

## Grade-adaptive EV speed target

v0.6 adds a new scenario:

```text
grade_adaptive
```

This scenario still creates a normal speed target `ω_ref`, but it shapes the
mission target using the route grade. Uphill sections reduce the desired speed
slightly, downhill sections allow mild recovery, and low SOC applies a small
derating.

Run it from CLI:

```bat
python cli.py run --plant evdc --scenario grade_adaptive --schemes pid --duration 8 --dt 0.1 --soc0 55 --payload 35 --grade 4 --grade-amp 2.5 --metrics grade_metrics.csv --plot grade_plot.png
```

In the GUI:

1. Select `Plant = evdc`.
2. Select `Scenario = grade_adaptive`.
3. Change `grade %`, `grade ripple %`, `SOC0 %`, payload, and load settings.
4. Press `Apply/Rebuild`.
5. Run `pid` or `iaic`.
6. Compare `km/kWh`, `Wh/km`, `Nm/kW`, `SOC%`, `Irms`, and tracking error.

Important distinction:

- `grade_adaptive` changes the **reference target**.
- The `evdc` plant still computes the **actual road load** from grade, payload,
  rolling resistance, aero drag, and variable load torque.

So the controller is not being helped by fake physics; it is following a more
realistic mission command while the plant remains constrained by battery,
converter, motor, and load limits.


## v0.6 vehicle settings

The GUI now includes a **Vehicle settings** button. Use it to configure vehicle mass, wheel radius, gear ratio, drivetrain efficiency, rolling resistance, CdA, target max speed, and route/load periods. Press **Apply & rebuild** after changing these values.

Useful presets are included: **Eco prototype**, **Urban kart**, and **RC toy**. For this project, **Eco prototype** or **Urban kart** are better starting points when you want the animation and metrics to feel like a real lightweight EV rather than a small model car.

CLI example with explicit vehicle scale:

```bat
python cli.py run --plant evdc --scenario grade_adaptive --schemes pid --duration 8 --dt 0.1 --soc0 55 --payload 35 --grade 4 --grade-amp 2.5 --vehicle-mass 115 --wheel-radius 0.255 --gear 7 --target-vmax 45 --metrics grade_metrics.csv --plot grade_plot.png
```


## v0.7 multi-objective controller

The workbench now includes a first real multi-objective control scheme: `moev` / **Multi-objective EV cascade**.  It adds an outer speed loop, an inner torque-current loop, and a battery/SOC energy supervisor.  This is different from earlier versions where EV quantities such as torque, SOC and km/kWh were mainly metrics around a single speed loop.

Example:

```bash
python cli.py run --plant evdc --scenario grade_adaptive --schemes moev pid --duration 8 --dt 0.1 --soc0 55 --payload 35 --grade 4 --grade-amp 2.5 --metrics multiobj_metrics.csv --plot multiobj_plot.png
```

## v0.10 live vehicle speed target

In the GUI, `Run · live target` now supports two synchronized target sliders:

```text
motor target omega [rad/s]
vehicle target speed [km/h]
```

For the EV/DC plant, use `vehicle target speed [km/h]` when you want to think like a vehicle simulation. The controller still receives motor omega internally, using:

```text
omega_motor = vehicle_speed_kph / 3.6 * gear_ratio / wheel_radius
```

Do not confuse this with `target max speed km/h` in Vehicle Settings. That parameter only scales scenario references such as `urban` and `grade_adaptive`; it is not the live target slider.

## v0.15 straight-line harmonic sanity test

harmonic-compensation validation is typically closer to a fixed operating point than to a varying grade route. For debugging the Python harmonic model, run a straight/flat mission:

```bat
python cli.py run --plant spmsm_harm --scenario straight_flat --schemes hinj --duration 8 --dt 0.02 --soc0 70 --grade 0 --grade-amp 0 --load-amp 0 --vehicle-mass 115 --wheel-radius 0.255 --gear 7 --target-vmax 45 --harmonic-gain 1.0 --metrics test_v15_on.csv --plot test_v15_on.png
```

OFF comparison:

```bat
python cli.py run --plant spmsm_harm --scenario straight_flat --schemes hinj --duration 8 --dt 0.02 --soc0 70 --grade 0 --grade-amp 0 --load-amp 0 --vehicle-mass 115 --wheel-radius 0.255 --gear 7 --target-vmax 45 --harmonic-off --metrics test_v15_off.csv --plot test_v15_off.png
```

Look at:

```text
settled_current_thd_raw_proxy
settled_current_thd_residual_proxy
mean_harmonic_cancellation_pct
```

These are Python proxies. Real current THD requires three-phase current FFT in MATLAB/Simulink or measured data.

---

## v0.16 harmonic-injection sanity test

For harmonic injection, first use a straight-line test. This removes road-grade/load oscillations so you can verify the harmonic branch itself.

ON:

```bat
python cli.py run --plant spmsm_harm --scenario straight_flat --schemes hinj --duration 8 --dt 0.02 --soc0 70 --grade 0 --grade-amp 0 --load-amp 0 --vehicle-mass 115 --wheel-radius 0.255 --gear 7 --target-vmax 45 --harmonic-gain 1.0 --metrics v16_on.csv --plot v16_on.png
```

OFF:

```bat
python cli.py run --plant spmsm_harm --scenario straight_flat --schemes hinj --duration 8 --dt 0.02 --soc0 70 --grade 0 --grade-amp 0 --load-amp 0 --vehicle-mass 115 --wheel-radius 0.255 --gear 7 --target-vmax 45 --harmonic-off --metrics v16_off.csv --plot v16_off.png
```

Trust these metrics first:

```text
settled_current_thd_residual_proxy
mean_harmonic_loss_residual_W
rms_current_harmonic_torque_ripple_nm
```

In the GUI, use the **same-state A/B** lines. They compare ON and OFF at the same plant state. Do not use cumulative `km/kWh` snapshots after toggling, because they include the whole previous transient history.
