"""Armature-circuit view with animated current flow.

Draws the motor's electrical loop — supply voltage u, armature resistance R,
inductance L and the back-EMF / rotor — and animates carriers (dots) moving
around the loop. The dots' speed and direction follow the live armature current
(sign = direction, magnitude = how fast/how many), so the picture literally
shows "current flowing" and reverses when the motor regenerates.

`draw_circuit(ax, viz, phase)` — `viz` is the plant's `viz_state()` (current,
voltage, back_emf, speed, i_max); `phase` is an animation cursor in [0, 1) that
the GUI advances each frame by an amount proportional to the current.
"""
from __future__ import annotations

import math
from typing import Dict, List, Tuple

import numpy as np
from matplotlib.patches import Circle, FancyBboxPatch

# Rectangular loop corners (the wire path), counter-clockwise from bottom-left.
_LOOP = [(1.0, 1.0), (9.0, 1.0), (9.0, 5.0), (1.0, 5.0)]


def _perimeter_points(n: int, phase: float) -> List[Tuple[float, float]]:
    """n points equally spaced (by arc length) around the loop, offset by phase."""
    pts = _LOOP + [_LOOP[0]]
    seg_len = [math.hypot(pts[i + 1][0] - pts[i][0], pts[i + 1][1] - pts[i][1])
               for i in range(len(pts) - 1)]
    total = sum(seg_len)
    out = []
    for k in range(n):
        d = ((k / n) + phase) % 1.0 * total
        for i, L in enumerate(seg_len):
            if d <= L:
                f = d / L
                out.append((pts[i][0] + f * (pts[i + 1][0] - pts[i][0]),
                            pts[i][1] + f * (pts[i + 1][1] - pts[i][1])))
                break
            d -= L
    return out


def _resistor(ax, x0, x1, y, color="#333"):
    n = 6
    xs = np.linspace(x0, x1, 2 * n + 1)
    ys = [y + (0.18 if i % 2 else -0.18) if 0 < i < 2 * n else y
          for i in range(len(xs))]
    ax.plot(xs, ys, color=color, lw=1.8, zorder=3)


def _inductor(ax, x0, x1, y, color="#333"):
    xs = np.linspace(x0, x1, 60)
    loops = 4
    ys = y + 0.18 * np.abs(np.sin(np.linspace(0, loops * math.pi, 60)))
    ax.plot(xs, ys, color=color, lw=1.8, zorder=3)


def draw_circuit(ax, viz: Dict[str, float], phase: float = 0.0) -> None:
    viz = viz or {}
    i = viz.get("current", 0.0)
    v = viz.get("voltage", 0.0)
    bemf = viz.get("back_emf", 0.0)
    spd = viz.get("speed", 0.0)
    i_max = max(viz.get("i_max", 1.0), 1e-6)

    ax.clear()
    ax.set_xlim(0, 10); ax.set_ylim(0, 6)
    ax.set_aspect("equal", adjustable="box"); ax.axis("off")
    ax.set_title("Armature circuit — current flow", fontsize=11)

    # wires (the four sides; leave gaps where components sit)
    ax.plot([1, 1], [1, 5], color="#333", lw=1.8, zorder=2)          # left (source)
    ax.plot([1, 3], [5, 5], color="#333", lw=1.8, zorder=2)          # top to R
    _resistor(ax, 3, 4.6, 5)
    ax.plot([4.6, 5.2], [5, 5], color="#333", lw=1.8, zorder=2)
    _inductor(ax, 5.2, 7.0, 5)
    ax.plot([7.0, 9], [5, 5], color="#333", lw=1.8, zorder=2)        # to motor
    ax.plot([9, 9], [5, 3.6], color="#333", lw=1.8, zorder=2)        # right top
    ax.plot([9, 9], [2.4, 1], color="#333", lw=1.8, zorder=2)        # right bottom
    ax.plot([1, 9], [1, 1], color="#333", lw=1.8, zorder=2)          # bottom

    # voltage source (left side) -------------------------------------------
    ax.plot([0.7, 1.3], [3.3, 3.3], color="#333", lw=2.6, zorder=4)  # + long
    ax.plot([0.82, 1.18], [2.7, 2.7], color="#333", lw=1.4, zorder=4)  # − short
    ax.text(0.45, 3.3, "+", fontsize=12, ha="center"); ax.text(0.45, 2.7, "−", fontsize=12, ha="center")
    ax.text(1.7, 3.0, f"u = {v:+.1f} V", fontsize=9, color="#1f77b4", weight="bold")

    # component labels
    ax.text(3.8, 5.45, "R", fontsize=10, ha="center")
    ax.text(6.1, 5.55, "L", fontsize=10, ha="center")

    # motor / back-EMF (right side) ----------------------------------------
    ax.add_patch(Circle((9, 3.0), 0.6, fc="#fff7e6", ec="#333", lw=1.8, zorder=4))
    ax.text(9, 3.0, "M", fontsize=13, ha="center", va="center", weight="bold", zorder=5)
    ax.text(9.85, 3.0, f"E = {bemf:+.1f} V\nω = {spd:+.1f}", fontsize=8.5, va="center")

    # current carriers ------------------------------------------------------
    mag = abs(i) / i_max
    n_dots = int(6 + 26 * min(mag, 1.0))
    intensity = min(1.0, 0.25 + mag)
    col = (0.85 * intensity, 0.12, 0.12) if i >= 0 else (0.12, 0.25, 0.85 * intensity)
    for (px, py) in _perimeter_points(n_dots, phase):
        ax.add_patch(Circle((px, py), 0.07 + 0.05 * mag, fc=col, ec="none", zorder=6))

    arrow = "→ flow" if i >= 0 else "← flow (regen)"
    ax.text(5, 0.55, f"i = {i:+.2f} A    {arrow}", fontsize=10,
            ha="center", color=col, weight="bold")
