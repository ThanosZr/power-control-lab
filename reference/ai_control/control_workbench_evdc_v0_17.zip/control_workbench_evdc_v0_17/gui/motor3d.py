"""3-D motor view — a rotor that actually spins at the controlled speed.

`draw_motor3d(ax, viz, angle)` renders a shaft + rotor cylinder inside a stator
ring on a 3-D axes. `angle` is the integrated shaft angle θ (the GUI advances it
by ω·dt each frame), so the painted vane rotates and you see the speed the
controller is holding; the rotor colour tracks speed sign, and a torque arc
hints at the current. Kept to surfaces/lines that render fine under Agg too.
"""
from __future__ import annotations

import math
from typing import Dict

import numpy as np


def _cylinder(ax, x0, x1, radius, color, alpha=0.9, n=40):
    th = np.linspace(0, 2 * np.pi, n)
    xs = np.array([x0, x1])
    X, T = np.meshgrid(xs, th)
    Y = radius * np.cos(T)
    Z = radius * np.sin(T)
    ax.plot_surface(X, Y, Z, color=color, alpha=alpha, linewidth=0,
                    antialiased=True, shade=True)


def _disc(ax, x, radius, color, alpha=0.9, n=40):
    th = np.linspace(0, 2 * np.pi, n)
    r = np.linspace(0, radius, 6)
    T, R = np.meshgrid(th, r)
    Y = R * np.cos(T); Z = R * np.sin(T)
    X = np.full_like(Y, x)
    ax.plot_surface(X, Y, Z, color=color, alpha=alpha, linewidth=0, antialiased=True)


def draw_motor3d(ax, viz: Dict[str, float], angle: float = 0.0) -> None:
    viz = viz or {}
    spd = viz.get("speed", 0.0)
    cur = viz.get("current", 0.0)
    torque = viz.get("torque", 0.0)

    ax.clear()
    ax.set_box_aspect((2.2, 1, 1))
    ax.set_xlim(-1.6, 1.6); ax.set_ylim(-1.1, 1.1); ax.set_zlim(-1.1, 1.1)
    ax.set_xticks([]); ax.set_yticks([]); ax.set_zticks([])
    ax.set_title("3-D rotor", fontsize=11)

    # stator: translucent outer shell + end rings
    _cylinder(ax, -0.95, 0.95, 1.0, "#9fb6d4", alpha=0.12, n=48)
    for xe in (-0.95, 0.95):
        th = np.linspace(0, 2 * np.pi, 60)
        ax.plot(np.full_like(th, xe), 1.0 * np.cos(th), 1.0 * np.sin(th),
                color="#5f6f86", lw=1.2)

    # rotor colour by speed direction/magnitude
    sp = min(abs(spd) / 20.0, 1.0)
    rotor_col = (0.20 + 0.6 * sp, 0.30, 0.30) if spd >= 0 else (0.25, 0.35, 0.25 + 0.6 * sp)
    _cylinder(ax, -0.7, 0.7, 0.55, rotor_col, alpha=0.95)
    _disc(ax, 0.7, 0.55, rotor_col, alpha=0.95)
    _disc(ax, -0.7, 0.55, rotor_col, alpha=0.95)

    # shaft
    _cylinder(ax, -1.5, 1.5, 0.1, "#444", alpha=1.0, n=20)

    # rotating vanes on the front face so the spin is visible
    for k in range(4):
        a = angle + k * math.pi / 2
        ys = [0.12 * math.cos(a), 0.55 * math.cos(a)]
        zs = [0.12 * math.sin(a), 0.55 * math.sin(a)]
        ax.plot([0.71, 0.71], ys, zs, color="#ffd23f", lw=3)
    # a single bold marker vane to read direction
    ax.plot([0.72, 0.72], [0, 0.7 * math.cos(angle)], [0, 0.7 * math.sin(angle)],
            color="#111", lw=2.5)

    # torque/current hint: arc whose extent ~ |current|
    i_max = max(viz.get("i_max", 1.0), 1e-6)
    frac = min(abs(cur) / i_max, 1.0)
    arc = np.linspace(0, 2 * np.pi * frac, 40) * (1 if torque >= 0 else -1)
    ax.plot(np.full_like(arc, 0.95), 0.85 * np.cos(arc), 0.85 * np.sin(arc),
            color="#d62728", lw=2.5)

    v_kph = viz.get("vehicle_speed_kph", None)
    vline = "" if v_kph is None else f"\nv = {v_kph:+.1f} km/h"
    ax.text2D(0.02, 0.95, f"ω = {spd:+.2f} rad/s{vline}\ni = {cur:+.2f} A\nτ = {torque:+.3f} N·m",
              transform=ax.transAxes, fontsize=9, va="top")
    ax.view_init(elev=22, azim=-60)
