"""Live control diagrams for the workbench.

The original project used an Adaptive Inverse Control diagram:

    r -> Σ -> ANN inverse -> plant -> y
                 |          
                 v
              ANN emulator

The EV/DC extension adds real multi-loop schemes (``moev`` and ``moevc``).
For those schemes this module draws the active cascaded loops instead of the
old ANN-only picture:

    mission speed -> reference governor -> speed loop -> torque demand
        -> SOC/power allocator -> current/torque loop -> EV plant

This keeps the first GUI tab honest: the active loops depend on the selected
scheme.
"""
from __future__ import annotations

from typing import Dict, Optional

from matplotlib.patches import Circle, FancyArrowPatch, FancyBboxPatch


def _box(ax, x, y, w, h, text, fc, ec="#333", fs=10):
    ax.add_patch(FancyBboxPatch((x, y), w, h,
                                boxstyle="round,pad=0.02,rounding_size=0.06",
                                fc=fc, ec=ec, lw=1.6, zorder=3))
    ax.text(x + w / 2, y + h / 2, text, ha="center", va="center",
            fontsize=fs, zorder=4, weight="bold")


def _sum(ax, x, y, r=0.20):
    ax.add_patch(Circle((x, y), r, fc="white", ec="#333", lw=1.6, zorder=3))
    ax.text(x, y, "Σ", ha="center", va="center", fontsize=11, zorder=4)


def _arrow(ax, p0, p1, color="#333", style="-", lw=1.6, zorder=2):
    ax.add_patch(FancyArrowPatch(p0, p1, arrowstyle="-|>", mutation_scale=14,
                                 color=color, lw=lw, linestyle=style, zorder=zorder))


def _sig(ax, x, y, name, val, color="#0b6", fmt="+.2f"):
    ax.text(x, y + 0.16, name, ha="center", va="bottom", fontsize=8.5,
            color=color, weight="bold", zorder=5)
    if val is None:
        txt = "—"
    else:
        try:
            txt = ("{:" + fmt + "}").format(float(val))
        except Exception:
            txt = str(val)
    ax.text(x, y - 0.18, txt, ha="center", va="top", fontsize=8.0,
            color="#222", zorder=5)


def _fmt(val: Optional[float], unit: str = "") -> str:
    if val is None:
        return "—"
    try:
        return f"{float(val):.2f}{unit}"
    except Exception:
        return str(val)


def draw_diagram(ax, signals: Dict[str, float]) -> None:
    """Draw the appropriate live diagram for the selected scheme."""
    s = signals or {}
    scheme_id = str(s.get("scheme_id", "")).lower()
    if scheme_id == "hinj":
        _draw_harmonic_multiloop(ax, s)
    elif scheme_id in {"moev", "moevc"}:
        _draw_ev_multiloop(ax, s, coupled=(scheme_id == "moevc"))
    else:
        _draw_inverse_ann(ax, s)


def _draw_inverse_ann(ax, s: Dict[str, float]) -> None:
    r = s.get("r", 0.0); u = s.get("u", 0.0); y = s.get("y", 0.0)
    yh = s.get("y_hat", 0.0); e = s.get("e", 0.0); es = s.get("e_star", 0.0)

    ax.clear()
    ax.set_xlim(0, 10.5); ax.set_ylim(0, 6.2)
    ax.set_aspect("equal", adjustable="box"); ax.axis("off")
    ax.set_title("Adaptive inverse control — ANN emulator + inverse loop", fontsize=11)

    # main forward path -----------------------------------------------------
    ax.text(0.35, 4.6, "reference", fontsize=8.5, color="#0b6", ha="center")
    _arrow(ax, (0.35, 4.3), (1.55, 4.3))
    _sig(ax, 0.95, 4.3, "r", r)
    _sum(ax, 1.8, 4.3)
    ax.text(1.55, 4.62, "+", fontsize=11)
    ax.text(1.62, 3.92, "−", fontsize=13)
    _arrow(ax, (2.02, 4.3), (3.1, 4.3))
    _sig(ax, 2.55, 4.3, "e", e, color="#d62728")
    _box(ax, 3.1, 3.8, 1.9, 1.0, "ANN 1\ncontroller  F⁻¹", "#ffe0e0")
    _arrow(ax, (5.0, 4.3), (6.2, 4.3))
    _sig(ax, 5.6, 4.3, "u", u, color="#1f77b4")
    _box(ax, 6.2, 3.8, 1.9, 1.0, "System  F\n(motor)", "#e3eefc")
    _arrow(ax, (8.1, 4.3), (9.7, 4.3))
    _sig(ax, 9.0, 4.3, "y", y)
    ax.add_patch(Circle((9.7, 4.3), 0.04, fc="#333"))

    # feedback y -> Σ -------------------------------------------------------
    ax.plot([9.7, 9.7], [4.3, 0.7], color="#333", lw=1.4, zorder=1)
    ax.plot([9.7, 1.8], [0.7, 0.7], color="#333", lw=1.4, zorder=1)
    _arrow(ax, (1.8, 0.7), (1.8, 4.08))

    # emulator branch -------------------------------------------------------
    ax.plot([5.6, 5.6], [4.3, 2.4], color="#1f77b4", lw=1.3, zorder=1)
    _arrow(ax, (5.6, 2.4), (6.2, 2.4))
    _box(ax, 6.2, 1.9, 1.9, 1.0, "ANN 2\nemulator", "#eee0ff")
    _arrow(ax, (8.1, 2.4), (9.0, 2.4))
    _sig(ax, 8.55, 2.4, "ŷ", yh, color="#9467bd")
    _sum(ax, 9.25, 2.4)
    ax.text(9.0, 2.72, "+", fontsize=10)
    ax.plot([9.7, 9.25], [3.2, 3.2], color="#333", lw=1.2, zorder=1)
    _arrow(ax, (9.25, 3.2), (9.25, 2.62))
    ax.text(9.35, 2.95, "y", fontsize=8.5)
    _arrow(ax, (9.47, 2.4), (10.1, 2.4))
    _sig(ax, 9.9, 2.4, "e*", es, color="#e67700")
    ax.text(8.1, 1.4, "e* trains ANN 2  (e* = y − ŷ)", fontsize=8, color="#e67700")

    _draw_ev_panel(ax, s, x=0.35, y=1.05, w=4.65, h=1.45)

    # indirect training path: e back-propagated through ANN2 into ANN1 ------
    _arrow(ax, (7.15, 1.9), (4.05, 3.8), color="#d62728", style=(0, (4, 3)), lw=1.3)
    ax.text(5.0, 2.2, "∂ŷ/∂u  back-prop\n(e through ANN 2 → ANN 1)",
            fontsize=8, color="#d62728", ha="center")



def _draw_harmonic_multiloop(ax, s: Dict[str, float]) -> None:
    """Draw coupled EV loops plus a harmonic-injection feed-forward branch."""
    _draw_ev_multiloop(ax, s, coupled=True)
    ax.set_title("SPMSM harmonic injection — speed + torque loops + v_harm feed-forward", fontsize=11)

    # Add harmonic compensator branch on top of the generic coupled diagram.
    eh = s.get("bemf_harmonic", None)
    uh = s.get("u_harm", None)
    theta = s.get("theta_e", None)
    _box(ax, 0.35, 2.10, 2.25, 0.82, "Harmonic model\nθe, ω → v_harm", "#f6e8ff", fs=8.2)
    _sig(ax, 1.45, 1.92, "e_h", eh, color="#9467bd")
    _sig(ax, 2.42, 1.92, "u_harm", uh, color="#9467bd")
    ax.text(0.45, 1.55, "v_total = v_base + v_harm", fontsize=7.5, color="#5e3a8a")
    _arrow(ax, (2.60, 2.51), (5.00, 3.66), color="#9467bd", style=(0, (4, 3)), lw=1.25)
    ax.text(3.75, 2.70, "harmonic\ninjection", fontsize=7.2, color="#9467bd", ha="center")
    # feedback from plant angle/speed to harmonic model
    ax.plot([1.40, 1.40], [3.55, 2.92], color="#9467bd", lw=1.0, zorder=1)
    _arrow(ax, (1.40, 2.92), (1.40, 2.92), color="#9467bd", lw=1.0)
    if theta is not None:
        ax.text(0.48, 3.02, f"θe={_fmt(theta, 'rad')}", fontsize=7.0, color="#9467bd")

def _draw_ev_multiloop(ax, s: Dict[str, float], coupled: bool = True) -> None:
    """Draw the active speed/torque/energy loops for moev/moevc."""
    r_cmd = s.get("r_cmd", s.get("r", 0.0))
    r_gov = s.get("r", r_cmd)
    y = s.get("y", 0.0)
    e_w = s.get("e", 0.0)
    tau_req = s.get("tau_request", s.get("tau_raw", 0.0))
    tau_ref = s.get("tau_ref", 0.0)
    tau_meas = s.get("torque", 0.0)
    i_ref = s.get("i_ref", 0.0)
    i_meas = s.get("current", s.get("i_arm", 0.0))
    u = s.get("u", 0.0)
    soc = s.get("soc_pct", None)
    pbat = None if s.get("p_bat_W") is None else s.get("p_bat_W") / 1000.0
    constraint = s.get("constraint", s.get("constraint_active", 0.0))

    ax.clear()
    ax.set_xlim(0, 12.5); ax.set_ylim(0, 7.2)
    ax.set_aspect("equal", adjustable="box"); ax.axis("off")
    title = "Coupled multi-loop EV control — speed + torque/current + energy/SOC"
    if not coupled:
        title = "Multi-objective EV cascade — speed loop + torque/current loop + energy/SOC"
    ax.set_title(title, fontsize=11)

    # Row 1: mission/reference/speed loop ---------------------------------
    _box(ax, 0.35, 5.65, 1.45, 0.78, "Mission\nspeed target", "#e9f7ef", fs=8.5)
    _arrow(ax, (1.80, 6.04), (2.25, 6.04))
    _sig(ax, 2.02, 6.04, "ωcmd", r_cmd, color="#0b6")

    if coupled:
        _box(ax, 2.25, 5.65, 1.55, 0.78, "Reference\ngovernor", "#fff5cc", fs=8.5)
        _arrow(ax, (3.80, 6.04), (4.35, 6.04))
        _sig(ax, 4.05, 6.04, "ωgov", r_gov, color="#b8860b")
    else:
        ax.plot([2.25, 3.80], [6.04, 6.04], color="#333", lw=1.6)
        _arrow(ax, (3.80, 6.04), (4.35, 6.04))
        _sig(ax, 3.30, 6.04, "ωref", r_gov, color="#0b6")

    _sum(ax, 4.55, 6.04)
    ax.text(4.35, 6.34, "+", fontsize=10)
    ax.text(4.37, 5.70, "−", fontsize=12)
    _arrow(ax, (4.75, 6.04), (5.25, 6.04))
    _sig(ax, 5.00, 6.04, "eω", e_w, color="#d62728")
    _box(ax, 5.25, 5.65, 1.65, 0.78, "Outer speed\nloop", "#ffe0e0", fs=8.5)
    _arrow(ax, (6.90, 6.04), (7.45, 6.04))

    # Row 2: physical coupler and energy allocation ------------------------
    _box(ax, 7.45, 5.65, 1.65, 0.78, "Vehicle dynamics\ncoupler", "#e8f1ff", fs=8.1)
    ax.text(8.28, 5.28, "τreq = J·dω/dt + Bω + τload", fontsize=7.0,
            color="#333", ha="center")
    _arrow(ax, (9.10, 6.04), (9.65, 6.04))
    _sig(ax, 9.38, 6.04, "τreq", tau_req, color="#1f77b4")
    _box(ax, 9.65, 5.65, 1.90, 0.78, "SOC / power\nallocator", "#e6ffe6", fs=8.5)

    # constraints entering allocator
    ax.plot([10.60, 10.60], [4.50, 5.65], color="#0a7", lw=1.2, zorder=1)
    _arrow(ax, (10.60, 4.50), (10.60, 5.65), color="#0a7")
    ax.text(11.70, 4.60, f"SOC={_fmt(soc, '%')}\nPbat={_fmt(pbat, 'kW')}\nconstraint={int(float(constraint or 0))}",
            fontsize=7.0, color="#0a7", ha="right")

    _arrow(ax, (10.60, 5.65), (10.60, 4.25))
    _sig(ax, 10.60, 5.05, "τref", tau_ref, color="#ff7f0e")

    # Row 3: inner torque/current loop -------------------------------------
    _sum(ax, 10.60, 4.05)
    ax.text(10.37, 4.35, "+", fontsize=10)
    ax.text(10.42, 3.72, "−", fontsize=12)
    _arrow(ax, (10.40, 4.05), (9.60, 4.05))
    _sig(ax, 10.00, 4.05, "eτ", None if tau_ref is None or tau_meas is None else float(tau_ref) - float(tau_meas), color="#d62728")
    _box(ax, 7.55, 3.66, 2.05, 0.78, "Inner torque /\ncurrent loop", "#eee0ff", fs=8.3)
    _arrow(ax, (7.55, 4.05), (6.80, 4.05))
    _sig(ax, 7.15, 4.05, "iref", i_ref, color="#9467bd")
    _box(ax, 5.00, 3.66, 1.80, 0.78, "Voltage /\nconverter cmd", "#f0f0f0", fs=8.3)
    _arrow(ax, (5.00, 4.05), (4.35, 4.05))
    _sig(ax, 4.68, 4.05, "u", u, color="#1f77b4")
    _box(ax, 2.15, 3.55, 2.20, 1.00, "Battery + boost\nDC motor + vehicle", "#e3eefc", fs=8.5)
    _arrow(ax, (2.15, 4.05), (1.40, 4.05))
    _sig(ax, 1.72, 4.05, "ω", y, color="#0b6")

    # Feedbacks: speed to speed sum, torque/current to inner sum -----------
    ax.add_patch(Circle((1.40, 4.05), 0.04, fc="#333"))
    ax.plot([1.40, 1.40], [4.05, 1.00], color="#333", lw=1.2, zorder=1)
    ax.plot([1.40, 4.55], [1.00, 1.00], color="#333", lw=1.2, zorder=1)
    _arrow(ax, (4.55, 1.00), (4.55, 5.84), color="#333", lw=1.2)
    ax.text(2.50, 1.12, "speed feedback ω", fontsize=7.5, color="#333")

    ax.plot([3.25, 3.25], [3.55, 2.35], color="#9467bd", lw=1.2, zorder=1)
    ax.plot([3.25, 10.60], [2.35, 2.35], color="#9467bd", lw=1.2, zorder=1)
    _arrow(ax, (10.60, 2.35), (10.60, 3.85), color="#9467bd", lw=1.2)
    ax.text(6.60, 2.48, "torque/current feedback  τ=Kt·i", fontsize=7.5, color="#9467bd")

    # Plant load disturbances entering physical model -----------------------
    ax.plot([8.27, 8.27], [6.43, 6.95], color="#777", lw=1.1)
    _arrow(ax, (8.27, 6.95), (8.27, 6.43), color="#777", lw=1.1)
    ax.text(8.92, 6.78, f"grade={_fmt(s.get('grade_pct_live'), '%')}\nload={_fmt(s.get('load_torque'), 'Nm')}",
            fontsize=7.0, color="#555", ha="left", va="center")

    # Difference from old ANN picture --------------------------------------
    ax.text(0.35, 0.45,
            "This tab now shows the active selected control loops. ANN emulator/inverse pairs are the next training layer;\n"
            "the current MOEVC scheme is the deterministic coupled-loop scaffold they will replace module-by-module.",
            fontsize=7.4, color="#444", ha="left")

    _draw_ev_panel(ax, s, x=0.35, y=1.55, w=4.35, h=1.25, compact=True)


def _draw_ev_panel(ax, s: Dict[str, float], x: float, y: float, w: float, h: float, compact: bool = False) -> None:
    ev_keys = [
        ("SOC", s.get("soc_pct"), "%"),
        ("Vbat", s.get("v_bat"), "V"),
        ("Ibat", s.get("i_bat"), "A"),
        ("Pbat", None if s.get("p_bat_W") is None else s.get("p_bat_W") / 1000.0, "kW"),
        ("v", s.get("vehicle_speed_kph"), "km/h"),
        ("Grade", s.get("grade_pct_live"), "%"),
        ("Torque", s.get("torque"), "Nm"),
        ("Load", s.get("load_torque"), "Nm"),
        ("km/kWh", s.get("km_per_kwh_live"), ""),
        ("Nm/kW", s.get("nm_per_kw_live"), ""),
        ("Mass", s.get("vehicle_mass_total"), "kg"),
        ("vmax", s.get("target_vmax_kph"), "km/h"),
    ]
    if not any(v is not None for _, v, _ in ev_keys):
        return
    _box(ax, x, y, w, h, "", "#f5f5f5", ec="#777", fs=8)
    ax.text(x + 0.16, y + h - 0.24, "Control variables / EV metrics", fontsize=8.0,
            weight="bold", color="#333", ha="left")
    cols = 3 if compact else 4
    dx = w / cols
    dy = 0.30 if compact else 0.34
    for idx, (name, val, unit) in enumerate(ev_keys):
        row = idx // cols; col = idx % cols
        xx = x + 0.16 + col * dx; yy = y + h - 0.52 - row * dy
        ax.text(xx, yy, f"{name}: {_fmt(val, unit)}", fontsize=6.85 if compact else 7.25,
                ha="left", color="#222")
