"""The Tk workbench window for the control domain.

Like the TSP workbench it is generic: it discovers plants, schemes, scenarios,
their step graphs, their layers and their results through the registries and the
ControlScheme interface. Adding a plant / scheme / scenario / exporter needs
**no change here**.

Four synchronised views of the live loop:
  • Loop diagram — the slide, with signal values flowing
  • Circuit      — armature loop with animated current
  • 3-D motor    — rotor spinning at the controlled speed
  • Signals      — reference/output, error, control, emulator time-series
"""
from __future__ import annotations

import tkinter as tk
from tkinter import filedialog, messagebox, ttk
from tkinter import scrolledtext
from typing import Dict, List, Optional

import matplotlib
matplotlib.use("TkAgg")
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from matplotlib.figure import Figure

from core.registry import (exporters, plant_classes, scenario_names,
                           scheme_classes)
from core.render import render_signals
from core.scheme import DONE, LOCKED, READY, RUNNING, DrawContext
from core.session import Session
from gui.circuit import draw_circuit
from gui.diagram import draw_diagram
from gui.motor3d import draw_motor3d

STATUS_COLOR = {LOCKED: "#d9d9d9", READY: "#cfe3ff", RUNNING: "#fff1b8", DONE: "#c8efc8"}
STATUS_LABEL = {LOCKED: "LOCKED", READY: "READY", RUNNING: "RUNNING", DONE: "DONE"}

MODE_TRAIN = "Train (offline)"
MODE_RUN_REF = "Run · follow reference (loop)"
MODE_RUN_LIVE = "Run · live target"
MODES = [MODE_TRAIN, MODE_RUN_REF, MODE_RUN_LIVE]


class ControlWorkbenchGUI(tk.Tk):
    def __init__(self) -> None:
        super().__init__()
        self.title("Multi-Objective AI Control Workbench for Electric Drives")
        self.geometry("1600x980")

        # instance controls
        self.plant_var = tk.StringVar(value=plant_classes()[0].id)
        self.scenario_var = tk.StringVar(value="multistep")
        self.seed_var = tk.IntVar(value=7)
        self.dt_var = tk.DoubleVar(value=0.1)
        self.dur_var = tk.DoubleVar(value=12.0)

        self.active_scheme_var = tk.StringVar(value=scheme_classes()[0].id)
        self.speed_var = tk.IntVar(value=20)
        self.step_combo_var = tk.StringVar()
        self.live_var = tk.BooleanVar(value=False)
        # Live target is internally motor speed omega [rad/s]. For the EV/DC
        # plant the GUI also exposes the same target as vehicle speed [km/h].
        self.setpoint_var = tk.DoubleVar(value=0.0)
        self.vehicle_setpoint_kph = tk.DoubleVar(value=0.0)
        self.target_display_var = tk.StringVar(value="target: 0.00 rad/s = 0.0 km/h")
        self._syncing_targets = False
        self.mode_var = tk.StringVar(value=MODE_TRAIN)
        self.learn_var = tk.BooleanVar(value=True)

        # a few exposed scheme knobs (Settings)
        self.p_alpha = tk.DoubleVar(value=0.5)
        self.p_excite = tk.IntVar(value=2000)
        self.p_epochs_emu = tk.IntVar(value=80)
        self.p_epochs_ctrl = tk.IntVar(value=80)
        self.p_kp = tk.DoubleVar(value=2.5)
        self.p_ki = tk.DoubleVar(value=6.0)
        self.p_kd = tk.DoubleVar(value=0.05)

        # harmonic-injection scheme knobs (live for hinj, persisted on Rebuild)
        self.harmonic_enabled = tk.BooleanVar(value=True)
        self.harmonic_gain = tk.DoubleVar(value=1.0)
        self.harmonic_limit_v = tk.DoubleVar(value=18.0)

        # exposed EV/DC plant knobs (applied on Rebuild)
        self.ev_soc0_pct = tk.DoubleVar(value=85.0)
        self.ev_payload_kg = tk.DoubleVar(value=0.0)
        self.ev_grade_pct = tk.DoubleVar(value=0.0)
        self.ev_grade_amp_pct = tk.DoubleVar(value=1.5)
        self.ev_load_base_nm = tk.DoubleVar(value=0.05)
        self.ev_load_amp_nm = tk.DoubleVar(value=0.45)
        self.ev_boost_ratio = tk.DoubleVar(value=1.75)
        self.ev_vout_max = tk.DoubleVar(value=96.0)
        self.ev_capacity_ah = tk.DoubleVar(value=18.0)

        # vehicle-characteristic knobs (applied on Rebuild)
        self.ev_vehicle_mass_kg = tk.DoubleVar(value=115.0)
        self.ev_wheel_radius_m = tk.DoubleVar(value=0.255)
        self.ev_gear_ratio = tk.DoubleVar(value=7.0)
        self.ev_drivetrain_eta = tk.DoubleVar(value=0.92)
        self.ev_crr = tk.DoubleVar(value=0.012)
        self.ev_cda = tk.DoubleVar(value=0.32)
        self.ev_target_vmax_kph = tk.DoubleVar(value=45.0)
        self.ev_grade_period_m = tk.DoubleVar(value=90.0)
        self.ev_load_period_m = tk.DoubleVar(value=55.0)

        # runtime
        self.session: Optional[Session] = None
        self.layer_vars: Dict[str, tk.BooleanVar] = {}
        self.playing = False
        self.after_id: Optional[str] = None
        self.last_signals: Dict[str, float] = {}
        self.last_viz: Dict[str, float] = {}
        # Harmonic live ON/OFF memory.  When the user toggles injection during
        # live run, the state panel keeps the last observed values for both
        # states so the before/after comparison does not disappear.
        self.harmonic_snapshot_on: Dict[str, float] = {}
        self.harmonic_snapshot_off: Dict[str, float] = {}
        self.phase = 0.0       # circuit animation cursor
        self.angle = 0.0       # 3-D shaft angle

        self._build_layout()
        self.rebuild_session()

    # ================================================================== #
    def _build_layout(self) -> None:
        left = ttk.Frame(self); left.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        right = ttk.Frame(self, width=540); right.pack(side=tk.RIGHT, fill=tk.Y)
        right.pack_propagate(False)

        # ---- instance bar
        bar = ttk.Frame(left); bar.pack(side=tk.TOP, fill=tk.X, padx=8, pady=6)
        ttk.Label(bar, text="Plant").pack(side=tk.LEFT)
        ttk.Combobox(bar, textvariable=self.plant_var, state="readonly", width=22,
                     values=[c.id for c in plant_classes()]).pack(side=tk.LEFT, padx=3)
        ttk.Label(bar, text="Scenario").pack(side=tk.LEFT)
        ttk.Combobox(bar, textvariable=self.scenario_var, state="readonly", width=11,
                     values=scenario_names()).pack(side=tk.LEFT, padx=3)
        ttk.Label(bar, text="seed").pack(side=tk.LEFT)
        ttk.Spinbox(bar, from_=0, to=999999, textvariable=self.seed_var, width=7).pack(side=tk.LEFT, padx=3)
        ttk.Label(bar, text="dt").pack(side=tk.LEFT)
        ttk.Spinbox(bar, from_=0.01, to=0.5, increment=0.01, textvariable=self.dt_var, width=5).pack(side=tk.LEFT, padx=3)
        ttk.Label(bar, text="dur").pack(side=tk.LEFT)
        ttk.Spinbox(bar, from_=2, to=60, increment=1, textvariable=self.dur_var, width=5).pack(side=tk.LEFT, padx=3)
        ttk.Button(bar, text="Rebuild", command=self.rebuild_session).pack(side=tk.LEFT, padx=5)
        ttk.Button(bar, text="Settings", command=self.open_settings).pack(side=tk.LEFT, padx=2)
        ttk.Button(bar, text="Vehicle settings", command=self.open_vehicle_settings).pack(side=tk.LEFT, padx=2)
        ttk.Button(bar, text="❓ Help", command=self.open_help).pack(side=tk.LEFT, padx=8)

        # ---- scheme + step control
        ctrl = ttk.LabelFrame(left, text="Scheme control")
        ctrl.pack(side=tk.TOP, fill=tk.X, padx=8, pady=(0, 4))
        row1 = ttk.Frame(ctrl); row1.pack(side=tk.TOP, fill=tk.X, padx=6, pady=4)
        ttk.Label(row1, text="Active scheme").pack(side=tk.LEFT)
        self.scheme_combo = ttk.Combobox(row1, textvariable=self.active_scheme_var,
                                         state="readonly", width=24,
                                         values=[c.id for c in scheme_classes()])
        self.scheme_combo.pack(side=tk.LEFT, padx=5)
        self.scheme_combo.bind("<<ComboboxSelected>>", lambda e: self._on_scheme_change())
        ttk.Label(row1, text="Step").pack(side=tk.LEFT, padx=(12, 2))
        self.step_combo = ttk.Combobox(row1, textvariable=self.step_combo_var,
                                       state="readonly", width=46)
        self.step_combo.pack(side=tk.LEFT, padx=4)
        self.step_combo.bind("<<ComboboxSelected>>", lambda e: self._on_step_select())

        self.step_strip = ttk.Frame(ctrl); self.step_strip.pack(side=tk.TOP, fill=tk.X, padx=6, pady=2)

        row2 = ttk.Frame(ctrl); row2.pack(side=tk.TOP, fill=tk.X, padx=6, pady=4)
        for txt, cmd in [("▶ Step", self.do_step), ("Run step", self.do_run_step),
                         ("Run all", self.do_run_all), ("Reset this", self.do_reset_scheme)]:
            ttk.Button(row2, text=txt, command=cmd).pack(side=tk.LEFT, padx=3)
        self.play_btn = ttk.Button(row2, text="Play", command=self.toggle_play)
        self.play_btn.pack(side=tk.LEFT, padx=(14, 3))
        ttk.Label(row2, text="delay ms").pack(side=tk.LEFT)
        ttk.Spinbox(row2, from_=1, to=500, textvariable=self.speed_var, width=5).pack(side=tk.LEFT)

        # ---- mode row: Train vs continuous Run (until Stop)
        row3 = ttk.Frame(ctrl); row3.pack(side=tk.TOP, fill=tk.X, padx=6, pady=(0, 3))
        ttk.Label(row3, text="Mode").pack(side=tk.LEFT)
        self.mode_combo = ttk.Combobox(row3, textvariable=self.mode_var, state="readonly",
                                       width=26, values=MODES)
        self.mode_combo.pack(side=tk.LEFT, padx=4)
        self.mode_combo.bind("<<ComboboxSelected>>", lambda e: self._on_mode_change())
        ttk.Checkbutton(row3, text="keep learning", variable=self.learn_var,
                        command=self._apply_learning).pack(side=tk.LEFT, padx=10)
        ttk.Label(row3, textvariable=self.target_display_var, foreground="#444").pack(side=tk.LEFT, padx=12)

        # ---- live target row. The control schemes still consume motor speed
        # omega [rad/s], but for EV/DC it is much more intuitive to command the
        # corresponding vehicle speed. Both sliders are coupled:
        #     v_vehicle[km/h] = omega * wheel_radius / gear_ratio * 3.6
        row4 = ttk.Frame(ctrl); row4.pack(side=tk.TOP, fill=tk.X, padx=6, pady=(0, 5))
        self.setpoint_scale = tk.Scale(row4, from_=-20, to=20, resolution=0.1,
                                       orient=tk.HORIZONTAL, length=330,
                                       variable=self.setpoint_var, command=self._on_setpoint,
                                       showvalue=True, label="motor target ω [rad/s]")
        self.setpoint_scale.pack(side=tk.LEFT, padx=6)
        self.vehicle_setpoint_scale = tk.Scale(row4, from_=0, to=45, resolution=0.1,
                                               orient=tk.HORIZONTAL, length=330,
                                               variable=self.vehicle_setpoint_kph,
                                               command=self._on_vehicle_speed_setpoint,
                                               showvalue=True, label="vehicle target speed [km/h]")
        self.vehicle_setpoint_scale.pack(side=tk.LEFT, padx=6)

        # ---- harmonic live controls.  These settings are applied every tick
        # when the active scheme is hinj, so ON/OFF can be toggled live without
        # rebuilding the session.
        row5 = ttk.Frame(ctrl); row5.pack(side=tk.TOP, fill=tk.X, padx=6, pady=(0, 5))
        ttk.Label(row5, text="Harmonic injection").pack(side=tk.LEFT, padx=(6, 4))
        ttk.Checkbutton(row5, text="ON/OFF live", variable=self.harmonic_enabled,
                        command=self._on_harmonic_live_change).pack(side=tk.LEFT, padx=4)
        ttk.Label(row5, text="gain").pack(side=tk.LEFT, padx=(12, 2))
        tk.Scale(row5, from_=0.0, to=2.0, resolution=0.05, orient=tk.HORIZONTAL,
                 length=170, variable=self.harmonic_gain, command=lambda _v: self._on_harmonic_live_change(),
                 showvalue=True).pack(side=tk.LEFT, padx=3)
        ttk.Label(row5, text="limit V").pack(side=tk.LEFT, padx=(12, 2))
        tk.Scale(row5, from_=0.0, to=80.0, resolution=1.0, orient=tk.HORIZONTAL,
                 length=170, variable=self.harmonic_limit_v, command=lambda _v: self._on_harmonic_live_change(),
                 showvalue=True).pack(side=tk.LEFT, padx=3)

        # ---- EV/DC plant controls. These are plant parameters, so they are
        # applied when the user presses Rebuild. The live target sliders above
        # command the same target either as motor ω or vehicle km/h; these knobs define the battery/load/drive
        # operating condition of the experiment.
        self.ev_frame = ttk.LabelFrame(left, text="EV/DC plant variables — applied on Rebuild")
        self.ev_frame.pack(side=tk.TOP, fill=tk.X, padx=8, pady=(0, 4))
        evr1 = ttk.Frame(self.ev_frame); evr1.pack(side=tk.TOP, fill=tk.X, padx=6, pady=3)
        evr2 = ttk.Frame(self.ev_frame); evr2.pack(side=tk.TOP, fill=tk.X, padx=6, pady=3)

        def ev_spin(parent, label, var, frm, to, inc, width=7):
            ttk.Label(parent, text=label).pack(side=tk.LEFT, padx=(4, 2))
            ttk.Spinbox(parent, from_=frm, to=to, increment=inc, textvariable=var, width=width).pack(side=tk.LEFT, padx=(0, 6))

        ev_spin(evr1, "SOC0 %", self.ev_soc0_pct, 5, 100, 1)
        ev_spin(evr1, "payload kg", self.ev_payload_kg, 0, 300, 5)
        ev_spin(evr1, "grade %", self.ev_grade_pct, -15, 15, 0.5)
        ev_spin(evr1, "grade ripple %", self.ev_grade_amp_pct, 0, 10, 0.5)
        ev_spin(evr1, "capacity Ah", self.ev_capacity_ah, 1, 200, 1)

        ev_spin(evr2, "load base Nm", self.ev_load_base_nm, 0, 20, 0.05)
        ev_spin(evr2, "load amp Nm", self.ev_load_amp_nm, 0, 20, 0.05)
        ev_spin(evr2, "boost max", self.ev_boost_ratio, 0.5, 5.0, 0.05)
        ev_spin(evr2, "Vout max V", self.ev_vout_max, 12, 300, 1)
        ttk.Button(evr2, text="Apply/Rebuild", command=self.rebuild_session).pack(side=tk.LEFT, padx=8)
        ttk.Button(evr2, text="Vehicle settings…", command=self.open_vehicle_settings).pack(side=tk.LEFT, padx=2)

        # ---- notebook with the four views
        self.nb = ttk.Notebook(left); self.nb.pack(side=tk.TOP, fill=tk.BOTH, expand=True, padx=8, pady=6)
        self.fig_diagram = Figure(figsize=(7, 4.6), dpi=100)
        self.fig_circuit = Figure(figsize=(7, 4.6), dpi=100)
        self.fig_motor = Figure(figsize=(7, 4.6), dpi=100)
        self.fig_signals = Figure(figsize=(7, 4.6), dpi=100)
        self.ax_diagram = self.fig_diagram.add_subplot(111)
        self.ax_circuit = self.fig_circuit.add_subplot(111)
        self.ax_motor = self.fig_motor.add_subplot(111, projection="3d")
        self.canvases = {}
        for fig, name in [(self.fig_diagram, "Loop diagram"), (self.fig_circuit, "Circuit"),
                          (self.fig_motor, "3-D motor"), (self.fig_signals, "Signals")]:
            tab = ttk.Frame(self.nb); self.nb.add(tab, text=name)
            cv = FigureCanvasTkAgg(fig, master=tab)
            cv.get_tk_widget().pack(side=tk.TOP, fill=tk.BOTH, expand=True)
            self.canvases[name] = cv
        self.nb.bind("<<NotebookTabChanged>>", lambda e: self.redraw())

        # ---- right: state + layers + comparison + export
        self.layer_frame = ttk.LabelFrame(right, text="Signal layers")
        self.layer_frame.pack(side=tk.TOP, fill=tk.X, padx=6, pady=4)

        sf = ttk.LabelFrame(right, text="State / cost"); sf.pack(side=tk.TOP, fill=tk.BOTH, expand=True, padx=6, pady=4)
        self.state_text = tk.Text(sf, height=14, width=62, font=("TkFixedFont", 9))
        self.state_text.pack(side=tk.TOP, fill=tk.BOTH, expand=True)

        cf = ttk.LabelFrame(right, text="Comparison"); cf.pack(side=tk.TOP, fill=tk.X, padx=6, pady=4)
        cols = ("scheme", "plant", "rmse", "km/kWh", "Nm/kW", "Wh/km", "SOC%", "Irms", "effort", "grads", "ms")
        self.tree = ttk.Treeview(cf, columns=cols, show="headings", height=6)
        for c, w in zip(cols, (120, 95, 55, 65, 60, 60, 55, 55, 55, 60, 50)):
            self.tree.heading(c, text=c); self.tree.column(c, width=w, anchor=tk.CENTER)
        self.tree.pack(side=tk.TOP, fill=tk.X)

        ef = ttk.Frame(right); ef.pack(side=tk.TOP, fill=tk.X, padx=6, pady=4)
        self.export_var = tk.StringVar(value=list(exporters().keys())[0])
        ttk.Combobox(ef, textvariable=self.export_var, state="readonly", width=20,
                     values=list(exporters().keys())).pack(side=tk.LEFT, padx=2)
        ttk.Button(ef, text="Export", command=self.do_export).pack(side=tk.LEFT, padx=2)
        ttk.Button(ef, text="Save run", command=self.do_save).pack(side=tk.LEFT, padx=2)
        ttk.Button(ef, text="Load run", command=self.do_load).pack(side=tk.LEFT, padx=2)

    # ================================================================== #
    # session lifecycle
    # ================================================================== #
    def _plant_params(self) -> Dict[str, float]:
        """Plant-level parameters exposed by the EV/DC controls.

        They are harmless for non-EV plants because unknown keys are only used
        by the selected plant if they match its PARAMS. For evdc they define
        the battery/load/converter operating condition for the experiment.
        """
        return {
            "SOC0": float(self.ev_soc0_pct.get()) / 100.0,
            "payload_mass": float(self.ev_payload_kg.get()),
            "grade_pct": float(self.ev_grade_pct.get()),
            "grade_amp_pct": float(self.ev_grade_amp_pct.get()),
            "T_load_base": float(self.ev_load_base_nm.get()),
            "T_load_amp": float(self.ev_load_amp_nm.get()),
            "boost_ratio_max": float(self.ev_boost_ratio.get()),
            "Vout_abs_max": float(self.ev_vout_max.get()),
            "capacity_Ah": float(self.ev_capacity_ah.get()),
            "vehicle_mass": float(self.ev_vehicle_mass_kg.get()),
            "wheel_radius": float(self.ev_wheel_radius_m.get()),
            "gear_ratio": float(self.ev_gear_ratio.get()),
            "drivetrain_eta": float(self.ev_drivetrain_eta.get()),
            "Crr": float(self.ev_crr.get()),
            "CdA": float(self.ev_cda.get()),
            "target_vmax_kph": float(self.ev_target_vmax_kph.get()),
            "grade_period_m": float(self.ev_grade_period_m.get()),
            "load_period_m": float(self.ev_load_period_m.get()),
        }

    def _scheme_params(self) -> Dict[str, dict]:
        return {
            "iaic": {"ref_model_alpha": self.p_alpha.get(),
                     "excite_steps": self.p_excite.get(),
                     "epochs_emu": self.p_epochs_emu.get(),
                     "epochs_ctrl": self.p_epochs_ctrl.get()},
            "pid": {"kp": self.p_kp.get(), "ki": self.p_ki.get(), "kd": self.p_kd.get()},
            "hinj": {"harmonic_enabled": self.harmonic_enabled.get(),
                     "harmonic_gain": self.harmonic_gain.get(),
                     "harmonic_limit_v": self.harmonic_limit_v.get()},
        }

    def rebuild_session(self) -> None:
        self.stop_play()
        self.session = Session(plant_id=self.plant_var.get(),
                               plant_params=self._plant_params(),
                               scenario_id=self.scenario_var.get(),
                               dt=float(self.dt_var.get()),
                               duration=float(self.dur_var.get()),
                               seed=int(self.seed_var.get()),
                               scheme_params=self._scheme_params())
        self.last_signals, self.last_viz = {}, {}
        self.harmonic_snapshot_on, self.harmonic_snapshot_off = {}, {}
        self.phase = self.angle = 0.0
        # size and synchronize the live-target sliders to this plant/vehicle
        self._configure_live_target_sliders()
        self.mode_var.set(MODE_TRAIN)
        for sc in self.session.scheme_list():
            sc.set_setpoint(None)
            sc.run_continuous = False
        self._on_scheme_change()

    def _scheme(self):
        return self.session.schemes[self.active_scheme_var.get()]

    def _on_scheme_change(self) -> None:
        sc = self._scheme()
        self.mode_var.set(MODE_TRAIN)
        self._rebuild_layers()
        self._refresh_step_combo(); self._refresh_step_strip()
        self.redraw(); self.update_state(); self._refresh_tree()

    # ---- step combo + dependency strip -------------------------------- #
    def _step_disp(self, scheme, step_id) -> str:
        st = scheme._step(step_id)
        needs = ("needs: " + ", ".join(st.requires)) if st.requires else "no prereqs"
        return f"{st.label} · {needs} · [{STATUS_LABEL[scheme.status(step_id)]}]"

    def _refresh_step_combo(self) -> None:
        sc = self._scheme()
        vals = [self._step_disp(sc, s.id) for s in sc.steps()]
        self.step_combo["values"] = vals
        ids = [s.id for s in sc.steps()]
        if sc.active_step_id in ids:
            self.step_combo_var.set(vals[ids.index(sc.active_step_id)])

    def _refresh_step_strip(self) -> None:
        for w in self.step_strip.winfo_children():
            w.destroy()
        sc = self._scheme()
        for i, s in enumerate(sc.steps()):
            if i:
                ttk.Label(self.step_strip, text="→").pack(side=tk.LEFT)
            mark = "▸" if s.id == sc.active_step_id else " "
            lbl = tk.Label(self.step_strip, text=f"{mark}{s.label}",
                           bg=STATUS_COLOR[sc.status(s.id)], padx=6, pady=2,
                           relief=tk.RIDGE, font=("TkDefaultFont", 8))
            lbl.pack(side=tk.LEFT, padx=1)
            lbl.bind("<Button-1>", lambda e, sid=s.id: self._select_step(sid))

    def _select_step(self, sid) -> None:
        self._scheme().active_step_id = sid
        self._refresh_step_combo(); self._refresh_step_strip(); self.update_state()

    def _on_step_select(self) -> None:
        sc = self._scheme()
        ids = [s.id for s in sc.steps()]
        try:
            sc.active_step_id = ids[self.step_combo["values"].index(self.step_combo_var.get())]
        except ValueError:
            pass
        self._refresh_step_strip(); self.update_state()

    # ---- layers ------------------------------------------------------- #
    def _rebuild_layers(self) -> None:
        for w in self.layer_frame.winfo_children():
            w.destroy()
        self.layer_vars = {}
        sc = self._scheme()
        for ls in sc.layers():
            v = tk.BooleanVar(value=ls.default_on)
            self.layer_vars[ls.id] = v
            ttk.Checkbutton(self.layer_frame, text=ls.label, variable=v,
                            command=self.redraw).pack(side=tk.LEFT, padx=4)

    def _layer_on(self) -> Dict[str, bool]:
        return {k: v.get() for k, v in self.layer_vars.items()}

    # ================================================================== #
    # run controls
    # ================================================================== #
    def _post(self, frames) -> None:
        if frames:
            f = frames[-1] if isinstance(frames, list) else frames
            if getattr(f, "signals", None):
                self.last_signals = f.signals
            if getattr(f, "viz", None):
                self.last_viz = f.viz
            self._update_harmonic_snapshots(self.last_viz, self.last_signals)
        self._refresh_step_combo(); self._refresh_step_strip()
        self.redraw(); self.update_state(); self._refresh_tree()

    def do_step(self) -> None:
        sc = self._scheme()
        self._apply_live_harmonic_settings(sc)
        self._post(sc.micro_step())

    def do_run_step(self) -> None:
        self._stop_continuous()          # one pass, not free-run
        sc = self._scheme()
        self._apply_live_harmonic_settings(sc)
        self._post(sc.run_step(sc.active_step_id))

    def do_run_all(self) -> None:
        self._stop_continuous()
        self._post(self._scheme().run_all())

    def do_reset_scheme(self) -> None:
        self.stop_play()
        self._stop_continuous()
        self.mode_var.set(MODE_TRAIN)
        self._scheme().reset()
        self.last_signals, self.last_viz = {}, {}
        self._post(None)

    def do_train_offline(self) -> None:
        """Run every step except the final live/online one (no-op for PID)."""
        self.stop_play()
        sc = self._scheme()
        for st in sc.steps()[:-1]:
            if not sc.is_step_done(st.id):
                sc.run_step(st.id)
        self._post(None)

    # ---- mode handling ------------------------------------------------- #
    def _offline_done(self, sc) -> bool:
        return all(sc.is_step_done(s.id) for s in sc.steps()[:-1])

    def _stop_continuous(self) -> None:
        sc = self._scheme()
        sc.set_setpoint(None)
        sc.run_continuous = False

    def _apply_learning(self) -> None:
        sc = self._scheme()
        on = self.learn_var.get()
        if hasattr(sc, "adapt_emu"):
            sc.adapt_emu = on
            sc.adapt_ctrl = on

    def _apply_mode(self) -> bool:
        """Configure the active scheme for the chosen mode. Returns False (and
        reverts to Train) if a Run mode is picked before the controller exists."""
        sc = self._scheme()
        mode = self.mode_var.get()
        self._apply_learning()
        if mode == MODE_TRAIN:
            self._stop_continuous()
            sc.active_step_id = sc.next_ready_step() or sc.steps()[0].id
            return True
        # Run modes need a trained controller (iaic)
        if not self._offline_done(sc):
            self.mode_var.set(MODE_TRAIN)
            messagebox.showinfo("Run mode",
                                "Train first: press 'Run all' once, or run the "
                                "offline steps, then choose a Run mode.")
            return False
        last = sc.steps()[-1].id
        sc._done_steps.discard(last)
        sc.online_k = 0
        sc.k = 0
        sc.active_step_id = last
        if mode == MODE_RUN_REF:
            sc.set_setpoint(None); sc.run_continuous = True
        else:                                   # MODE_RUN_LIVE
            sc.run_continuous = False; sc.set_setpoint(self._live_setpoint_omega())
        return True

    def _on_mode_change(self) -> None:
        self.stop_play()
        self._apply_mode()
        self._refresh_step_combo(); self._refresh_step_strip(); self.update_state()

    def _omega_to_vehicle_kph(self, omega: float) -> float:
        """Convert motor speed omega [rad/s] to vehicle speed [km/h]."""
        pp = self._plant_params()
        wheel = max(float(pp.get("wheel_radius", 0.255)), 1e-9)
        gear = max(float(pp.get("gear_ratio", 7.0)), 1e-9)
        return float(omega) * wheel / gear * 3.6

    def _vehicle_kph_to_omega(self, speed_kph: float) -> float:
        """Convert vehicle speed [km/h] to motor omega [rad/s]."""
        pp = self._plant_params()
        wheel = max(float(pp.get("wheel_radius", 0.255)), 1e-9)
        gear = max(float(pp.get("gear_ratio", 7.0)), 1e-9)
        return float(speed_kph) / 3.6 * gear / wheel

    def _live_setpoint_omega(self) -> float:
        return float(self.setpoint_var.get())

    def _update_target_display(self) -> None:
        omega = float(self.setpoint_var.get())
        vkph = self._omega_to_vehicle_kph(omega)
        self.target_display_var.set(f"live target: ω={omega:.2f} rad/s  |  v={vkph:.1f} km/h")

    def _configure_live_target_sliders(self) -> None:
        """Set slider ranges after plant rebuild and keep omega/km/h in sync."""
        ylo, yhi = self._scheme().plant.y_range()
        omega_span = max(abs(ylo), abs(yhi), 1.0)
        self.setpoint_scale.config(from_=round(ylo, 1), to=round(yhi, 1))
        v_lo = self._omega_to_vehicle_kph(ylo)
        v_hi = self._omega_to_vehicle_kph(yhi)
        if v_lo > v_hi:
            v_lo, v_hi = v_hi, v_lo
        # EV examples are mostly forward, but keep the small negative range
        # because evdc.y_range() allows mild reverse speed.
        self.vehicle_setpoint_scale.config(from_=round(v_lo, 1), to=round(v_hi, 1))
        # If the old target is outside the new plant range, clip it.
        omega = min(max(float(self.setpoint_var.get()), ylo), yhi)
        self._syncing_targets = True
        try:
            self.setpoint_var.set(omega)
            self.vehicle_setpoint_kph.set(self._omega_to_vehicle_kph(omega))
        finally:
            self._syncing_targets = False
        self._update_target_display()

    def _on_setpoint(self, _val) -> None:
        if not getattr(self, "_syncing_targets", False):
            self._syncing_targets = True
            try:
                self.vehicle_setpoint_kph.set(self._omega_to_vehicle_kph(float(self.setpoint_var.get())))
            finally:
                self._syncing_targets = False
            self._update_target_display()
        if self.mode_var.get() == MODE_RUN_LIVE:
            self._scheme().set_setpoint(self._live_setpoint_omega())

    def _on_vehicle_speed_setpoint(self, _val) -> None:
        if not getattr(self, "_syncing_targets", False):
            self._syncing_targets = True
            try:
                omega = self._vehicle_kph_to_omega(float(self.vehicle_setpoint_kph.get()))
                self.setpoint_var.set(omega)
            finally:
                self._syncing_targets = False
            self._update_target_display()
        if self.mode_var.get() == MODE_RUN_LIVE:
            self._scheme().set_setpoint(self._live_setpoint_omega())

    def _on_harmonic_live_change(self) -> None:
        """Apply harmonic-injection knobs to the active running scheme.

        These controls are intentionally live for the hinj scheme.  For other
        schemes they are harmless and are simply stored for the next Rebuild.
        """
        if self.session is None:
            return
        try:
            self._apply_live_harmonic_settings(self._scheme())
        except Exception:
            pass
        self.update_state()

    def _apply_live_harmonic_settings(self, sc=None) -> None:
        if sc is None:
            sc = self._scheme()
        if getattr(sc, "id", "") == "hinj":
            sc.harmonic_enabled = bool(self.harmonic_enabled.get())
            sc.harmonic_gain = float(self.harmonic_gain.get())
            sc.harmonic_limit_v = float(self.harmonic_limit_v.get())

    def _update_harmonic_snapshots(self, viz: Dict[str, float], signals: Dict[str, float]) -> None:
        if not (viz and ("bemf_harmonic" in viz or "harmonic_thd_proxy" in viz)):
            return
        enabled = bool(self.harmonic_enabled.get())
        snap = {**viz, **signals}
        # Store a compact set of values to keep the state panel readable.
        compact = {
            "enabled": 1.0 if enabled else 0.0,
            "u_harm": float(snap.get("u_harm", 0.0)),
            "u_h5": float(snap.get("u_h5", 0.0)),
            "u_h7": float(snap.get("u_h7", 0.0)),
            "u_h11": float(snap.get("u_h11", 0.0)),
            "u_h13": float(snap.get("u_h13", 0.0)),
            "bemf_harmonic": float(snap.get("bemf_harmonic", 0.0)),
            "bemf_h5": float(snap.get("bemf_h5", 0.0)),
            "bemf_h7": float(snap.get("bemf_h7", 0.0)),
            "bemf_h11": float(snap.get("bemf_h11", 0.0)),
            "bemf_h13": float(snap.get("bemf_h13", 0.0)),
            "harmonic_thd_proxy": float(snap.get("harmonic_thd_proxy", 0.0)),
            "harmonic_thd_raw_proxy": float(snap.get("harmonic_thd_raw_proxy", snap.get("harmonic_thd_proxy", 0.0))),
            "harmonic_thd_residual_proxy": float(snap.get("harmonic_thd_residual_proxy", snap.get("harmonic_thd_proxy", 0.0))),
            "harmonic_cancellation_pct": float(snap.get("harmonic_cancellation_pct", 0.0)),
            "current_thd_raw_proxy": float(snap.get("current_thd_raw_proxy", snap.get("harmonic_thd_raw_proxy", 0.0))),
            "current_thd_residual_proxy": float(snap.get("current_thd_residual_proxy", snap.get("harmonic_thd_residual_proxy", 0.0))),
            "torque_ripple": float(snap.get("torque_ripple", 0.0)),
            "torque_ripple_current_residual_nm": float(snap.get("torque_ripple_current_residual_nm", 0.0)),
            "harmonic_loss_residual_W": float(snap.get("harmonic_loss_residual_W", 0.0)),
            "iq": float(snap.get("iq", snap.get("current", 0.0))),
            "km_per_kwh_live": float(snap.get("km_per_kwh_live", 0.0)),
            "nm_per_kw_live": float(snap.get("nm_per_kw_live", 0.0)),
            "km_per_kwh_inst": float(snap.get("km_per_kwh_inst", 0.0)),
            "km_per_kwh_effective_inst": float(snap.get("km_per_kwh_effective_inst", 0.0)),
            "nm_per_kw_effective_inst": float(snap.get("nm_per_kw_effective_inst", 0.0)),
        }
        if enabled:
            self.harmonic_snapshot_on = compact
        else:
            self.harmonic_snapshot_off = compact

    def toggle_play(self) -> None:
        if self.playing:
            self.stop_play()
        else:
            if not self._apply_mode():
                return
            self.playing = True
            self.play_btn.config(text="Stop")
            self._tick()

    def stop_play(self) -> None:
        self.playing = False
        if hasattr(self, "play_btn"):
            self.play_btn.config(text="Play")
        if self.after_id is not None:
            try:
                self.after_cancel(self.after_id)
            except Exception:
                pass
            self.after_id = None

    def _tick(self) -> None:
        if not self.playing:
            return
        sc = self._scheme()
        self._apply_live_harmonic_settings(sc)
        # In Train mode, stop once the offline steps are all done.
        if self.mode_var.get() == MODE_TRAIN and self._offline_done(sc):
            self.stop_play(); self._post(None); return
        f = sc.micro_step()
        if f is None:                 # replay reached its end (Train finished)
            self.stop_play(); self._post(None); return
        if getattr(f, "signals", None):
            self.last_signals = f.signals
        if getattr(f, "viz", None):
            self.last_viz = f.viz
        self._update_harmonic_snapshots(self.last_viz, self.last_signals)
        self._refresh_step_strip()
        self.redraw(light=True); self.update_state()
        self.after_id = self.after(int(self.speed_var.get()), self._tick)

    # ================================================================== #
    # drawing
    # ================================================================== #
    def redraw(self, light: bool = False) -> None:
        name = self.nb.tab(self.nb.select(), "text") if self.nb.tabs() else "Signals"
        sc = self._scheme()
        # advance animation cursors from the live viz
        dt = float(self.dt_var.get())
        i_max = max(self.last_viz.get("i_max", 1.0), 1e-6)
        self.phase = (self.phase + 0.04 + 0.25 * (self.last_viz.get("current", 0.0) / i_max)) % 1.0
        self.angle = (self.angle + self.last_viz.get("speed", 0.0) * dt) % (2 * 3.141592653589793)

        if name == "Loop diagram":
            merged = {**self.last_signals, **self.last_viz, "scheme_id": sc.id, "scheme_name": sc.name}
            draw_diagram(self.ax_diagram, merged)
            self.canvases[name].draw_idle()
        elif name == "Circuit":
            draw_circuit(self.ax_circuit, self.last_viz, self.phase)
            self.canvases[name].draw_idle()
        elif name == "3-D motor":
            draw_motor3d(self.ax_motor, self.last_viz, self.angle)
            self.canvases[name].draw_idle()
        elif name == "Signals":
            render_signals(self.fig_signals, sc, self._layer_on())
            self.canvases[name].draw_idle()

    # ================================================================== #
    # state panel + comparison
    # ================================================================== #
    def update_state(self, *_args) -> None:
        sc = self._scheme()
        c = sc.cost
        lines = [f"Scheme : {sc.name}",
                 f"Plant  : {sc.plant.name}",
                 f"Active step : {sc.active_step_id}",
                 "",
                 "Honest cost",
                 f"  sim steps     : {c.sim_steps}",
                 f"  grad updates  : {c.grad_updates}",
                 f"  forward evals : {c.forward_evals}",
                 f"  train epochs  : {c.epochs}",
                 f"  elapsed ms    : {c.elapsed_ms:.1f}"]
        if self.last_signals:
            s = self.last_signals
            lines += ["", "Live signals",
                      f"  r={s.get('r',0):+.3f}  y={s.get('y',0):+.3f}  u={s.get('u',0):+.3f}",
                      f"  e={s.get('e',0):+.3f}  e*={s.get('e_star',0):+.3f}  ŷ={s.get('y_hat',0):+.3f}"]
        def _recent_ev_stats(window_samples: int = 80):
            """Return a short-window average for the volatile EV metrics.

            Instantaneous ratios such as Nm/kW and km/kWh are intentionally
            noisy during the first seconds because distance and energy are still
            tiny.  This helper computes a local window so the state panel is
            easier to read without hiding the raw plant variables.
            """
            log = getattr(sc, "log", {}) or {}
            if not log.get("t"):
                return {}
            n = len(log["t"])
            i0 = max(0, n - window_samples)
            out = {}
            def arr(name):
                vals = log.get(name, [])
                if len(vals) < n:
                    return None
                return [float(x) for x in vals[i0:n] if isinstance(x, (int, float))]
            pb = arr("p_bat_W")
            tq = arr("torque")
            cur = arr("current") or arr("iq") or arr("i_arm")
            if pb:
                out["p_avg_kw"] = sum(pb) / len(pb) / 1000.0
            if tq:
                out["tau_avg_nm"] = sum(tq) / len(tq)
            if cur:
                out["i_rms_a"] = (sum(x*x for x in cur) / len(cur)) ** 0.5
            dist = log.get("distance_km", [])
            ene = log.get("energy_kwh", [])
            if len(dist) >= n and len(ene) >= n and n - i0 >= 2:
                dd = float(dist[-1]) - float(dist[i0])
                de = float(ene[-1]) - float(ene[i0])
                if dd > 1e-5 and de > 1e-7:
                    out["km_per_kwh_win"] = dd / de
                    out["wh_per_km_win"] = 1000.0 * de / dd
            if tq and pb:
                p_abs = [abs(x) for x in pb if abs(x) > 1e-3]
                if p_abs:
                    out["nm_per_kw_win"] = (sum(abs(x) for x in tq) / len(tq)) / (sum(p_abs) / len(p_abs) / 1000.0)
            return out

        if self.last_viz and ("soc_pct" in self.last_viz or "p_bat_W" in self.last_viz):
            v = self.last_viz
            p_inst_kw = float(v.get('p_bat_W', 0.0)) / 1000.0
            p_vi_kw = float(v.get('v_bat', 0.0)) * float(v.get('i_bat', 0.0)) / 1000.0
            stable = _recent_ev_stats()
            lines += ["", "EV / battery / load",
                      f"  live target: ω={float(self.setpoint_var.get()):.2f} rad/s  v={float(self.vehicle_setpoint_kph.get()):.2f} km/h",
                      f"  SOC={v.get('soc_pct',0):.2f}%  Vbat={v.get('v_bat',0):.2f} V  Ibat={v.get('i_bat',0):.2f} A",
                      f"  Pbat={p_inst_kw:.3f} kW  P=V·I={p_vi_kw:.3f} kW  torque={v.get('torque',0):.3f} Nm",
                      f"  load={v.get('load_torque',0):.3f} Nm  v={v.get('vehicle_speed_kph',0):.2f} km/h  grade={v.get('grade_pct_live',0):+.2f}%",
                      f"  mass={v.get('vehicle_mass_total',0):.1f} kg  dist={v.get('distance_km',0):.4f} km  E={v.get('energy_kwh',0):.5f} kWh"]
            if stable.get("km_per_kwh_win") is not None:
                lines += [f"  recent avg: km/kWh={stable.get('km_per_kwh_win',0):.2f}  Wh/km={stable.get('wh_per_km_win',0):.2f}  Nm/kW={stable.get('nm_per_kw_win',0):.2f}"]
            else:
                lines += ["  recent avg: warming up — ratios stabilize after some distance/energy"]
            lines += [f"  instantaneous: km/kWh={v.get('km_per_kwh_live',0):.2f}  Wh/km={v.get('wh_per_km_live',0):.2f}  Nm/kW={v.get('nm_per_kw_live',0):.2f}"]
        if self.last_viz and ("bemf_harmonic" in self.last_viz or "harmonic_thd_proxy" in self.last_viz):
            v = self.last_viz
            s = self.last_signals or {}
            status = "ON" if self.harmonic_enabled.get() else "OFF"
            raw_thd = float(s.get('harmonic_thd_raw_proxy', v.get('harmonic_thd_raw_proxy', v.get('harmonic_thd_proxy',0))))
            residual_thd = float(s.get('harmonic_thd_residual_proxy', raw_thd))
            cancel_pct = float(s.get('harmonic_cancellation_pct', 0.0))
            current_raw = float(s.get('current_thd_raw_proxy', raw_thd))
            current_resid = float(s.get('current_thd_residual_proxy', residual_thd))
            lines += ["", f"Harmonic injection [{status}]",
                      f"  θe={v.get('theta_e',0):.3f} rad  e_h(sum)={v.get('bemf_harmonic',0):+.3f} V",
                      f"  EMF residual proxy: raw={raw_thd:.4f}  residual={residual_thd:.4f}",
                      f"  current THD proxy: raw={current_raw:.4f}  residual={current_resid:.4f}  cancel={cancel_pct:+.1f}%",
                      f"  same-state A/B: ON Ithd={s.get('cf_on_current_thd_residual_proxy',0):.4f} loss={s.get('cf_on_harmonic_loss_residual_W',0):.2f} W km/kWh*={s.get('cf_on_km_per_kwh_effective_inst',0):.2f}",
                      f"                  OFF Ithd={s.get('cf_off_current_thd_residual_proxy',0):.4f} loss={s.get('cf_off_harmonic_loss_residual_W',0):.2f} W km/kWh*={s.get('cf_off_km_per_kwh_effective_inst',0):.2f}",
                      f"  *same-state instantaneous estimate; cumulative km/kWh is not used for ON/OFF judgment",
                      f"  EMF orders: h5={v.get('bemf_h5',0):+.3f} V  h7={v.get('bemf_h7',0):+.3f} V  h11={v.get('bemf_h11',0):+.3f} V  h13={v.get('bemf_h13',0):+.3f} V",
                      f"  injected: total={s.get('u_harm',0):+.3f} V  h5={s.get('u_h5',0):+.3f}  h7={s.get('u_h7',0):+.3f}  h11={s.get('u_h11',0):+.3f}  h13={s.get('u_h13',0):+.3f}",
                      f"  residual: h5={s.get('resid_h5',0):+.3f}  h7={s.get('resid_h7',0):+.3f}  h11={s.get('resid_h11',0):+.3f}  h13={s.get('resid_h13',0):+.3f}",
                      f"  torque ripple={v.get('torque_ripple',0):+.4f} Nm  iq={v.get('iq', v.get('current',0)):+.3f} A"]

            def snap_line(name, snap):
                if not snap:
                    return f"  {name}: no sample yet"
                return (f"  {name}: u_h={snap.get('u_harm',0):+.2f} V  "
                        f"Ithd raw={snap.get('current_thd_raw_proxy', snap.get('harmonic_thd_raw_proxy',0)):.4f}  "
                        f"resid={snap.get('current_thd_residual_proxy', snap.get('harmonic_thd_residual_proxy',0)):.4f}  "
                        f"cancel={snap.get('harmonic_cancellation_pct',0):+.1f}%  "
                        f"τrip≈{snap.get('torque_ripple_current_residual_nm', snap.get('torque_ripple',0)):+.4f} Nm  "
                        f"loss={snap.get('harmonic_loss_residual_W',0):.2f} W  "
                        f"km/kWh*={snap.get('km_per_kwh_effective_inst', snap.get('km_per_kwh_inst',0)):.2f}  "
                        f"Nm/kW*={snap.get('nm_per_kw_effective_inst', snap.get('nm_per_kw_live',0)):.2f}")
            lines += ["  last ON/OFF comparison:",
                      snap_line("ON ", self.harmonic_snapshot_on),
                      snap_line("OFF", self.harmonic_snapshot_off)]
        m = sc.metrics()
        if m:
            lines += ["", "Tracking metrics",
                      f"  RMSE={m['rmse']:.3f}  sse={m['sse']:.3f}",
                      f"  overshoot={m['overshoot_pct']:.1f}%  effort={m['control_effort']:.2f}"]
            if "km_per_kwh" in m or "nm_per_kw" in m:
                lines += ["", "Energy metrics",
                          f"  km/kWh={m.get('km_per_kwh',0):.3f}  Wh/km={m.get('wh_per_km',0):.3f}",
                          f"  Nm/kW={m.get('nm_per_kw',0):.3f}  Irms={m.get('rms_current_a',0):.3f} A",
                          f"  final SOC={m.get('final_soc_pct',0):.2f}%  drop={m.get('soc_drop_pctpts',0):.4f} pct-pts"]
        self.state_text.delete("1.0", tk.END)
        self.state_text.insert(tk.END, "\n".join(lines))

    def _refresh_tree(self) -> None:
        for r in self.tree.get_children():
            self.tree.delete(r)
        for row in self.session.comparison_rows():
            gap = row.get("gap_pct")
            self.tree.insert("", tk.END, values=(
                row.get("scheme", ""), row.get("plant", ""),
                row.get("rmse", ""), row.get("km_per_kwh", ""),
                row.get("nm_per_kw", ""), row.get("wh_per_km", ""),
                row.get("final_soc_pct", ""), row.get("rms_current_a", ""),
                row.get("control_effort", ""), row.get("grad_updates", ""),
                row.get("ms", "")))

    # ================================================================== #
    # export / save / load / settings
    # ================================================================== #
    def do_export(self) -> None:
        label = self.export_var.get()
        spec = exporters()[label]
        path = filedialog.asksaveasfilename(defaultextension="." + spec["ext"],
                                            filetypes=[(label, "*." + spec["ext"])])
        if not path:
            return
        try:
            if label == "Signal plot (PNG)":
                spec["fn"](self.session, path, scheme_id=self.active_scheme_var.get(),
                           layer_on=self._layer_on())
            elif label == "Signals (CSV)":
                spec["fn"](self.session, path, scheme_id=self.active_scheme_var.get())
            else:
                spec["fn"](self.session, path)
            messagebox.showinfo("Export", f"Wrote {path}")
        except Exception as ex:
            messagebox.showerror("Export failed", str(ex))

    def do_save(self) -> None:
        path = filedialog.asksaveasfilename(defaultextension=".json")
        if path:
            self.session.save(path); messagebox.showinfo("Save", f"Saved {path}")

    def do_load(self) -> None:
        path = filedialog.askopenfilename(filetypes=[("Session", "*.json")])
        if not path:
            return
        try:
            self.session = Session.load(path)
            self.plant_var.set(self.session.plant_id)
            self.scenario_var.set(self.session.scenario_id)
            pp = getattr(self.session, "plant_params", {}) or {}
            if "SOC0" in pp: self.ev_soc0_pct.set(100.0 * float(pp["SOC0"]))
            if "payload_mass" in pp: self.ev_payload_kg.set(float(pp["payload_mass"]))
            if "grade_pct" in pp: self.ev_grade_pct.set(float(pp["grade_pct"]))
            if "grade_amp_pct" in pp: self.ev_grade_amp_pct.set(float(pp["grade_amp_pct"]))
            if "T_load_base" in pp: self.ev_load_base_nm.set(float(pp["T_load_base"]))
            if "T_load_amp" in pp: self.ev_load_amp_nm.set(float(pp["T_load_amp"]))
            if "boost_ratio_max" in pp: self.ev_boost_ratio.set(float(pp["boost_ratio_max"]))
            if "Vout_abs_max" in pp: self.ev_vout_max.set(float(pp["Vout_abs_max"]))
            if "capacity_Ah" in pp: self.ev_capacity_ah.set(float(pp["capacity_Ah"]))
            if "vehicle_mass" in pp: self.ev_vehicle_mass_kg.set(float(pp["vehicle_mass"]))
            if "wheel_radius" in pp: self.ev_wheel_radius_m.set(float(pp["wheel_radius"]))
            if "gear_ratio" in pp: self.ev_gear_ratio.set(float(pp["gear_ratio"]))
            if "drivetrain_eta" in pp: self.ev_drivetrain_eta.set(float(pp["drivetrain_eta"]))
            if "Crr" in pp: self.ev_crr.set(float(pp["Crr"]))
            if "CdA" in pp: self.ev_cda.set(float(pp["CdA"]))
            if "target_vmax_kph" in pp: self.ev_target_vmax_kph.set(float(pp["target_vmax_kph"]))
            if "grade_period_m" in pp: self.ev_grade_period_m.set(float(pp["grade_period_m"]))
            if "load_period_m" in pp: self.ev_load_period_m.set(float(pp["load_period_m"]))
            self._on_scheme_change()
            messagebox.showinfo("Load", f"Loaded {path}")
        except Exception as ex:
            messagebox.showerror("Load failed", str(ex))


    def _apply_vehicle_preset(self, preset: str) -> None:
        """Convenience presets for the EV/DC plant.

        These are not magic validated vehicles; they are starting points so the
        demo can move like a light EV prototype, an urban kart, or a small RC
        vehicle without manually editing every parameter.
        """
        presets = {
            "eco": dict(vehicle_mass=115.0, wheel_radius=0.255, gear=7.0, eta=0.92,
                         crr=0.010, cda=0.24, vmax=45.0, capacity=18.0,
                         boost=1.75, vout=96.0),
            "urban": dict(vehicle_mass=180.0, wheel_radius=0.280, gear=8.5, eta=0.90,
                           crr=0.014, cda=0.45, vmax=55.0, capacity=32.0,
                           boost=1.90, vout=120.0),
            "rc": dict(vehicle_mass=8.0, wheel_radius=0.060, gear=10.0, eta=0.82,
                        crr=0.020, cda=0.05, vmax=18.0, capacity=3.0,
                        boost=1.30, vout=24.0),
        }
        pr = presets[preset]
        self.ev_vehicle_mass_kg.set(pr["vehicle_mass"])
        self.ev_wheel_radius_m.set(pr["wheel_radius"])
        self.ev_gear_ratio.set(pr["gear"])
        self.ev_drivetrain_eta.set(pr["eta"])
        self.ev_crr.set(pr["crr"])
        self.ev_cda.set(pr["cda"])
        self.ev_target_vmax_kph.set(pr["vmax"])
        self.ev_capacity_ah.set(pr["capacity"])
        self.ev_boost_ratio.set(pr["boost"])
        self.ev_vout_max.set(pr["vout"])

    def open_vehicle_settings(self) -> None:
        win = tk.Toplevel(self); win.title("Vehicle / route settings"); win.geometry("520x520")
        ttk.Label(win, text="Vehicle characteristics for the EV/DC plant",
                  font=("TkDefaultFont", 9, "bold")).pack(pady=(8, 2))
        ttk.Label(win, text="These parameters change the road-load physics and reference scaling. Press Apply & rebuild.",
                  wraplength=480, justify=tk.LEFT).pack(padx=10, pady=(0, 8), anchor="w")

        presets = ttk.LabelFrame(win, text="Presets")
        presets.pack(side=tk.TOP, fill=tk.X, padx=10, pady=4)
        ttk.Button(presets, text="Eco prototype", command=lambda: self._apply_vehicle_preset("eco")).pack(side=tk.LEFT, padx=4, pady=5)
        ttk.Button(presets, text="Urban kart", command=lambda: self._apply_vehicle_preset("urban")).pack(side=tk.LEFT, padx=4, pady=5)
        ttk.Button(presets, text="RC toy", command=lambda: self._apply_vehicle_preset("rc")).pack(side=tk.LEFT, padx=4, pady=5)

        def row(parent, label, var, frm, to, inc=1, help_text=""):
            f = ttk.Frame(parent); f.pack(side=tk.TOP, fill=tk.X, padx=8, pady=3)
            ttk.Label(f, text=label, width=24).pack(side=tk.LEFT)
            ttk.Spinbox(f, from_=frm, to=to, increment=inc, textvariable=var, width=10).pack(side=tk.LEFT)
            if help_text:
                ttk.Label(f, text=help_text, foreground="#555").pack(side=tk.LEFT, padx=8)

        veh = ttk.LabelFrame(win, text="Vehicle")
        veh.pack(side=tk.TOP, fill=tk.X, padx=10, pady=4)
        row(veh, "vehicle mass kg", self.ev_vehicle_mass_kg, 1, 1000, 5, "vehicle + driver, payload is separate")
        row(veh, "wheel radius m", self.ev_wheel_radius_m, 0.03, 0.8, 0.005)
        row(veh, "gear ratio", self.ev_gear_ratio, 1.0, 30.0, 0.1, "motor speed / wheel speed")
        row(veh, "drivetrain eta", self.ev_drivetrain_eta, 0.50, 1.0, 0.01)
        row(veh, "rolling Crr", self.ev_crr, 0.002, 0.08, 0.001)
        row(veh, "CdA m²", self.ev_cda, 0.02, 2.5, 0.01)
        row(veh, "target max speed km/h", self.ev_target_vmax_kph, 5, 120, 1, "scales the reference ω")

        route = ttk.LabelFrame(win, text="Route periodicity")
        route.pack(side=tk.TOP, fill=tk.X, padx=10, pady=4)
        row(route, "grade period m", self.ev_grade_period_m, 5, 1000, 5)
        row(route, "load period m", self.ev_load_period_m, 5, 1000, 5)

        bottom = ttk.Frame(win); bottom.pack(side=tk.BOTTOM, fill=tk.X, padx=10, pady=10)
        ttk.Button(bottom, text="Apply & rebuild",
                   command=lambda: (self.rebuild_session(), win.destroy())).pack(side=tk.RIGHT, padx=4)
        ttk.Button(bottom, text="Close", command=win.destroy).pack(side=tk.RIGHT, padx=4)


    def open_help(self) -> None:
        """Open an extensible help window with topic navigation.

        The goal is to make the GUI less chaotic: the help window explains what
        every major control block does and how the current Python prototype maps
        to the later MATLAB/Simulink implementation.
        """
        win = tk.Toplevel(self)
        win.title("Help — Multi-Objective AI Control Workbench")
        win.geometry("940x680")
        win.minsize(760, 520)

        topics = {
            "Quick start": """
1) Pick a Plant.
   - evdc: battery + averaged boost + DC motor + vehicle load.
   - spmsm_harm: simplified synchronous PM machine with back-EMF harmonics.

2) Pick a Scenario.
   - urban: EV-like speed cycle.
   - grade_adaptive: target speed changes with slope and SOC.

3) Pick a Scheme.
   - pid: basic speed PID.
   - iaic: original ANN emulator + inverse controller.
   - moev / moevc: multi-loop EV controllers.
   - hinj: speed/torque/current control plus harmonic voltage injection.

4) Press Run all for one complete offline/reference run, or choose
   'Run · live target' and press Play to drive the target sliders live.

5) Watch the Loop diagram, Signals tab, and Comparison table.
""",
            "Plants": """
evdc — Battery + boost DC EV drive
  A control-level model: battery OCV(SOC), internal resistance, averaged boost
  envelope, DC motor, road load, grade, payload, distance and energy metrics.

spmsm_harm — Battery + inverter SPMSM harmonic model
  A simplified synchronous-machine model. It has q-axis current, rotor speed,
  electrical angle and harmonic back-EMF terms at 5th/7th/11th/13th orders.
  This is not a finite-element PMSM model and not SVPWM. It is a sandbox for
  showing the harmonic-injection idea before moving to MATLAB/Simulink.
""",
            "Schemes / loops": """
pid
  One speed loop: speed error -> voltage command.

iaic
  Original adaptive inverse-control demo:
  ANN emulator learns the plant; ANN inverse controller learns the input needed
  to reach the target.

moev
  EV cascade: outer speed loop -> torque/current loop -> SOC/power supervisor.

moevc
  Coupled EV controller: reference governor checks whether the requested speed
  is feasible under torque, current, battery power and SOC constraints. It maps
  desired acceleration into required torque using vehicle dynamics.

hinj
  Same coupled speed/torque/current structure, plus a harmonic feed-forward
  branch that injects v_harm into the voltage command.
""",
            "Vehicle settings": """
Use Vehicle settings to prevent the model from feeling like a small RC car.
Important parameters:
  vehicle mass kg     vehicle + driver mass, before payload
  wheel radius m      links motor omega to vehicle speed
  gear ratio          motor speed / wheel speed
  drivetrain eta      mechanical efficiency of drivetrain
  Crr                 rolling resistance coefficient
  CdA                 aero drag area
  target max speed    scenario scaling cap, not the live target slider

Live target sliders:
  motor target ω [rad/s]
  vehicle target speed [km/h]
These are synchronized by v = omega * wheel_radius / gear_ratio.
""",
            "Multi-objective idea": """
The point is not only to track speed. Objectives can conflict:
  - more torque and faster acceleration usually draw more current
  - more current increases I²R losses and voltage sag
  - low SOC reduces the useful power/current envelope
  - eco driving improves km/kWh but may reduce peak torque response

The multi-loop schemes expose these trade-offs through metrics:
  km/kWh, Wh/km, Nm/kW, RMS current, SOC drop, tracking RMSE and constraints.
""",
            "Harmonic injection": """
In the simplified SPMSM plant, q-axis current obeys:
  Lq di/dt = vq - Rs iq - Ke omega - e_h(theta_e, omega)
where e_h is a synthetic 5th/7th/11th/13th back-EMF harmonic disturbance.

The hinj scheme computes:
  v_total = v_base + v_harm
  v_harm ≈ gain * e_h(theta_e, omega)

The GUI reports two harmonic proxies:
  raw THD proxy      = RMS of synthetic EMF harmonic orders / fundamental EMF
  residual THD proxy = RMS of (EMF harmonic - injected voltage) / fundamental EMF
The residual value is the before/after indicator; raw is the disturbance that
exists in the machine model.

Because e_h subtracts inside the current equation, adding a matching voltage is
an active cancellation step. It is the same concept as harmonic compensation, but here
it is intentionally simplified: scalar q-axis voltage, no three-phase PWM and no
detailed machine modelling maps yet.
""",
            "MATLAB / Simulink path": """
The Python GUI is the architecture prototype. The MATLAB version should replace
simple envelopes with engineering models:
  - Simscape battery or OCV-SOC-Rint tables
  - averaged/switching DC/DC converter controllers
  - DC motor or PMSM/FOC/SVPWM plant
  - App Designer GUI for variants and sweeps
  - ANN emulator + inverse modules per loop/objective
  - optional map/ANN harmonic injection module
""",
            "Files / docs": """
Useful markdown files in the project folder:
  README.md              overview
  HOW_TO_RUN.md          commands and smoke tests
  EV_EXTENSION.md        battery/DC motor/vehicle metrics
  COUPLED_CONTROL_PLAN.md multi-loop equations
  HARMONIC_INJECTION.md  simplified SPMSM harmonic extension
  PATCH_NOTES_v0_11.md   this release
""",
        }

        left = ttk.Frame(win, width=230)
        left.pack(side=tk.LEFT, fill=tk.Y, padx=8, pady=8)
        left.pack_propagate(False)
        ttk.Label(left, text="❓ Help topics", font=("TkDefaultFont", 10, "bold")).pack(anchor="w", pady=(0, 6))
        topic_list = tk.Listbox(left, height=20, exportselection=False)
        topic_list.pack(side=tk.TOP, fill=tk.BOTH, expand=True)
        for name in topics:
            topic_list.insert(tk.END, name)

        right = ttk.Frame(win)
        right.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True, padx=(0, 8), pady=8)
        title = ttk.Label(right, text="", font=("TkDefaultFont", 12, "bold"))
        title.pack(anchor="w", pady=(0, 4))
        text = scrolledtext.ScrolledText(right, wrap=tk.WORD, font=("TkDefaultFont", 10))
        text.pack(fill=tk.BOTH, expand=True)

        def show_topic(_evt=None):
            sel = topic_list.curselection()
            if not sel:
                return
            name = topic_list.get(sel[0])
            title.config(text=name)
            text.configure(state=tk.NORMAL)
            text.delete("1.0", tk.END)
            text.insert(tk.END, topics[name].strip() + "\n")
            text.configure(state=tk.DISABLED)

        def open_markdown(filename: str):
            from pathlib import Path
            path = Path(__file__).resolve().parent.parent / filename
            text.configure(state=tk.NORMAL)
            text.delete("1.0", tk.END)
            title.config(text=filename)
            try:
                text.insert(tk.END, path.read_text(encoding="utf-8"))
            except Exception as ex:
                text.insert(tk.END, f"Could not open {path}:\n{ex}")
            text.configure(state=tk.DISABLED)

        topic_list.bind("<<ListboxSelect>>", show_topic)
        bottom = ttk.Frame(right); bottom.pack(side=tk.BOTTOM, fill=tk.X, pady=(6, 0))
        ttk.Button(bottom, text="Open HOW_TO_RUN.md", command=lambda: open_markdown("HOW_TO_RUN.md")).pack(side=tk.LEFT, padx=2)
        ttk.Button(bottom, text="Open HARMONIC_INJECTION.md", command=lambda: open_markdown("HARMONIC_INJECTION.md")).pack(side=tk.LEFT, padx=2)
        ttk.Button(bottom, text="Close", command=win.destroy).pack(side=tk.RIGHT, padx=2)
        topic_list.selection_set(0)
        show_topic()

    def open_settings(self) -> None:
        win = tk.Toplevel(self); win.title("Settings"); win.geometry("400x430")
        def row(parent, label, var, frm, to, inc=1):
            f = ttk.Frame(parent); f.pack(side=tk.TOP, fill=tk.X, padx=8, pady=3)
            ttk.Label(f, text=label, width=22).pack(side=tk.LEFT)
            ttk.Spinbox(f, from_=frm, to=to, increment=inc, textvariable=var, width=10).pack(side=tk.LEFT)
        ttk.Label(win, text="Indirect inverse (iaic)", font=("TkDefaultFont", 9, "bold")).pack(pady=(8, 0))
        row(win, "ref-model alpha", self.p_alpha, 0.05, 1.0, 0.05)
        row(win, "excitation steps", self.p_excite, 200, 8000, 100)
        row(win, "emulator epochs", self.p_epochs_emu, 5, 300, 5)
        row(win, "controller epochs", self.p_epochs_ctrl, 5, 300, 5)
        ttk.Label(win, text="PID baseline", font=("TkDefaultFont", 9, "bold")).pack(pady=(10, 0))
        row(win, "kp", self.p_kp, 0.0, 50.0, 0.1)
        row(win, "ki", self.p_ki, 0.0, 50.0, 0.1)
        row(win, "kd", self.p_kd, 0.0, 5.0, 0.01)
        ttk.Label(win, text="Harmonic injection (hinj)", font=("TkDefaultFont", 9, "bold")).pack(pady=(10, 0))
        f = ttk.Frame(win); f.pack(side=tk.TOP, fill=tk.X, padx=8, pady=3)
        ttk.Label(f, text="enabled", width=22).pack(side=tk.LEFT)
        ttk.Checkbutton(f, variable=self.harmonic_enabled).pack(side=tk.LEFT)
        row(win, "harmonic gain", self.harmonic_gain, 0.0, 2.0, 0.05)
        row(win, "harmonic limit V", self.harmonic_limit_v, 0.0, 80.0, 1.0)
        ttk.Button(win, text="Apply & rebuild",
                   command=lambda: (self.rebuild_session(), win.destroy())).pack(pady=12)

    def on_close(self) -> None:
        self.stop_play()
        self.destroy()
