# Patch notes v0.13 — harmonic visibility + live ON/OFF comparison

This patch focuses on the confusion around the simplified harmonic-injection extension.

## 1. Live harmonic ON/OFF toggle

The GUI now has live harmonic controls in the main scheme-control area:

- `ON/OFF live`
- `gain`
- `limit V`

For the `hinj` scheme these are applied at every simulation tick. You no longer need to rebuild the session just to switch harmonic injection on or off.

## 2. Last ON/OFF comparison memory

The right-side state panel now keeps two last-observed harmonic snapshots:

- last sample with injection ON
- last sample with injection OFF

This means you can toggle from ON to OFF and still see the last ON values, or toggle back to ON and still see the last OFF values. This is intended for visual before/after comparison during live runs.

The comparison currently shows:

- injected harmonic voltage `u_h`
- THD proxy
- torque ripple proxy
- live km/kWh
- live Nm/kW

## 3. Per-order harmonic display

The simplified SPMSM harmonic plant now exposes the synthetic back-EMF harmonics split into:

- 5th harmonic
- 7th harmonic
- 11th harmonic
- 13th harmonic

The `hinj` controller also exposes the per-order injected voltage components:

- `u_h5`
- `u_h7`
- `u_h11`
- `u_h13`

The state panel now shows both the EMF harmonic components and the injected voltage components.

## 4. Signals plot improvement

The harmonic signal layer now plots:

- total harmonic EMF
- total injected harmonic voltage
- per-order injected harmonics h5/h7/h11/h13
- THD proxy

## 5. Important interpretation note

The harmonic injection model remains intentionally simplified. It is not a full three-phase FOC/SVPWM PMSM model. It is a Python sandbox to demonstrate how a control loop can host a parallel compensation branch before migrating the architecture to MATLAB/Simulink.

## 6. About Pbat jumping

Pbat can still vary strongly in `grade_adaptive` because the road grade and load are changing, and because power is instantaneous:

```text
Pbat = Vbat * Ibat
```

In v0.12 and later the displayed Pbat is physically consistent with terminal battery voltage/current after current limiting. The GUI also shows recent-window averaged metrics because ratios such as km/kWh and Nm/kW are noisy during the first seconds/meters of a live run.
