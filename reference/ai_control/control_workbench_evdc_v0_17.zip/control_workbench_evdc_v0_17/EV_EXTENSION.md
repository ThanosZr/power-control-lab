# EV Battery + DC Motor Extension — v0.1

This extension turns the original adaptive inverse-control workbench into a first
version of a **multi-objective electric-drive workbench**. The aim is not yet to
model a full PMSM/inverter stack; the aim is to create a clean, reproducible
control-level platform where battery state, converter limits, motor torque,
variable load and energy metrics can be evaluated together.

## 1. Project title

**Multi-Objective AI Control Workbench for Electric Drive Energy Optimization**

Short GitHub name:

**AI EV Drive Control Workbench**

## 2. What changed in v0.1

### New plant: `evdc`

`plants/ev_dc_drive.py` adds:

```text
Battery SOC model
      ↓
Internal resistance + voltage sag
      ↓
Simplified bidirectional buck/boost converter envelope
      ↓
DC motor armature dynamics
      ↓
Vehicle-equivalent road/load model
      ↓
Energy and performance metrics
```

The plant keeps the original workbench contract: the controller still sees one
input and one tracked output. This means the existing PID and ANN inverse-control
schemes can drive it without rewriting the GUI.

### New scenario: `urban`

`core/scenario.py` adds a positive EV-style reference trajectory:

```text
launch → cruise → coast → re-accelerate → cruise
```

This is better for `km/kWh` and road-load analysis than the original multistep
reference, which includes reverse-speed commands.

### Updated first GUI tab

The first tab now shows live EV/control variables in the loop diagram:

- SOC [%]
- battery voltage
- battery current
- battery power
- motor torque
- equivalent load torque
- live km/kWh
- live Nm/kW

The idea is that the user immediately sees that the control loop is not only
tracking speed; it is also operating under battery and load constraints.

### Updated metrics

The base `ControlScheme.metrics()` now computes EV metrics when the plant logs
the required variables:

- `km_per_kwh`
- `wh_per_km`
- `nm_per_kw`
- `rms_current_a`
- `final_soc_pct`
- `soc_drop_pctpts`
- `peak_torque_nm`
- `mean_v_sag`

The comparison table and CSV exporter include these fields.

## 3. Plant model

### 3.1 State vector

```text
x = [i_a, omega_m, SOC, distance_m, energy_draw_J]
```

where:

- `i_a` is armature current [A]
- `omega_m` is motor shaft speed [rad/s]
- `SOC` is battery state of charge [0..1]
- `distance_m` is travelled distance [m]
- `energy_draw_J` is positive drawn battery energy [J]

### 3.2 Controller input

```text
u = V_cmd
```

The controller requests a motor armature voltage. The plant then applies a
converter envelope based on available battery voltage and maximum boost ratio:

```text
V_arm = clip(V_cmd, -V_available, +V_available)
V_available = min(Vout_abs_max, boost_ratio_max · OCV(SOC))
```

This is not a transistor-level switching converter. It is a system-level
converter envelope suitable for control studies.

### 3.3 Battery model

The battery has:

```text
OCV = f(SOC)
Rint = f(SOC)
Vbat = OCV - Ibat · Rint
```

Low SOC increases internal resistance, which increases voltage sag. This is the
main mechanism that makes the same drive cycle behave differently at different
battery states.

### 3.4 Motor model

The DC motor still follows the standard armature equations:

```text
L di/dt = Varm - R i - Ke ω
J_eq dω/dt = Kt i - Bω - T_load
```

The difference from the original `dc` plant is that `J_eq` and `T_load` now come
from an EV-equivalent road-load model.

### 3.5 Variable load model

The plant computes a reflected motor load from:

- rolling resistance
- aerodynamic drag
- road grade
- sinusoidal variable road/load disturbance
- optional payload mass

This gives a more realistic result than a constant `T_load`. When the load
changes, the controller must change motor voltage/current to maintain the same
speed target. This is the first step toward multi-objective control.

## 4. Metrics

### 4.1 Energy efficiency

```text
km/kWh = distance_km / energy_kWh
Wh/km  = 1000 · energy_kWh / distance_km
```

These are vehicle-level metrics and are sensitive to SOC, load, reference speed,
controller aggressiveness and current ripple.

### 4.2 Torque per electrical power

```text
Nm/kW = mean(|T_motor|) / mean(P_battery_kW)
```

This is not the same as `T/P_mech`, because `T/P_mech = 1/ω` and mostly reflects
speed. The chosen metric asks a more useful EV-control question:

> How much useful torque does the system produce per kW drawn from the battery?

### 4.3 Current stress

```text
Irms = sqrt(mean(i_a²))
```

This is useful because more aggressive tracking or high torque demand usually
raises current RMS, which increases copper and battery losses.

## 5. How to run

### GUI

```bash
python main.py
```

Then select:

```text
Plant    : evdc
Scenario : urban
Scheme   : pid or iaic
```

Run the scheme and open:

- **Loop diagram** for live control variables
- **Signals** for speed/error/control plots
- enable **EV energy / SOC** layer for energy metrics over time

### CLI examples

```bash
python cli.py run --plant evdc --scenario urban --schemes pid --duration 8 --dt 0.05 --metrics ev_metrics.csv --plot ev_plot.png
```

```bash
python cli.py run --plant evdc --scenario urban --schemes iaic pid --duration 8 --dt 0.1 --metrics ev_metrics.csv
```

## 6. Why this matters

The first workbench version showed:

> ANN emulator + ANN inverse controller can learn speed control for a motor.

This extension starts showing:

> A controller can be evaluated under conflicting EV objectives: tracking,
> torque, battery power, SOC, current stress and energy efficiency.

That is the important CV/research direction. It is not just a controller that
happens to learn; it is a framework where additional objectives can be plugged
in and compared.

## 7. Planned next stages

### Stage 1 — Current version

- Battery + SOC
- Converter envelope
- DC motor
- Variable road/load torque
- km/kWh, Wh/km, Nm/kW
- updated GUI and exporters

### Stage 2 — Multi-objective supervisor

Add a controller layer that changes strategy depending on mode:

```text
Eco        → lower current, smoother response, higher km/kWh
Balanced   → trade-off
Performance→ higher torque/power, lower km/kWh
Low-SOC    → current/power limiting and voltage-sag protection
```

### Stage 3 — Harmonic/ripple module

Add a ripple-augmented DC motor or PMSM model and an extra ANN pair:

```text
Ripple emulator ANN   : predicts ripple/current stress from harmonic injection
Harmonic inverse ANN  : outputs correction coefficients
```

This would move the workbench closer to harmonic compensation ideas, while
keeping the contribution different: not fixed-map compensation, but modular
AI-based multi-objective control allocation.

### Stage 4 — PMSM / Simulink bridge

Use MATLAB/Simulink for a PMSM/FOC model and use this workbench as the Python
prototype for the AI supervisor, metrics and trade-off visualization.

## 8. Suggested CV bullet

> Developed a modular AI control workbench for electric-drive simulations,
> extending an ANN emulator–inverse controller architecture with a battery-SOC
> model, simplified boost-converter envelope, variable EV road-load model and
> multi-objective metrics including km/kWh, Wh/km, Nm/kW, RMS current and SOC
> drop. Implemented GUI/CLI comparison between PID and adaptive inverse-control
> strategies with live visualization of battery, torque and energy variables.


## v0.6 vehicle settings

The GUI now includes a **Vehicle settings** button. Use it to configure vehicle mass, wheel radius, gear ratio, drivetrain efficiency, rolling resistance, CdA, target max speed, and route/load periods. Press **Apply & rebuild** after changing these values.

Useful presets are included: **Eco prototype**, **Urban kart**, and **RC toy**. For this project, **Eco prototype** or **Urban kart** are better starting points when you want the animation and metrics to feel like a real lightweight EV rather than a small model car.

CLI example with explicit vehicle scale:

```bat
python cli.py run --plant evdc --scenario grade_adaptive --schemes pid --duration 8 --dt 0.1 --soc0 55 --payload 35 --grade 4 --grade-amp 2.5 --vehicle-mass 115 --wheel-radius 0.255 --gear 7 --target-vmax 45 --metrics grade_metrics.csv --plot grade_plot.png
```


## v0.7 multi-objective controller

The workbench now includes a first real multi-objective control scheme: `moev` / **Multi-objective EV cascade**.  It adds an outer speed loop, an inner torque-current loop, and a battery/SOC energy supervisor.  This is different from earlier versions where EV quantities such as torque, SOC and km/kWh were mainly metrics around a single speed loop.

Example:

```bash
python cli.py run --plant evdc --scenario grade_adaptive --schemes moev pid --duration 8 --dt 0.1 --soc0 55 --payload 35 --grade 4 --grade-amp 2.5 --metrics multiobj_metrics.csv --plot multiobj_plot.png
```
