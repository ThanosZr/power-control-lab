from pathlib import Path
import sys
root = Path(__file__).resolve().parent
print("PROJECT ROOT:", root)
print("PYTHON:", sys.executable)
print("sys.path[0]:", sys.path[0])
print("plants folder exists:", (root / "plants").exists())
print("plants/ev_dc_drive.py exists:", (root / "plants" / "ev_dc_drive.py").exists())
print("plants/sync_harmonic_drive.py exists:", (root / "plants" / "sync_harmonic_drive.py").exists())
print("Files in plants:")
for p in sorted((root / "plants").glob("*.py")):
    print(" -", p.name)
for mod in ["plants.ev_dc_drive", "plants.sync_harmonic_drive", "schemes.harmonic_injection", "bootstrap"]:
    try:
        __import__(mod)
        print(f"OK: import {mod}")
    except Exception as e:
        print(f"ERROR importing {mod}:", repr(e))
        raise
