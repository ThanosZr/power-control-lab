# Patch notes v0.6 — Vehicle settings panel and realistic speed scaling

This patch adds a dedicated **Vehicle settings** dialog for the EV/DC plant.
The goal is to make the simulated vehicle feel less like a tiny RC car and more
like a configurable electric-drive test vehicle.

## New GUI button

A new button appears in the top bar:

```text
Vehicle settings
```

It opens a vehicle/route configuration dialog. These values are **plant
parameters**, so they are applied after pressing:

```text
Apply & rebuild
```

## New configurable vehicle characteristics

The dialog exposes:

| Parameter | Meaning |
|---|---|
| `vehicle mass kg` | vehicle + driver mass, excluding extra payload |
| `wheel radius m` | wheel radius used for vehicle speed and road-load conversion |
| `gear ratio` | motor speed / wheel speed |
| `drivetrain eta` | mechanical drivetrain efficiency |
| `rolling Crr` | rolling resistance coefficient |
| `CdA m²` | aerodynamic drag area |
| `target max speed km/h` | caps/scales the reference speed target |
| `grade period m` | distance period of grade ripple |
| `load period m` | distance period of variable load torque |

## Presets

The dialog includes three quick presets:

```text
Eco prototype
Urban kart
RC toy
```

These are not validated vehicle datasets. They are practical starting points for
different visual/physical scales.

## Why the speed looked too small

Earlier versions used mostly motor-speed `ω` and hidden vehicle parameters. The
3-D view and loop diagram could therefore look like a generic small motor even
when the system-level vehicle model was intended to represent a lightweight EV.

v0.6 now exposes vehicle-level settings and logs live vehicle speed:

```text
vehicle speed [km/h]
grade [%]
vehicle mass [kg]
target vmax [km/h]
```

## Updated CLI example

```bat
python cli.py run --plant evdc --scenario grade_adaptive --schemes pid ^
  --duration 8 --dt 0.1 --soc0 55 --payload 35 --grade 4 --grade-amp 2.5 ^
  --vehicle-mass 115 --wheel-radius 0.255 --gear 7 --target-vmax 45 ^
  --metrics grade_metrics.csv --plot grade_plot.png
```

## Interpretation

This is still a control-level EV/DC model, not a full validated powertrain. The
new settings make the simulation scale more transparent and allow sweeps over
vehicle mass, wheel size, gearing, drag, rolling resistance, and reference speed
cap before moving the concept into MATLAB/Simulink.
