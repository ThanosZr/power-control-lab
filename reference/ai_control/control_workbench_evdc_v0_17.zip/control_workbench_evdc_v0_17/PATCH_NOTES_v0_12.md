# Patch notes v0.12 — live power/metric stabilization

This patch fixes the confusing live-state behavior observed in v0.11 where several EV variables could appear to jump wildly even while vehicle speed and motor speed looked reasonable.

## What was wrong

### 1. Battery power display could be inconsistent

The battery model computed a requested/limited battery power and then clipped battery current. In some transient cases, the live panel could therefore show physically inconsistent combinations such as:

- reasonable `Vbat`
- reasonable `Ibat`
- but impossible `Pbat`

The corrected logged/displayed `p_bat_W` is now always based on terminal battery quantities after current limiting:

```text
Pbat = Vbat * Ibat
```

The older requested/model-side value is retained as:

```text
p_bat_request_W
```

for debugging.

### 2. Instantaneous ratios are naturally noisy at startup

Metrics such as `km/kWh`, `Wh/km`, and `Nm/kW` are ratios. During the first few seconds, distance and energy are tiny, so a small numerical or transient change can produce large apparent swings.

The GUI now shows:

- instantaneous metrics, still useful for debugging
- recent-window averaged metrics, better for interpretation
- a warm-up message until enough distance/energy has accumulated

## Files changed

- `plants/ev_dc_drive.py`
- `plants/sync_harmonic_drive.py`
- `gui/app.py`

## Interpretation guide

Use instantaneous values to diagnose controller transients.
Use recent-window averages and final CSV metrics to compare controllers.

For harmonic-injection experiments, compare:

```bash
python cli.py run --plant spmsm_harm --scenario grade_adaptive --schemes hinj pid --duration 8 --dt 0.05 --soc0 70 --grade 3 --grade-amp 2 --vehicle-mass 115 --wheel-radius 0.255 --gear 7 --target-vmax 45 --metrics spmsm_hinj_metrics.csv --plot spmsm_hinj_plot.png
```

Do not trust `km/kWh`, `Wh/km`, or `Nm/kW` from the first few meters of simulation.
