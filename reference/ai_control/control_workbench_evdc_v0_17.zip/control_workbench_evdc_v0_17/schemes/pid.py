"""A classical PID speed controller — the baseline the learning controller is
compared against in the comparison table. Single step: close the loop over the
reference. No model, no learning; it just needs the plant's `step`.
"""
from __future__ import annotations

from typing import Dict, List

import numpy as np

from core.registry import register_scheme
from core.scheme import (ControlScheme, DrawContext, LayerSpec, SimFrame, Step)


@register_scheme
class PIDControl(ControlScheme):
    id = "pid"
    name = "PID baseline"
    color = "#2ca02c"

    STEPS = [
        Step("run", "Closed-loop run",
             description="Run a fixed-gain PID controller over the reference.",
             rerunnable=True),
    ]

    def __init__(self, plant, reference, dt, params):
        super().__init__(plant, reference, dt, params)
        ulo, uhi = plant.u_range()
        self.u_lo, self.u_hi = ulo, uhi
        self.kp = float(self.params.get("kp", 2.5))
        self.ki = float(self.params.get("ki", 6.0))
        self.kd = float(self.params.get("kd", 0.05))
        self._reset_run()

    def _reset_run(self):
        self.k = 0
        self.integ = 0.0
        self.prev_e = 0.0
        self.plant.reset_state()
        self.log = {key: [] for key in ("t", "r", "y", "u", "e", "i_arm")}

    def micro_step(self):
        self.active_step_id = "run"
        if "run" in self._done_steps:
            self._done_steps.discard("run")
            self._reset_run()
        if self.k == 0:
            self._reset_run()
        live = self.setpoint is not None
        cont = self.run_continuous
        n = len(self.reference)
        if not live and not cont and self.k >= n - 1:
            self._done_steps.add("run")
            return None

        self.cost.start()
        if live:
            r = float(self.setpoint)
        elif cont:
            r = float(self.reference[self.k % n])
        else:
            r = float(self.reference[self.k])
        y = self.plant.output()
        e = r - y
        self.integ += e * self.dt
        deriv = (e - self.prev_e) / self.dt
        u = self.kp * e + self.ki * self.integ + self.kd * deriv
        u = float(np.clip(u, self.u_lo, self.u_hi))
        # anti-windup: undo integration if saturated
        if u in (self.u_lo, self.u_hi):
            self.integ -= e * self.dt
        self.plant.step(u, self.dt)
        self.prev_e = e
        self.cost.sim_steps += 1
        self.cost.stop()

        vz = self.plant.viz_state()
        for key, val in (("t", self.k * self.dt), ("r", r), ("y", y),
                         ("u", u), ("e", e), ("i_arm", vz.get("current", 0.0))):
            self.log[key].append(val)
        self._append_viz_to_log(vz)
        self.k += 1
        if (live or cont) and len(self.log["t"]) > self.live_log_cap:
            for key in self.log:
                self.log[key] = self.log[key][-self.live_log_cap:]
        self.last_signals = {"r": r, "y": y, "u": u, "e": e,
                             "y_hat": y, "e_star": 0.0}
        return self._frame("run", "control",
                           f"t={self.k*self.dt:5.2f}s  r={r:6.2f}  y={y:6.2f}  e={e:6.2f}",
                           signals=dict(self.last_signals), viz=vz)

    # ---- results / comparison ----------------------------------------- #
    def result(self) -> dict:
        d = super().result()
        d["log"] = {k: list(v) for k, v in self.log.items()}
        d["metrics"] = self.metrics()
        return d

    def load_result(self, data):
        super().load_result(data)
        self.log = {k: list(v) for k, v in data.get("log", {}).items()}

    def comparison_rows(self) -> List[dict]:
        if not self.log.get("y"):
            return []
        m = self.metrics()
        row = {
            "scheme": self.name, "variant": "PID", "plant": self.plant.name,
            "rmse": round(m["rmse"], 4), "sse": round(m["sse"], 4),
            "overshoot_pct": round(m["overshoot_pct"], 2),
            "control_effort": round(m["control_effort"], 3),
            "sim_steps": self.cost.sim_steps, "grad_updates": 0,
            "ms": round(self.cost.elapsed_ms, 1),
        }
        for key in ("km_per_kwh", "wh_per_km", "nm_per_kw", "rms_current_a",
                    "final_soc_pct", "soc_drop_pctpts", "peak_torque_nm", "mean_v_sag"):
            if key in m:
                row[key] = round(m[key], 4 if key in ("km_per_kwh", "nm_per_kw") else 3)
        return [row]

    # ---- visuals ------------------------------------------------------- #
    def layers(self) -> List[LayerSpec]:
        return [LayerSpec("track", "reference vs output", True),
                LayerSpec("error", "tracking error", True),
                LayerSpec("control", "control voltage", True),
                LayerSpec("energy", "EV energy / SOC", False)]

    def draw_signals(self, fig, ctx: DrawContext) -> None:
        _draw_timeseries(fig, self, ctx)


def _draw_timeseries(fig, scheme, ctx: DrawContext) -> None:
    """Shared time-series renderer (PID + inverse control reuse it)."""
    log = scheme.log
    if not log.get("t"):
        ax = fig.add_subplot(111)
        ax.text(0.5, 0.5, f"Run '{scheme.name}' to see signals",
                ha="center", va="center", transform=ax.transAxes, color="#888")
        ax.set_axis_off()
        return
    on = ctx.layer_on
    panels = []
    if on.get("track", True):
        panels.append("track")
    if on.get("error", True):
        panels.append("error")
    if on.get("control", True):
        panels.append("control")
    if log.get("y_hat") and on.get("emulator", False):
        panels.append("emulator")
    if on.get("energy", False) and (log.get("soc_pct") or log.get("p_bat_W") or log.get("km_per_kwh_live")):
        panels.append("energy")
    panels = panels or ["track"]

    t = log["t"]
    axes = fig.subplots(len(panels), 1, sharex=True, squeeze=False)[:, 0]
    for ax, kind in zip(axes, panels):
        if kind == "track":
            ax.plot(t, log["r"], "--", color="#555", lw=1.5, label="reference r")
            ax.plot(t, log["y"], color=scheme.color, lw=1.8, label="output y")
            ax.set_ylabel("speed")
            ax.legend(loc="best", fontsize=8)
        elif kind == "error":
            ax.plot(t, log["e"], color="#d62728", lw=1.3, label="error e = r−y")
            ax.axhline(0, color="#aaa", lw=0.8)
            ax.set_ylabel("error")
            ax.legend(loc="best", fontsize=8)
        elif kind == "control":
            ax.plot(t, log["u"], color="#1f77b4", lw=1.3, label="control u")
            ax.set_ylabel("voltage")
            ax.legend(loc="best", fontsize=8)
        elif kind == "emulator":
            ax.plot(t, log["y"], color=scheme.color, lw=1.5, label="plant y")
            ax.plot(t, log["y_hat"], ":", color="#9467bd", lw=1.5, label="emulator ŷ")
            ax.set_ylabel("emulator")
            ax.legend(loc="best", fontsize=8)
        elif kind == "energy":
            if log.get("soc_pct"):
                ax.plot(t, log["soc_pct"], lw=1.4, label="SOC [%]")
            if log.get("p_bat_W"):
                ax.plot(t, [v / 1000.0 for v in log["p_bat_W"]], lw=1.2, label="Pbat [kW]")
            if log.get("km_per_kwh_live"):
                ax.plot(t, log["km_per_kwh_live"], lw=1.2, label="km/kWh live")
            if log.get("nm_per_kw_live"):
                ax.plot(t, log["nm_per_kw_live"], lw=1.2, label="Nm/kW live")
            ax.set_ylabel("energy")
            ax.legend(loc="best", fontsize=8)
        ax.grid(True, alpha=0.25)
    axes[-1].set_xlabel("time [s]")
    fig.suptitle(f"{scheme.name} — closed-loop signals", fontsize=11)
