"""Multi-objective cascaded EV/DC controller.

This scheme is the first real multi-objective control implementation in the
workbench.  It is intentionally still lightweight: it does not replace the
existing ANN inverse controller, but it adds a second, explicit control loop so
that the EV/DC model can be controlled through both:

1. vehicle/motor speed tracking, and
2. motor torque/current tracking under energy/SOC constraints.

Structure
---------
reference speed r_omega
        |
        v
outer speed PI + road-load feed-forward  -> torque reference tau_ref
        |
        v
SOC/energy supervisor                    -> constrained tau_ref_limited
        |
        v
inner current/torque PI + back-EMF FF     -> converter/motor voltage command
        |
        v
Battery + boost + DC motor + vehicle plant

This is the bridge between the original single-output inverse-control demo and
the later ANN-pair architecture: the speed loop, torque loop and energy
supervisor are separate modules and can later each be replaced by an
emulator+inverse ANN pair.
"""
from __future__ import annotations

from typing import Dict, List

import numpy as np

from core.registry import register_scheme
from core.scheme import ControlScheme, DrawContext, LayerSpec, Step

_EPS = 1e-9


@register_scheme
class MultiObjectiveEVControl(ControlScheme):
    id = "moev"
    name = "Multi-objective EV cascade"
    color = "#ff7f0e"

    STEPS = [
        Step("run", "Speed + torque + energy run",
             description=("Run a cascaded controller: outer speed loop, inner "
                          "torque/current loop, and SOC/power supervisor."),
             rerunnable=True),
    ]

    def __init__(self, plant, reference, dt, params):
        super().__init__(plant, reference, dt, params)
        ulo, uhi = plant.u_range()
        self.u_lo, self.u_hi = ulo, uhi

        # Outer speed loop [rad/s -> Nm].  The feed-forward road-load term is
        # the scientific/physical part: slope, rolling resistance and aero load
        # become a torque demand instead of being hidden inside the error term.
        self.kp_w = float(self.params.get("kp_w", 0.20))
        self.ki_w = float(self.params.get("ki_w", 0.60))
        self.kd_w = float(self.params.get("kd_w", 0.000))

        # Inner torque/current loop [A -> V].  Torque = Kt*i for the DC motor,
        # so this is a complete second control loop, not just a metric.
        self.kp_i = float(self.params.get("kp_i", 0.02))
        self.ki_i = float(self.params.get("ki_i", 0.0))

        # Multi-objective supervisor parameters.  These weights/limits encode
        # the compromise between performance, current stress and energy use.
        self.mode = str(self.params.get("mode", "balanced")).lower()
        self.speed_weight = float(self.params.get("speed_weight", 1.0))
        self.energy_weight = float(self.params.get("energy_weight", 0.55))
        self.torque_weight = float(self.params.get("torque_weight", 0.75))
        self.torque_limit_nm = float(self.params.get("torque_limit_nm", 40.0))
        self.power_limit_kw = float(self.params.get("power_limit_kw", 8.0))
        self.current_limit_a = float(self.params.get("current_limit_a", 200.0))
        self.accel_tau_limit_nm = float(self.params.get("accel_tau_limit_nm", 40.0))

        if self.mode == "eco":
            self.energy_weight = max(self.energy_weight, 0.85)
            self.torque_weight = min(self.torque_weight, 0.55)
            self.power_limit_kw *= 0.65
            self.current_limit_a *= 0.70
        elif self.mode == "performance":
            self.energy_weight = min(self.energy_weight, 0.25)
            self.torque_weight = max(self.torque_weight, 0.95)
            self.power_limit_kw *= 1.35
            self.current_limit_a *= 1.25

        self._reset_run()

    def _reset_run(self):
        self.k = 0
        self.integ_w = 0.0
        self.prev_e_w = 0.0
        self.integ_i = 0.0
        self.constraint_events = 0
        self.plant.reset_state()
        self.log = {key: [] for key in (
            "t", "r", "y", "u", "e", "i_arm",
            "torque_ref", "torque_ref_raw", "torque_error", "i_ref",
            "speed_weight", "energy_weight", "torque_weight", "constraint_active",
            "target_vehicle_kph")}

    # ------------------------------------------------------------------ #
    def _plant_param(self, name: str, default: float) -> float:
        return float(getattr(self.plant, "p", {}).get(name, default))

    def _energy_supervisor(self, tau_raw: float, viz: Dict[str, float]) -> tuple[float, float]:
        """Return constrained torque reference and whether a constraint fired."""
        kt = max(self._plant_param("Kt", 0.2), _EPS)
        soc = float(viz.get("soc", 1.0))
        w = abs(float(viz.get("speed", 0.0)))
        v_bat = max(float(viz.get("v_bat", viz.get("v_ocv", 48.0))), 1.0)

        # SOC-aware derating.  The lower the SOC, the more the controller is
        # asked to preserve battery power/current instead of demanding torque.
        low_soc = np.clip((0.45 - soc) / 0.35, 0.0, 1.0)
        eco_bias = np.clip(self.energy_weight, 0.0, 1.5)
        soc_factor = 1.0 - 0.45 * low_soc * eco_bias
        soc_factor = float(np.clip(soc_factor, 0.35, 1.05))

        # Torque/current limit.
        tau_lim_current = self.current_limit_a * kt
        tau_lim = min(self.torque_limit_nm, tau_lim_current, self.accel_tau_limit_nm) * soc_factor

        # Battery power limit mapped to torque through P ≈ tau*omega.  At very
        # low speeds the torque limit dominates so we avoid singular behaviour.
        if w > 2.0:
            tau_lim_power = (self.power_limit_kw * 1000.0) / max(w, 2.0)
            tau_lim = min(tau_lim, tau_lim_power)

        # Weighted multi-objective allocation: performance modes keep more of
        # tau_raw; eco modes soften it even before hard clipping.
        keep = np.clip(0.55 + 0.45 * self.torque_weight - 0.20 * self.energy_weight * low_soc,
                       0.30, 1.05)
        tau_soft = float(tau_raw * keep)
        tau_limited = float(np.clip(tau_soft, -tau_lim, tau_lim))
        constrained = 1.0 if abs(tau_limited - tau_raw) > 1e-6 else 0.0
        if constrained:
            self.constraint_events += 1
        return tau_limited, constrained

    def micro_step(self):
        self.active_step_id = "run"
        if "run" in self._done_steps:
            self._done_steps.discard("run")
            self._reset_run()
        if self.k == 0:
            self._reset_run()
        live = self.setpoint is not None
        cont = self.run_continuous
        n = len(self.reference)
        if not live and not cont and self.k >= n - 1:
            self._done_steps.add("run")
            return None

        self.cost.start()
        r = float(self.setpoint if live else self.reference[self.k % n] if cont else self.reference[self.k])
        y = self.plant.output()
        vz0 = self.plant.viz_state()

        # Outer speed loop -> motor torque reference.
        e_w = r - y
        self.integ_w += e_w * self.dt
        d_w = (e_w - self.prev_e_w) / self.dt
        load_ff = float(vz0.get("load_torque", 0.0))
        visc_ff = self._plant_param("B", 0.0) * y
        tau_raw = (self.kp_w * e_w + self.ki_w * self.integ_w + self.kd_w * d_w)
        tau_raw = self.speed_weight * tau_raw + load_ff + visc_ff

        # Energy/SOC supervisor -> constrained torque command.
        tau_ref, constrained = self._energy_supervisor(tau_raw, vz0)

        # Inner torque/current loop.  Torque = Kt*i, so i_ref is the current
        # needed for the requested torque.  Add back-EMF and R*i feed-forward.
        kt = max(self._plant_param("Kt", 0.2), _EPS)
        ke = self._plant_param("Ke", 0.2)
        r_arm = self._plant_param("R", 0.22)
        i_meas = float(vz0.get("current", 0.0))
        i_ref = tau_ref / kt
        e_i = i_ref - i_meas
        self.integ_i += e_i * self.dt
        u = ke * y + r_arm * i_ref + self.kp_i * e_i + self.ki_i * self.integ_i
        u = float(np.clip(u, self.u_lo, self.u_hi))
        # anti-windup on the current loop
        if u in (self.u_lo, self.u_hi):
            self.integ_i -= e_i * self.dt

        self.plant.step(u, self.dt)
        self.prev_e_w = e_w
        self.cost.sim_steps += 1
        self.cost.stop()

        vz = self.plant.viz_state()
        target_vehicle_kph = 3.6 * r / max(self._plant_param("gear_ratio", 1.0), _EPS) * self._plant_param("wheel_radius", 0.25)
        values = {
            "t": self.k * self.dt,
            "r": r,
            "y": y,
            "u": u,
            "e": e_w,
            "i_arm": i_meas,
            "torque_ref": tau_ref,
            "torque_ref_raw": tau_raw,
            "torque_error": tau_ref - float(vz.get("torque", 0.0)),
            "i_ref": i_ref,
            "speed_weight": self.speed_weight,
            "energy_weight": self.energy_weight,
            "torque_weight": self.torque_weight,
            "constraint_active": constrained,
            "target_vehicle_kph": target_vehicle_kph,
        }
        for key, val in values.items():
            self.log[key].append(float(val))
        self._append_viz_to_log(vz)
        self.k += 1
        if (live or cont) and len(self.log["t"]) > self.live_log_cap:
            for key in self.log:
                self.log[key] = self.log[key][-self.live_log_cap:]
        self.last_signals = {"r": r, "y": y, "u": u, "e": e_w,
                             "tau_ref": tau_ref, "tau_raw": tau_raw,
                             "i_ref": i_ref, "constraint": constrained}
        return self._frame("run", "multi-objective",
                           f"t={self.k*self.dt:5.2f}s  ωref={r:6.2f}  ω={y:6.2f}  τref={tau_ref:+5.2f} Nm  u={u:+6.1f} V",
                           signals=dict(self.last_signals), viz=vz)

    # ------------------------------------------------------------------ #
    def result(self) -> dict:
        d = super().result()
        d["log"] = {k: list(v) for k, v in self.log.items()}
        d["metrics"] = self.metrics()
        d["constraint_events"] = self.constraint_events
        d["mode"] = self.mode
        return d

    def load_result(self, data):
        super().load_result(data)
        self.log = {k: list(v) for k, v in data.get("log", {}).items()}
        self.constraint_events = int(data.get("constraint_events", 0))

    def metrics(self) -> Dict[str, float]:
        out = super().metrics()
        if self.log.get("torque_ref") and self.log.get("torque"):
            tr = np.asarray(self.log["torque_ref"], dtype=float)
            tq = np.asarray(self.log["torque"], dtype=float)
            n = min(len(tr), len(tq))
            if n:
                terr = tr[:n] - tq[:n]
                out["torque_rmse_nm"] = float(np.sqrt(np.mean(terr ** 2)))
                out["mean_tau_ref_nm"] = float(np.mean(np.abs(tr[:n])))
        if self.log.get("constraint_active"):
            c = np.asarray(self.log["constraint_active"], dtype=float)
            out["constraint_pct"] = float(100.0 * np.mean(c))
        return out

    def comparison_rows(self) -> List[dict]:
        if not self.log.get("y"):
            return []
        m = self.metrics()
        row = {
            "scheme": self.name,
            "variant": f"cascade-{self.mode}",
            "plant": self.plant.name,
            "rmse": round(m.get("rmse", 0.0), 4),
            "sse": round(m.get("sse", 0.0), 4),
            "overshoot_pct": round(m.get("overshoot_pct", 0.0), 2),
            "control_effort": round(m.get("control_effort", 0.0), 3),
            "sim_steps": self.cost.sim_steps,
            "grad_updates": 0,
            "ms": round(self.cost.elapsed_ms, 1),
        }
        for key in ("km_per_kwh", "wh_per_km", "nm_per_kw", "rms_current_a",
                    "final_soc_pct", "soc_drop_pctpts", "peak_torque_nm", "mean_v_sag",
                    "torque_rmse_nm", "mean_tau_ref_nm", "constraint_pct"):
            if key in m:
                row[key] = round(m[key], 4 if key in ("km_per_kwh", "nm_per_kw", "torque_rmse_nm") else 3)
        return [row]

    def layers(self) -> List[LayerSpec]:
        return [LayerSpec("track", "reference vs output", True),
                LayerSpec("torque", "torque loop", True),
                LayerSpec("control", "control voltage", True),
                LayerSpec("energy", "EV energy / SOC", False),
                LayerSpec("error", "tracking error", False)]

    def draw_signals(self, fig, ctx: DrawContext) -> None:
        _draw_multiobjective_timeseries(fig, self, ctx)


def _draw_multiobjective_timeseries(fig, scheme, ctx: DrawContext) -> None:
    log = scheme.log
    if not log.get("t"):
        ax = fig.add_subplot(111)
        ax.text(0.5, 0.5, f"Run '{scheme.name}' to see signals",
                ha="center", va="center", transform=ax.transAxes, color="#888")
        ax.set_axis_off()
        return
    on = ctx.layer_on
    panels = []
    if on.get("track", True): panels.append("track")
    if on.get("torque", True): panels.append("torque")
    if on.get("control", True): panels.append("control")
    if on.get("energy", False): panels.append("energy")
    if on.get("error", False): panels.append("error")
    panels = panels or ["track"]
    t = log["t"]
    axes = fig.subplots(len(panels), 1, sharex=True, squeeze=False)[:, 0]
    for ax, kind in zip(axes, panels):
        if kind == "track":
            if log.get("r_cmd"):
                ax.plot(t, log["r_cmd"], ":", color="#777", lw=1.2, label="ω mission cmd")
            ax.plot(t, log["r"], "--", color="#555", lw=1.5, label="ω governed/reference")
            ax.plot(t, log["y"], color=scheme.color, lw=1.8, label="ω output")
            if log.get("target_vehicle_kph"):
                ax2 = ax.twinx()
                ax2.plot(t, log["target_vehicle_kph"], ":", lw=1.1, label="target km/h")
                if log.get("vehicle_speed_governed_kph"):
                    ax2.plot(t, log["vehicle_speed_governed_kph"], "--", lw=1.0, label="governed km/h")
                ax2.set_ylabel("target km/h")
            ax.set_ylabel("speed")
            ax.legend(loc="best", fontsize=8)
        elif kind == "torque":
            if log.get("torque_ref_raw"):
                ax.plot(t, log["torque_ref_raw"], ":", lw=1.2, label="raw τ request")
            ax.plot(t, log.get("torque_ref", []), "--", lw=1.4, label="limited τ ref")
            if log.get("torque"):
                ax.plot(t, log["torque"], color=scheme.color, lw=1.7, label="actual τ")
            if log.get("load_torque"):
                ax.plot(t, log["load_torque"], lw=1.0, alpha=0.8, label="load τ")
            ax.set_ylabel("torque [Nm]")
            ax.legend(loc="best", fontsize=8)
        elif kind == "control":
            ax.plot(t, log["u"], color="#1f77b4", lw=1.3, label="V command")
            if log.get("i_ref"):
                ax2 = ax.twinx()
                ax2.plot(t, log["i_ref"], ":", lw=1.1, label="i ref")
                ax2.set_ylabel("i ref [A]")
            ax.set_ylabel("voltage")
            ax.legend(loc="best", fontsize=8)
        elif kind == "energy":
            if log.get("soc_pct"):
                ax.plot(t, log["soc_pct"], lw=1.4, label="SOC [%]")
            if log.get("p_bat_W"):
                ax.plot(t, [v/1000.0 for v in log["p_bat_W"]], lw=1.2, label="Pbat [kW]")
            if log.get("km_per_kwh_live"):
                ax.plot(t, log["km_per_kwh_live"], lw=1.1, label="km/kWh live")
            if log.get("constraint_active"):
                ax.plot(t, log["constraint_active"], lw=1.0, label="constraint active")
            ax.set_ylabel("energy")
            ax.legend(loc="best", fontsize=8)
        elif kind == "error":
            ax.plot(t, log["e"], color="#d62728", lw=1.3, label="ω error")
            if log.get("torque_error"):
                ax.plot(t, log["torque_error"], lw=1.0, label="τ error")
            ax.axhline(0, color="#aaa", lw=0.8)
            ax.set_ylabel("errors")
            ax.legend(loc="best", fontsize=8)
        ax.grid(True, alpha=0.25)
    axes[-1].set_xlabel("time [s]")
    fig.suptitle(f"{scheme.name} — speed loop + torque loop + energy supervisor", fontsize=11)


@register_scheme
class CoupledMultiLoopEVControl(MultiObjectiveEVControl):
    """Coupled multi-loop EV controller with reference governor.

    This is the next step after ``moev``.  The important change is that speed
    and torque are no longer treated as two almost independent quantities.  A
    vehicle-dynamics coupler maps the speed objective into a physically required
    motor torque:

        tau_required = J_eq * alpha_ref + B*omega + tau_road_load

    Then a reference-governor / allocator checks whether that torque is feasible
    under current, power and SOC limits.  If not, it modifies the *effective*
    speed objective before the torque/current loop acts.  This makes the loops
    coupled in the way an EV drive actually is:

        speed target <-> acceleration demand <-> torque/current <-> battery power

    The scheme is still deterministic PI + feed-forward, not yet ANN-based.  It
    is deliberately structured so each block can later be replaced by an
    emulator+inverse ANN pair:

      1. speed/vehicle emulator + inverse speed-to-torque module
      2. torque/current emulator + inverse voltage module
      3. battery/energy emulator + inverse/supervisor allocation module
    """

    id = "moevc"
    name = "Coupled multi-loop EV control"
    color = "#2ca02c"

    STEPS = [
        Step("run", "Coupled speed + torque + energy run",
             description=("Run a coupled EV controller: speed reference governor, "
                          "vehicle-dynamics torque synthesis, inner current loop, "
                          "and SOC/power allocation."),
             rerunnable=True),
    ]

    def __init__(self, plant, reference, dt, params):
        super().__init__(plant, reference, dt, params)
        # Speed loop here works mostly as an acceleration planner.  Gains are
        # rad/s -> rad/s^2, then J_eq maps acceleration into torque.
        self.kp_alpha = float(self.params.get("kp_alpha", 2.2))
        self.ki_alpha = float(self.params.get("ki_alpha", 0.45))
        self.kd_alpha = float(self.params.get("kd_alpha", 0.04))
        self.alpha_limit = float(self.params.get("alpha_limit", 150.0))  # motor rad/s^2
        self.governor_horizon_s = float(self.params.get("governor_horizon_s", 0.85))
        self.road_ff_gain = float(self.params.get("road_ff_gain", 1.0))
        self.regen_torque_limit_nm = float(self.params.get("regen_torque_limit_nm", 16.0))
        self.torque_slew_nm_per_s = float(self.params.get("torque_slew_nm_per_s", 420.0))
        self.tau_prev = 0.0
        # Expose objective weights as real allocation knobs.
        if self.mode == "eco":
            self.speed_weight = min(self.speed_weight, 0.85)
            self.energy_weight = max(self.energy_weight, 0.95)
        elif self.mode == "performance":
            self.speed_weight = max(self.speed_weight, 1.10)
            self.energy_weight = min(self.energy_weight, 0.20)

    def _reset_run(self):
        super()._reset_run()
        self.integ_alpha = 0.0
        self.prev_e_gov = 0.0
        self.tau_prev = 0.0
        for key in (
            "r_cmd", "r_governed", "omega_feasible_next", "alpha_cmd",
            "alpha_feasible", "tau_road_ff", "tau_accel", "tau_available_pos",
            "tau_available_neg", "allocation_keep", "p_pred_kw", "constraint_reason",
            "vehicle_speed_ref_kph", "vehicle_speed_governed_kph"):
            self.log.setdefault(key, [])

    def _torque_limits(self, viz: Dict[str, float], w_abs: float) -> tuple[float, float, float, float]:
        """Return positive/negative torque limits and predicted power limit.

        Positive torque is traction.  Negative torque is regen/braking.  The
        limits combine motor torque/current, battery power and low-SOC derating.
        """
        kt = max(self._plant_param("Kt", 0.2), _EPS)
        soc = float(viz.get("soc", 1.0))
        low_soc = np.clip((0.45 - soc) / 0.35, 0.0, 1.0)
        soc_factor = 1.0 - 0.50 * low_soc * np.clip(self.energy_weight, 0.0, 1.4)
        soc_factor = float(np.clip(soc_factor, 0.30, 1.05))

        tau_current = self.current_limit_a * kt
        tau_pos = min(self.torque_limit_nm, tau_current) * soc_factor

        if w_abs > 2.0:
            tau_power = (self.power_limit_kw * 1000.0) / max(w_abs, 2.0)
            tau_pos = min(tau_pos, tau_power)
        else:
            tau_power = float("inf")

        # Regen/braking is intentionally more conservative in this first model.
        tau_neg = -min(self.regen_torque_limit_nm, tau_current * 0.55)
        return float(max(tau_pos, 0.0)), float(tau_neg), float(tau_power if np.isfinite(tau_power) else 0.0), soc_factor

    def _allocate(self, tau_request: float, tau_pos: float, tau_neg: float,
                  viz: Dict[str, float]) -> tuple[float, float, float, str]:
        """Apply multi-objective allocation and hard constraints."""
        w_abs = abs(float(viz.get("speed", 0.0)))
        p_pred_kw = abs(tau_request * w_abs) / 1000.0
        p_ratio = p_pred_kw / max(self.power_limit_kw, 1e-6)
        soc = float(viz.get("soc", 1.0))
        low_soc = np.clip((0.45 - soc) / 0.35, 0.0, 1.0)

        # Soft allocation before clipping: speed/performance preserves torque;
        # energy and low SOC reduce the request.  This is the explicit trade-off.
        keep = (0.72
                + 0.26 * np.clip(self.speed_weight, 0.0, 1.5)
                + 0.24 * np.clip(self.torque_weight, 0.0, 1.5)
                - 0.18 * np.clip(self.energy_weight, 0.0, 1.5) * low_soc
                - 0.08 * np.clip(p_ratio - 0.85, 0.0, 1.5))
        keep = float(np.clip(keep, 0.35, 1.15))
        tau_soft = tau_request * keep

        # Slew-rate keeps torque command physically smoother.
        max_step = self.torque_slew_nm_per_s * self.dt
        tau_slewed = float(np.clip(tau_soft, self.tau_prev - max_step, self.tau_prev + max_step))
        tau_limited = float(np.clip(tau_slewed, tau_neg, tau_pos))
        self.tau_prev = tau_limited

        reason = 0.0
        if abs(tau_limited - tau_request) > 1e-5:
            reason = 1.0  # generic allocation/limit active
            self.constraint_events += 1
        return tau_limited, keep, p_pred_kw, str(reason)

    def micro_step(self):
        self.active_step_id = "run"
        if "run" in self._done_steps:
            self._done_steps.discard("run")
            self._reset_run()
        if self.k == 0:
            self._reset_run()
        live = self.setpoint is not None
        cont = self.run_continuous
        n = len(self.reference)
        if not live and not cont and self.k >= n - 1:
            self._done_steps.add("run")
            return None

        self.cost.start()
        r_cmd = float(self.setpoint if live else self.reference[self.k % n] if cont else self.reference[self.k])
        y = self.plant.output()
        vz0 = self.plant.viz_state()
        p = self.plant.p
        gear = max(float(p.get("gear_ratio", 1.0)), _EPS)
        rw = max(float(p.get("wheel_radius", 0.25)), _EPS)
        j_eq = max(float(vz0.get("J_equiv", self._plant_param("J_motor", 0.02))), _EPS)
        b = self._plant_param("B", 0.0)

        # Feasibility governor.  Convert torque envelope into feasible angular
        # acceleration and do not let the effective reference ask for impossible
        # acceleration at this SOC/power/slope.
        tau_pos, tau_neg, tau_power_equiv, soc_factor = self._torque_limits(vz0, abs(y))
        tau_load = float(vz0.get("load_torque", 0.0))
        alpha_pos = (tau_pos - tau_load - b * y) / j_eq
        alpha_neg = (tau_neg - tau_load - b * y) / j_eq
        alpha_pos = float(np.clip(alpha_pos, -self.alpha_limit, self.alpha_limit))
        alpha_neg = float(np.clip(alpha_neg, -self.alpha_limit, self.alpha_limit))

        # r_governed is the target seen by the speed loop.  It is still based on
        # the driver/mission target, but limited by torque/power feasibility.
        e_cmd = r_cmd - y
        if e_cmd >= 0.0:
            max_delta = max(alpha_pos, 0.0) * self.governor_horizon_s
            r_gov = y + min(e_cmd, max_delta)
        else:
            max_delta = abs(min(alpha_neg, 0.0)) * self.governor_horizon_s
            r_gov = y - min(abs(e_cmd), max_delta)
        omega_feasible_next = y + (alpha_pos if e_cmd >= 0.0 else alpha_neg) * self.dt

        # Speed loop -> desired acceleration.  This is the first complete loop.
        e_w = r_gov - y
        self.integ_alpha += e_w * self.dt
        d_w = (e_w - self.prev_e_gov) / self.dt
        alpha_cmd = (self.kp_alpha * e_w + self.ki_alpha * self.integ_alpha + self.kd_alpha * d_w)
        alpha_cmd = float(np.clip(alpha_cmd, alpha_neg, alpha_pos))

        # Coupler: speed/acceleration objective becomes a torque request through
        # the vehicle dynamics, not by guesswork.  This couples omega and torque.
        tau_accel = j_eq * alpha_cmd
        tau_road_ff = self.road_ff_gain * tau_load + b * y
        tau_request = tau_road_ff + tau_accel

        # Multi-objective allocation: speed/torque/energy/SOC compromise.
        tau_ref, keep, p_pred_kw, reason = self._allocate(tau_request, tau_pos, tau_neg, vz0)
        constrained = 1.0 if reason != "0.0" else 0.0

        # Torque-current loop -> voltage command.  This is the second complete loop.
        kt = max(self._plant_param("Kt", 0.2), _EPS)
        ke = self._plant_param("Ke", 0.2)
        r_arm = self._plant_param("R", 0.22)
        i_meas = float(vz0.get("current", 0.0))
        i_ref = tau_ref / kt
        e_i = i_ref - i_meas
        self.integ_i += e_i * self.dt
        u = ke * y + r_arm * i_ref + self.kp_i * e_i + self.ki_i * self.integ_i
        u = float(np.clip(u, self.u_lo, self.u_hi))
        if u in (self.u_lo, self.u_hi):
            self.integ_i -= e_i * self.dt

        self.plant.step(u, self.dt)
        self.prev_e_gov = e_w
        self.cost.sim_steps += 1
        self.cost.stop()

        vz = self.plant.viz_state()
        target_vehicle_kph = 3.6 * r_cmd / gear * rw
        governed_vehicle_kph = 3.6 * r_gov / gear * rw
        values = {
            "t": self.k * self.dt,
            # Base metrics keep r as the governed reference so RMSE reflects
            # the feasible target.  r_cmd is also logged for mission error.
            "r": r_gov,
            "y": y,
            "u": u,
            "e": e_w,
            "i_arm": i_meas,
            "r_cmd": r_cmd,
            "r_governed": r_gov,
            "omega_feasible_next": omega_feasible_next,
            "alpha_cmd": alpha_cmd,
            "alpha_feasible": alpha_pos if e_cmd >= 0.0 else alpha_neg,
            "torque_ref": tau_ref,
            "torque_ref_raw": tau_request,
            "torque_error": tau_ref - float(vz.get("torque", 0.0)),
            "i_ref": i_ref,
            "speed_weight": self.speed_weight,
            "energy_weight": self.energy_weight,
            "torque_weight": self.torque_weight,
            "constraint_active": constrained,
            "constraint_reason": float(reason),
            "target_vehicle_kph": target_vehicle_kph,
            "vehicle_speed_ref_kph": target_vehicle_kph,
            "vehicle_speed_governed_kph": governed_vehicle_kph,
            "tau_road_ff": tau_road_ff,
            "tau_accel": tau_accel,
            "tau_available_pos": tau_pos,
            "tau_available_neg": tau_neg,
            "allocation_keep": keep,
            "p_pred_kw": p_pred_kw,
        }
        for key, val in values.items():
            self.log.setdefault(key, []).append(float(val))
        self._append_viz_to_log(vz)
        self.k += 1
        if (live or cont) and len(self.log["t"]) > self.live_log_cap:
            for key in self.log:
                self.log[key] = self.log[key][-self.live_log_cap:]
        self.last_signals = {"r": r_gov, "r_cmd": r_cmd, "y": y, "u": u, "e": e_w,
                             "tau_ref": tau_ref, "tau_request": tau_request,
                             "i_ref": i_ref, "constraint": constrained}
        return self._frame("run", "coupled multi-loop",
                           f"t={self.k*self.dt:5.2f}s  ωcmd={r_cmd:6.2f}  ωgov={r_gov:6.2f}  ω={y:6.2f}  τ={tau_ref:+5.2f} Nm",
                           signals=dict(self.last_signals), viz=vz)

    def metrics(self) -> Dict[str, float]:
        out = super().metrics()
        log = self.log
        if log.get("r_cmd") and log.get("y"):
            cmd = np.asarray(log["r_cmd"], dtype=float)
            y = np.asarray(log["y"], dtype=float)
            out["mission_rmse"] = float(np.sqrt(np.mean((cmd - y) ** 2)))
        if log.get("r_cmd") and log.get("r_governed"):
            cmd = np.asarray(log["r_cmd"], dtype=float)
            gov = np.asarray(log["r_governed"], dtype=float)
            out["reference_governor_activity"] = float(np.mean(np.abs(cmd - gov)))
        if log.get("allocation_keep"):
            out["mean_allocation_keep"] = float(np.mean(np.asarray(log["allocation_keep"], dtype=float)))
        return out

    def comparison_rows(self) -> List[dict]:
        rows = super().comparison_rows()
        if not rows:
            return rows
        m = self.metrics()
        rows[0]["variant"] = f"coupled-{self.mode}"
        for key in ("mission_rmse", "reference_governor_activity", "mean_allocation_keep"):
            if key in m:
                rows[0][key] = round(m[key], 4)
        return rows

    def draw_signals(self, fig, ctx: DrawContext) -> None:
        _draw_multiobjective_timeseries(fig, self, ctx)
