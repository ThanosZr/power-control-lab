"""Simplified harmonic-injection controller for the SPMSM harmonic plant.

The controller uses the same structure as the coupled EV controller:

    speed governor -> torque/current loop -> base voltage command

and adds one parallel feed-forward branch:

    rotor electrical angle + speed -> harmonic voltage estimate -> v_harm

The plant has a non-sinusoidal back-EMF disturbance e_h(theta_e, omega).  In the
q-axis current equation the disturbance appears as

    Lq di/dt = vq - Rs*iq - Ke*omega - e_h

so the simplest harmonic-cancellation action is to add approximately

    v_harm = + gain * e_h

before the inverter/battery envelope.  This is intentionally a Python-level
model, not a three-phase SVPWM implementation.  It shows how the multi-loop
control framework can host a harmonic compensation module before MATLAB/Simulink
gets the high-fidelity PMSM/inverter model.
"""
from __future__ import annotations

from typing import Dict, List

import numpy as np

from core.registry import register_scheme
from core.scheme import DrawContext, LayerSpec, Step
from schemes.multi_objective import CoupledMultiLoopEVControl, _EPS


@register_scheme
class HarmonicInjectionControl(CoupledMultiLoopEVControl):
    id = "hinj"
    name = "SPMSM harmonic injection control"
    color = "#9467bd"

    STEPS = [
        Step("run", "Speed + torque + harmonic injection run",
             description=("Run coupled speed/torque control and add a simplified "
                          "harmonic voltage feed-forward term for the SPMSM harmonic plant."),
             rerunnable=True),
    ]

    def __init__(self, plant, reference, dt, params):
        super().__init__(plant, reference, dt, params)
        self.harmonic_enabled = bool(self.params.get("harmonic_enabled", True))
        self.harmonic_gain = float(self.params.get("harmonic_gain", 1.0))
        self.harmonic_limit_v = float(self.params.get("harmonic_limit_v", 18.0))

    def _reset_run(self):
        super()._reset_run()
        for key in ("u_base", "u_harm", "u_total", "bemf_harmonic", "harmonic_gain",
                    "harmonic_thd_proxy", "harmonic_thd_raw_proxy",
                    "harmonic_thd_signed_proxy", "harmonic_thd_residual_proxy",
                    "harmonic_cancellation_pct", "torque_ripple", "harmonic_enabled_state",
                    "u_h5", "u_h7", "u_h11", "u_h13",
                    "bemf_h5", "bemf_h7", "bemf_h11", "bemf_h13",
                    "bemf_amp_h5", "bemf_amp_h7", "bemf_amp_h11", "bemf_amp_h13",
                    "u_amp_h5", "u_amp_h7", "u_amp_h11", "u_amp_h13",
                    "resid_h5", "resid_h7", "resid_h11", "resid_h13",
                    "resid_amp_h5", "resid_amp_h7", "resid_amp_h11", "resid_amp_h13",
                    "current_thd_raw_proxy", "current_thd_residual_proxy",
                    "i_harm_raw_rms_A", "i_harm_residual_rms_A",
                    "torque_ripple_current_raw_nm", "torque_ripple_current_residual_nm",
                    "harmonic_loss_raw_W", "harmonic_loss_residual_W",
                    "p_bat_effective_W", "km_per_kwh_effective_inst",
                    "wh_per_km_effective_inst", "nm_per_kw_effective_inst",
                    "cf_on_current_thd_residual_proxy", "cf_off_current_thd_residual_proxy",
                    "cf_on_harmonic_loss_residual_W", "cf_off_harmonic_loss_residual_W",
                    "cf_on_torque_ripple_current_residual_nm", "cf_off_torque_ripple_current_residual_nm",
                    "cf_on_km_per_kwh_effective_inst", "cf_off_km_per_kwh_effective_inst",
                    "cf_on_u_harm", "cf_off_u_harm"):
            self.log.setdefault(key, [])

    def _harmonic_details(self, viz: Dict[str, float], enabled=None, gain=None, limit_v=None) -> Dict[str, float]:
        """Return total/per-order harmonic injection values.

        This is a lightweight Python analogue of harmonic compensation reconstruction:

            U_h(t) = sum_h A_h cos(h*theta_e + phi_h)

        A high-fidelity model obtains A_h and phi_h from a detailed harmonic-amplitude maps.  Here they come from
        the synthetic SPMSM harmonic plant.  The key distinction is preserved:
        * per-order harmonic content exists even when instantaneous signed terms
          cancel,
        * injected voltage is decomposed by order, and
        * residual harmonic content is computed order-by-order.
        """
        orders = (5, 7, 11, 13)
        enabled = self.harmonic_enabled if enabled is None else bool(enabled)
        gain = self.harmonic_gain if gain is None else float(gain)
        limit_v = self.harmonic_limit_v if limit_v is None else float(limit_v)

        details = {}
        for h in orders:
            details[f"bemf_h{h}"] = float(viz.get(f"bemf_h{h}", 0.0))
            details[f"bemf_amp_h{h}"] = float(abs(viz.get(f"bemf_amp_h{h}", details[f"bemf_h{h}"])))

        if not enabled:
            details.update({f"u_h{h}": 0.0 for h in orders})
            details.update({f"u_amp_h{h}": 0.0 for h in orders})
            details.update({"u_harm": 0.0, "harmonic_scale": 0.0, "harmonic_raw": 0.0})
            return details

        raw_parts = {h: gain * details[f"bemf_h{h}"] for h in orders}
        raw_total = float(sum(raw_parts.values()))
        clipped = float(np.clip(raw_total, -limit_v, limit_v))
        scale = clipped / raw_total if abs(raw_total) > _EPS else 0.0
        amp_scale = abs(gain * scale)
        for h in orders:
            details[f"u_h{h}"] = float(raw_parts[h] * scale)
            details[f"u_amp_h{h}"] = float(amp_scale * details[f"bemf_amp_h{h}"])
        details.update({"u_harm": clipped, "harmonic_scale": float(scale), "harmonic_raw": raw_total})
        return details

    def _harmonic_quality(self, viz: Dict[str, float], harm: Dict[str, float]) -> Dict[str, float]:
        """Reference-style diagnostic proxies for the simplified harmonic model.

        These are not real FFT current THD. They are same-state estimates based
        on residual harmonic voltage divided by per-order q-axis impedance.
        This makes live ON/OFF comparisons meaningful without mixing in the
        cumulative launch energy already stored in the plant.
        """
        orders = (5, 7, 11, 13)
        ebase_abs = max(abs(float(viz.get("back_emf", 0.0))), _EPS)
        residual_parts = {h: float(harm.get(f"bemf_h{h}", 0.0) - harm.get(f"u_h{h}", 0.0)) for h in orders}
        raw_rss = float(np.sqrt(sum(float(harm.get(f"bemf_h{h}", 0.0)) ** 2 for h in orders)))
        residual_rss = float(np.sqrt(sum(v ** 2 for v in residual_parts.values())))
        thd_raw = raw_rss / ebase_abs
        thd_residual = residual_rss / ebase_abs

        rs = float(getattr(self.plant, "p", {}).get("Rs", getattr(self.plant, "p", {}).get("R", 0.2)))
        lq = float(getattr(self.plant, "p", {}).get("Lq", getattr(self.plant, "p", {}).get("L", 0.003)))
        kt = float(getattr(self.plant, "p", {}).get("Kt", 0.2))
        pp = float(getattr(self.plant, "p", {}).get("pole_pairs", 1.0))
        omega_m = abs(float(viz.get("speed", viz.get("omega", 0.0))))
        omega_e = abs(pp * omega_m)
        iq_abs = max(abs(float(viz.get("iq", viz.get("current", 0.0)))), 1e-3)

        raw_i2 = 0.0
        resid_i2 = 0.0
        residual_amp_parts = {}
        raw_i_parts = {}
        resid_i_parts = {}
        for h in orders:
            amp = float(harm.get(f"bemf_amp_h{h}", abs(harm.get(f"bemf_h{h}", 0.0))))
            uamp = float(harm.get(f"u_amp_h{h}", 0.0))
            # abs(), not max(...,0): over-injection should show as residual again.
            ramp = abs(amp - uamp)
            residual_amp_parts[h] = ramp
            zmag = float(np.sqrt(rs * rs + (h * omega_e * lq) ** 2))
            ih_raw = amp / max(zmag, _EPS)
            ih_resid = ramp / max(zmag, _EPS)
            raw_i_parts[h] = ih_raw
            resid_i_parts[h] = ih_resid
            raw_i2 += ih_raw ** 2
            resid_i2 += ih_resid ** 2

        ih_raw_rms = float(np.sqrt(raw_i2))
        ih_resid_rms = float(np.sqrt(resid_i2))
        current_thd_raw = ih_raw_rms / iq_abs
        current_thd_residual = ih_resid_rms / iq_abs
        cancellation_pct = 100.0 * (1.0 - current_thd_residual / max(current_thd_raw, _EPS))

        # Proxy AC copper loss due to harmonic current content.  Small here,
        # because Lq filters the harmonic currents down to ~1% THD.
        loss_scale = float(self.params.get("harmonic_loss_scale", 3.0))
        p_harm_raw_cu = float(loss_scale * rs * raw_i2)
        p_harm_resid_cu = float(loss_scale * rs * resid_i2)

        # Frequency-weighted harmonic IRON / eddy-current loss proxy (v0.17).
        # Core loss tracks the harmonic flux pulsation -- driven by the harmonic
        # back-EMF, NOT by the heavily Lq-filtered harmonic *current*.  This is
        # the dominant mechanism behind the compensation's efficiency gain in the
        # reference, and the reason the earlier copper-only proxy showed ~0 benefit
        # (cancelling ~1% harmonic current saves negligible I^2*R).  Eddy-type
        # weighting per order:  P_fe(h) ~ fe_scale * h^fe_exp * E_h^2 .  The
        # injection cancels E_h, so the residual iron loss -> 0 with ON, which
        # is what finally makes the effective km/kWh respond ON vs OFF.  Set
        # harmonic_iron_loss_scale = 0 to recover the pure copper-loss model.
        fe_scale = float(self.params.get("harmonic_iron_loss_scale", 0.18))
        fe_exp = float(self.params.get("harmonic_iron_freq_exp", 1.0))
        raw_fe = 0.0
        resid_fe = 0.0
        for h in orders:
            amp_h = float(harm.get(f"bemf_amp_h{h}", abs(harm.get(f"bemf_h{h}", 0.0))))
            w = float(h) ** fe_exp
            raw_fe += w * amp_h * amp_h
            resid_fe += w * residual_amp_parts[h] * residual_amp_parts[h]
        p_harm_raw_fe = float(fe_scale * raw_fe)
        p_harm_resid_fe = float(fe_scale * resid_fe)

        p_harm_raw = p_harm_raw_cu + p_harm_raw_fe
        p_harm_resid = p_harm_resid_cu + p_harm_resid_fe
        torque_ripple_raw = float(abs(kt) * ih_raw_rms)
        torque_ripple_resid = float(abs(kt) * ih_resid_rms)

        p_bat_base = float(viz.get("p_bat_W", 0.0))
        p_eff = p_bat_base + max(p_harm_resid, 0.0)
        speed_kph = max(float(viz.get("vehicle_speed_kph", 0.0)), 0.0)
        km_per_kwh_eff = speed_kph / (p_eff / 1000.0) if p_eff > 1e-6 else 0.0
        wh_per_km_eff = 1000.0 / km_per_kwh_eff if km_per_kwh_eff > 1e-9 else 0.0
        torque = abs(float(viz.get("torque", 0.0)))
        nm_per_kw_eff = torque / (p_eff / 1000.0) if p_eff > 1e-6 else 0.0

        out = {
            "residual_parts": residual_parts,
            "residual_amp_parts": residual_amp_parts,
            "harmonic_thd_raw_proxy": float(thd_raw),
            "harmonic_thd_residual_proxy": float(thd_residual),
            "current_thd_raw_proxy": float(current_thd_raw),
            "current_thd_residual_proxy": float(current_thd_residual),
            "harmonic_cancellation_pct": float(cancellation_pct),
            "i_harm_raw_rms_A": ih_raw_rms,
            "i_harm_residual_rms_A": ih_resid_rms,
            "torque_ripple_current_raw_nm": torque_ripple_raw,
            "torque_ripple_current_residual_nm": torque_ripple_resid,
            "harmonic_loss_raw_W": p_harm_raw,
            "harmonic_loss_residual_W": p_harm_resid,
            "harmonic_iron_loss_raw_W": p_harm_raw_fe,
            "harmonic_iron_loss_residual_W": p_harm_resid_fe,
            "harmonic_copper_loss_raw_W": p_harm_raw_cu,
            "harmonic_copper_loss_residual_W": p_harm_resid_cu,
            "p_bat_effective_W": p_eff,
            "km_per_kwh_effective_inst": km_per_kwh_eff,
            "wh_per_km_effective_inst": wh_per_km_eff,
            "nm_per_kw_effective_inst": nm_per_kw_eff,
        }
        for h in orders:
            out[f"i_h{h}_raw_A"] = float(raw_i_parts[h])
            out[f"i_h{h}_residual_A"] = float(resid_i_parts[h])
        return out

    def _harmonic_voltage(self, viz: Dict[str, float]) -> float:
        return float(self._harmonic_details(viz)["u_harm"])

    def micro_step(self):
        self.active_step_id = "run"
        if "run" in self._done_steps:
            self._done_steps.discard("run")
            self._reset_run()
        if self.k == 0:
            self._reset_run()
        live = self.setpoint is not None
        cont = self.run_continuous
        n = len(self.reference)
        if not live and not cont and self.k >= n - 1:
            self._done_steps.add("run")
            return None

        self.cost.start()
        r_cmd = float(self.setpoint if live else self.reference[self.k % n] if cont else self.reference[self.k])
        y = self.plant.output()
        vz0 = self.plant.viz_state()
        p = self.plant.p
        gear = max(float(p.get("gear_ratio", 1.0)), _EPS)
        rw = max(float(p.get("wheel_radius", 0.25)), _EPS)
        j_eq = max(float(vz0.get("J_equiv", self._plant_param("J_motor", 0.02))), _EPS)
        b = self._plant_param("B", 0.0)

        # Same coupled reference-governor and speed-to-torque mapping as moevc.
        tau_pos, tau_neg, tau_power_equiv, soc_factor = self._torque_limits(vz0, abs(y))
        tau_load = float(vz0.get("load_torque", 0.0))
        alpha_pos = (tau_pos - tau_load - b * y) / j_eq
        alpha_neg = (tau_neg - tau_load - b * y) / j_eq
        alpha_pos = float(np.clip(alpha_pos, -self.alpha_limit, self.alpha_limit))
        alpha_neg = float(np.clip(alpha_neg, -self.alpha_limit, self.alpha_limit))

        e_cmd = r_cmd - y
        if e_cmd >= 0.0:
            max_delta = max(alpha_pos, 0.0) * self.governor_horizon_s
            r_gov = y + min(e_cmd, max_delta)
        else:
            max_delta = abs(min(alpha_neg, 0.0)) * self.governor_horizon_s
            r_gov = y - min(abs(e_cmd), max_delta)
        omega_feasible_next = y + (alpha_pos if e_cmd >= 0.0 else alpha_neg) * self.dt

        e_w = r_gov - y
        self.integ_alpha += e_w * self.dt
        d_w = (e_w - self.prev_e_gov) / self.dt
        alpha_cmd = self.kp_alpha * e_w + self.ki_alpha * self.integ_alpha + self.kd_alpha * d_w
        alpha_cmd = float(np.clip(alpha_cmd, alpha_neg, alpha_pos))

        tau_accel = j_eq * alpha_cmd
        tau_road_ff = self.road_ff_gain * tau_load + b * y
        tau_request = tau_road_ff + tau_accel

        tau_ref, keep, p_pred_kw, reason = self._allocate(tau_request, tau_pos, tau_neg, vz0)
        constrained = 1.0 if reason != "0.0" else 0.0

        # Inner current loop -> base voltage.
        kt = max(self._plant_param("Kt", 0.2), _EPS)
        ke = self._plant_param("Ke", 0.2)
        # DC plant uses R; SPMSM plant uses Rs.  Support both.
        r_arm = float(getattr(self.plant, "p", {}).get("R", getattr(self.plant, "p", {}).get("Rs", 0.22)))
        i_meas = float(vz0.get("current", 0.0))
        i_ref = tau_ref / kt
        e_i = i_ref - i_meas
        self.integ_i += e_i * self.dt
        u_base = ke * y + r_arm * i_ref + self.kp_i * e_i + self.ki_i * self.integ_i

        # Harmonic injection branch.  For spmsm_harm this is a generic harmonic-compensation branch.
        harm = self._harmonic_details(vz0)
        u_harm = float(harm["u_harm"])
        # --- Path-1 concept-demonstrator fix (v0.17) ----------------------
        # The injection is computed once per macro-step (dt=20 ms -> 50 Hz) and
        # then held constant by the plant's zero-order hold across all RK4
        # substeps, while the harmonic back-EMF it is meant to cancel runs at
        # ~700-1800 Hz (the 5th does ~14 cycles per step, the 13th ~36).  A
        # frozen, 50 Hz-sampled value cannot track that disturbance, so feeding
        # it into the integrated voltage command cancels essentially nothing in
        # the dynamics and only injects spurious ZOH energy -- which is exactly
        # why injection ON used to come out *worse* than OFF in both the
        # cumulative and the "effective" km/kWh.  At this fidelity the honest model drives the plant with
        # the clean base command and expresses the harmonic benefit purely in
        # the amplitude / AC-loss domain (the proxies below).  True per-instant
        # time-domain cancellation belongs in the substep/Simulink model --
        # see HARMONIC_PROPOSALS.md (path 2).
        u_intended_total = float(np.clip(u_base + u_harm, self.u_lo, self.u_hi))
        u_applied = float(np.clip(u_base, self.u_lo, self.u_hi))
        u = u_applied

        # Harmonic quality proxies and same-state ON/OFF counterfactuals.
        # We compute both ON and OFF from the exact same plant state so the GUI
        # does not compare two different moments of the acceleration transient.
        q_actual = self._harmonic_quality(vz0, harm)
        harm_on = self._harmonic_details(vz0, enabled=True)
        harm_off = self._harmonic_details(vz0, enabled=False)
        q_on = self._harmonic_quality(vz0, harm_on)
        q_off = self._harmonic_quality(vz0, harm_off)
        residual_parts = q_actual["residual_parts"]
        residual_amp_parts = q_actual["residual_amp_parts"]
        thd_raw = q_actual["harmonic_thd_raw_proxy"]
        thd_residual = q_actual["harmonic_thd_residual_proxy"]
        current_thd_raw = q_actual["current_thd_raw_proxy"]
        current_thd_residual = q_actual["current_thd_residual_proxy"]
        cancellation_pct = q_actual["harmonic_cancellation_pct"]

        if u_applied in (self.u_lo, self.u_hi):
            self.integ_i -= e_i * self.dt

        self.plant.step(u_applied, self.dt)
        self.prev_e_gov = e_w
        self.cost.sim_steps += 1
        self.cost.stop()

        vz = self.plant.viz_state()
        target_vehicle_kph = 3.6 * r_cmd / gear * rw
        governed_vehicle_kph = 3.6 * r_gov / gear * rw
        values = {
            "t": self.k * self.dt,
            "r": r_gov,
            "y": y,
            "u": u,
            "e": e_w,
            "i_arm": i_meas,
            "r_cmd": r_cmd,
            "r_governed": r_gov,
            "omega_feasible_next": omega_feasible_next,
            "alpha_cmd": alpha_cmd,
            "alpha_feasible": alpha_pos if e_cmd >= 0.0 else alpha_neg,
            "torque_ref": tau_ref,
            "torque_ref_raw": tau_request,
            "torque_error": tau_ref - float(vz.get("torque", 0.0)),
            "i_ref": i_ref,
            "speed_weight": self.speed_weight,
            "energy_weight": self.energy_weight,
            "torque_weight": self.torque_weight,
            "constraint_active": constrained,
            "constraint_reason": float(reason),
            "target_vehicle_kph": target_vehicle_kph,
            "vehicle_speed_ref_kph": target_vehicle_kph,
            "vehicle_speed_governed_kph": governed_vehicle_kph,
            "tau_road_ff": tau_road_ff,
            "tau_accel": tau_accel,
            "tau_available_pos": tau_pos,
            "tau_available_neg": tau_neg,
            "allocation_keep": keep,
            "p_pred_kw": p_pred_kw,
            "u_base": u_base,
            "u_harm": u_harm,
            "u_total": u_intended_total,
            "harmonic_enabled_state": 1.0 if self.harmonic_enabled else 0.0,
            "u_h5": float(harm.get("u_h5", 0.0)),
            "u_h7": float(harm.get("u_h7", 0.0)),
            "u_h11": float(harm.get("u_h11", 0.0)),
            "u_h13": float(harm.get("u_h13", 0.0)),
            "u_amp_h5": float(harm.get("u_amp_h5", 0.0)),
            "u_amp_h7": float(harm.get("u_amp_h7", 0.0)),
            "u_amp_h11": float(harm.get("u_amp_h11", 0.0)),
            "u_amp_h13": float(harm.get("u_amp_h13", 0.0)),
            "bemf_harmonic": float(vz0.get("bemf_harmonic", 0.0)),
            "bemf_h5": float(harm.get("bemf_h5", vz0.get("bemf_h5", 0.0))),
            "bemf_h7": float(harm.get("bemf_h7", vz0.get("bemf_h7", 0.0))),
            "bemf_h11": float(harm.get("bemf_h11", vz0.get("bemf_h11", 0.0))),
            "bemf_h13": float(harm.get("bemf_h13", vz0.get("bemf_h13", 0.0))),
            "bemf_amp_h5": float(harm.get("bemf_amp_h5", vz0.get("bemf_amp_h5", 0.0))),
            "bemf_amp_h7": float(harm.get("bemf_amp_h7", vz0.get("bemf_amp_h7", 0.0))),
            "bemf_amp_h11": float(harm.get("bemf_amp_h11", vz0.get("bemf_amp_h11", 0.0))),
            "bemf_amp_h13": float(harm.get("bemf_amp_h13", vz0.get("bemf_amp_h13", 0.0))),
            "resid_h5": float(residual_parts[5]),
            "resid_h7": float(residual_parts[7]),
            "resid_h11": float(residual_parts[11]),
            "resid_h13": float(residual_parts[13]),
            "resid_amp_h5": float(residual_amp_parts[5]),
            "resid_amp_h7": float(residual_amp_parts[7]),
            "resid_amp_h11": float(residual_amp_parts[11]),
            "resid_amp_h13": float(residual_amp_parts[13]),
            "harmonic_gain": self.harmonic_gain,
            "harmonic_thd_proxy": float(thd_raw),
            "harmonic_thd_raw_proxy": float(thd_raw),
            "harmonic_thd_signed_proxy": float(vz0.get("harmonic_thd_signed_proxy", 0.0)),
            "harmonic_thd_residual_proxy": float(thd_residual),
            "harmonic_cancellation_pct": float(cancellation_pct),
            "current_thd_raw_proxy": float(current_thd_raw),
            "current_thd_residual_proxy": float(current_thd_residual),
            "i_harm_raw_rms_A": float(q_actual["i_harm_raw_rms_A"]),
            "i_harm_residual_rms_A": float(q_actual["i_harm_residual_rms_A"]),
            "torque_ripple_current_raw_nm": float(q_actual["torque_ripple_current_raw_nm"]),
            "torque_ripple_current_residual_nm": float(q_actual["torque_ripple_current_residual_nm"]),
            "harmonic_loss_raw_W": float(q_actual["harmonic_loss_raw_W"]),
            "harmonic_loss_residual_W": float(q_actual["harmonic_loss_residual_W"]),
            "p_bat_effective_W": float(q_actual["p_bat_effective_W"]),
            "km_per_kwh_effective_inst": float(q_actual["km_per_kwh_effective_inst"]),
            "wh_per_km_effective_inst": float(q_actual["wh_per_km_effective_inst"]),
            "nm_per_kw_effective_inst": float(q_actual["nm_per_kw_effective_inst"]),
            "cf_on_current_thd_residual_proxy": float(q_on["current_thd_residual_proxy"]),
            "cf_off_current_thd_residual_proxy": float(q_off["current_thd_residual_proxy"]),
            "cf_on_harmonic_loss_residual_W": float(q_on["harmonic_loss_residual_W"]),
            "cf_off_harmonic_loss_residual_W": float(q_off["harmonic_loss_residual_W"]),
            "cf_on_torque_ripple_current_residual_nm": float(q_on["torque_ripple_current_residual_nm"]),
            "cf_off_torque_ripple_current_residual_nm": float(q_off["torque_ripple_current_residual_nm"]),
            "cf_on_km_per_kwh_effective_inst": float(q_on["km_per_kwh_effective_inst"]),
            "cf_off_km_per_kwh_effective_inst": float(q_off["km_per_kwh_effective_inst"]),
            "cf_on_u_harm": float(harm_on["u_harm"]),
            "cf_off_u_harm": float(harm_off["u_harm"]),
            "torque_ripple": float(vz0.get("torque_ripple", 0.0)),
        }
        for key, val in values.items():
            self.log.setdefault(key, []).append(float(val))
        self._append_viz_to_log(vz)
        self.k += 1
        if (live or cont) and len(self.log["t"]) > self.live_log_cap:
            for key in self.log:
                self.log[key] = self.log[key][-self.live_log_cap:]
        self.last_signals = {"r": r_gov, "r_cmd": r_cmd, "y": y, "u": u, "e": e_w,
                             "tau_ref": tau_ref, "tau_raw": tau_request,
                             "i_ref": i_ref, "constraint": constrained,
                             "u_base": u_base, "u_harm": u_harm,
                             "u_h5": values["u_h5"], "u_h7": values["u_h7"],
                             "u_h11": values["u_h11"], "u_h13": values["u_h13"],
                             "harmonic_enabled_state": values["harmonic_enabled_state"],
                             "bemf_harmonic": values["bemf_harmonic"],
                             "bemf_h5": values["bemf_h5"], "bemf_h7": values["bemf_h7"],
                             "bemf_h11": values["bemf_h11"], "bemf_h13": values["bemf_h13"],
                             "resid_h5": values["resid_h5"], "resid_h7": values["resid_h7"],
                             "resid_h11": values["resid_h11"], "resid_h13": values["resid_h13"],
                             "harmonic_thd_raw_proxy": values["harmonic_thd_raw_proxy"],
                             "harmonic_thd_residual_proxy": values["harmonic_thd_residual_proxy"],
                             "harmonic_cancellation_pct": values["harmonic_cancellation_pct"],
                             "current_thd_raw_proxy": values["current_thd_raw_proxy"],
                             "current_thd_residual_proxy": values["current_thd_residual_proxy"],
                             "i_harm_raw_rms_A": values["i_harm_raw_rms_A"],
                             "i_harm_residual_rms_A": values["i_harm_residual_rms_A"],
                             "torque_ripple_current_raw_nm": values["torque_ripple_current_raw_nm"],
                             "torque_ripple_current_residual_nm": values["torque_ripple_current_residual_nm"],
                             "harmonic_loss_raw_W": values["harmonic_loss_raw_W"],
                             "harmonic_loss_residual_W": values["harmonic_loss_residual_W"],
                             "p_bat_effective_W": values["p_bat_effective_W"],
                             "km_per_kwh_effective_inst": values["km_per_kwh_effective_inst"],
                             "nm_per_kw_effective_inst": values["nm_per_kw_effective_inst"],
                             "cf_on_current_thd_residual_proxy": values["cf_on_current_thd_residual_proxy"],
                             "cf_off_current_thd_residual_proxy": values["cf_off_current_thd_residual_proxy"],
                             "cf_on_harmonic_loss_residual_W": values["cf_on_harmonic_loss_residual_W"],
                             "cf_off_harmonic_loss_residual_W": values["cf_off_harmonic_loss_residual_W"],
                             "cf_on_torque_ripple_current_residual_nm": values["cf_on_torque_ripple_current_residual_nm"],
                             "cf_off_torque_ripple_current_residual_nm": values["cf_off_torque_ripple_current_residual_nm"],
                             "cf_on_km_per_kwh_effective_inst": values["cf_on_km_per_kwh_effective_inst"],
                             "cf_off_km_per_kwh_effective_inst": values["cf_off_km_per_kwh_effective_inst"],
                             "cf_on_u_harm": values["cf_on_u_harm"],
                             "cf_off_u_harm": values["cf_off_u_harm"]}
        return self._frame("run", "harmonic-injection",
                           f"t={self.k*self.dt:5.2f}s  ωref={r_gov:6.2f}  ω={y:6.2f}  τref={tau_ref:+5.2f}  uh={u_harm:+5.2f} V",
                           signals=dict(self.last_signals), viz=vz)

    def metrics(self) -> Dict[str, float]:
        out = super().metrics()
        if self.log.get("u_harm"):
            uh = np.asarray(self.log["u_harm"], dtype=float)
            out["rms_harmonic_voltage_v"] = float(np.sqrt(np.mean(uh ** 2)))
            for h in (5, 7, 11, 13):
                key = f"u_h{h}"
                if self.log.get(key):
                    arr = np.asarray(self.log[key], dtype=float)
                    out[f"rms_u_h{h}_v"] = float(np.sqrt(np.mean(arr ** 2)))
        if self.log.get("harmonic_thd_proxy"):
            hp = np.asarray(self.log["harmonic_thd_proxy"], dtype=float)
            out["mean_harmonic_thd_proxy"] = float(np.mean(np.abs(hp)))
        if self.log.get("harmonic_thd_residual_proxy"):
            hp = np.asarray(self.log["harmonic_thd_residual_proxy"], dtype=float)
            out["mean_harmonic_thd_residual_proxy"] = float(np.mean(np.abs(hp)))
        if self.log.get("current_thd_raw_proxy"):
            raw = np.asarray(self.log["current_thd_raw_proxy"], dtype=float)
            res = np.asarray(self.log.get("current_thd_residual_proxy", self.log["current_thd_raw_proxy"]), dtype=float)
            # Use a settled-window statistic for current THD proxies.  During the
            # launch ramp the fundamental current can be near zero, making any
            # THD ratio visually noisy.  harmonic-compensation implementations report THD at an operating
            # point, so this Python proxy uses the last 50% of samples and a
            # median/mean only where current is meaningful.
            start = len(raw) // 2
            mask = np.ones_like(raw[start:], dtype=bool)
            if self.log.get("i_arm"):
                iq = np.abs(np.asarray(self.log["i_arm"], dtype=float)[start:])
                mask = iq > 5.0
                if not np.any(mask):
                    mask = np.ones_like(iq, dtype=bool)
            raw_set = np.abs(raw[start:][mask])
            res_set = np.abs(res[start:][mask])
            out["mean_current_thd_raw_proxy"] = float(np.mean(raw_set)) if raw_set.size else 0.0
            out["mean_current_thd_residual_proxy"] = float(np.mean(res_set)) if res_set.size else 0.0
            out["settled_current_thd_raw_proxy"] = float(np.median(raw_set)) if raw_set.size else 0.0
            out["settled_current_thd_residual_proxy"] = float(np.median(res_set)) if res_set.size else 0.0
        if self.log.get("harmonic_cancellation_pct"):
            cc = np.asarray(self.log["harmonic_cancellation_pct"], dtype=float)
            start = len(cc) // 2
            out["mean_harmonic_cancellation_pct"] = float(np.mean(cc[start:])) if len(cc) else 0.0
        if self.log.get("torque_ripple"):
            tr = np.asarray(self.log["torque_ripple"], dtype=float)
            out["rms_torque_ripple_nm"] = float(np.sqrt(np.mean(tr ** 2)))
        if self.log.get("torque_ripple_current_residual_nm"):
            trc = np.asarray(self.log["torque_ripple_current_residual_nm"], dtype=float)
            out["rms_current_harmonic_torque_ripple_nm"] = float(np.sqrt(np.mean(trc ** 2)))
        if self.log.get("harmonic_loss_residual_W"):
            loss = np.asarray(self.log["harmonic_loss_residual_W"], dtype=float)
            out["mean_harmonic_loss_residual_W"] = float(np.mean(loss))
        if self.log.get("harmonic_loss_raw_W"):
            loss = np.asarray(self.log["harmonic_loss_raw_W"], dtype=float)
            out["mean_harmonic_loss_raw_W"] = float(np.mean(loss))
        if self.log.get("p_bat_effective_W") and self.log.get("distance_km") and self.log.get("t"):
            t = np.asarray(self.log["t"], dtype=float)
            p_eff = np.maximum(np.asarray(self.log["p_bat_effective_W"], dtype=float), 0.0)
            if len(t) > 1 and len(p_eff) == len(t):
                dt_vec = np.diff(t, prepend=t[0])
                if len(dt_vec) > 1:
                    dt_vec[0] = dt_vec[1]
                e_eff_kwh = float(np.sum(p_eff * dt_vec) / 3.6e6)
                dist_km = float(self.log["distance_km"][-1])
                if e_eff_kwh > 1e-9:
                    out["km_per_kwh_effective"] = dist_km / e_eff_kwh
                if dist_km > 1e-9:
                    out["wh_per_km_effective"] = 1000.0 * e_eff_kwh / dist_km
        return out

    def comparison_rows(self) -> List[dict]:
        rows = super().comparison_rows()
        if rows:
            m = self.metrics()
            rows[0]["variant"] = "harmonic injection"
            keys = ["rms_harmonic_voltage_v", "mean_harmonic_thd_proxy", "mean_harmonic_thd_residual_proxy", "mean_current_thd_raw_proxy", "mean_current_thd_residual_proxy", "settled_current_thd_raw_proxy", "settled_current_thd_residual_proxy", "mean_harmonic_cancellation_pct", "rms_torque_ripple_nm", "rms_current_harmonic_torque_ripple_nm", "mean_harmonic_loss_raw_W", "mean_harmonic_loss_residual_W", "km_per_kwh_effective", "wh_per_km_effective"]
            keys += [f"rms_u_h{h}_v" for h in (5, 7, 11, 13)]
            for key in keys:
                if key in m:
                    rows[0][key] = round(m[key], 4)
        return rows

    def layers(self) -> List[LayerSpec]:
        base = super().layers()
        return base + [LayerSpec("harmonic", "harmonic injection", True)]

    def draw_signals(self, fig, ctx: DrawContext) -> None:
        _draw_harmonic_timeseries(fig, self, ctx)


def _draw_harmonic_timeseries(fig, scheme, ctx: DrawContext) -> None:
    log = scheme.log
    if not log.get("t"):
        ax = fig.add_subplot(111)
        ax.text(0.5, 0.5, f"Run '{scheme.name}' to see harmonic-injection signals",
                ha="center", va="center", transform=ax.transAxes, color="#888")
        ax.set_axis_off()
        return
    on = ctx.layer_on
    panels = []
    if on.get("track", True): panels.append("track")
    if on.get("torque", True): panels.append("torque")
    if on.get("control", True): panels.append("control")
    if on.get("harmonic", True): panels.append("harmonic")
    if on.get("energy", False): panels.append("energy")
    if on.get("error", False): panels.append("error")
    panels = panels or ["track"]
    t = log["t"]
    axes = fig.subplots(len(panels), 1, sharex=True, squeeze=False)[:, 0]
    for ax, kind in zip(axes, panels):
        if kind == "track":
            if log.get("r_cmd"):
                ax.plot(t, log["r_cmd"], ":", lw=1.1, label="mission ωcmd")
            ax.plot(t, log["r"], "--", lw=1.4, label="governed ωref")
            ax.plot(t, log["y"], color=scheme.color, lw=1.7, label="ω output")
            ax.set_ylabel("speed")
            ax.legend(loc="best", fontsize=8)
        elif kind == "torque":
            ax.plot(t, log.get("torque_ref_raw", []), ":", lw=1.1, label="raw τ request")
            ax.plot(t, log.get("torque_ref", []), "--", lw=1.3, label="τ ref")
            if log.get("torque"):
                ax.plot(t, log["torque"], color=scheme.color, lw=1.6, label="actual τ")
            if log.get("torque_ripple"):
                ax.plot(t, log["torque_ripple"], lw=1.0, label="τ ripple")
            ax.set_ylabel("torque [Nm]")
            ax.legend(loc="best", fontsize=8)
        elif kind == "control":
            ax.plot(t, log.get("u_base", []), lw=1.2, label="base voltage")
            ax.plot(t, log.get("u_harm", []), lw=1.2, label="harmonic voltage")
            ax.plot(t, log.get("u", []), lw=1.4, label="total voltage")
            ax.set_ylabel("voltage [V]")
            ax.legend(loc="best", fontsize=8)
        elif kind == "harmonic":
            if log.get("bemf_harmonic"):
                ax.plot(t, log["bemf_harmonic"], lw=1.2, label="total EMF harm [V]")
            if log.get("u_harm"):
                ax.plot(t, log["u_harm"], "--", lw=1.2, label="total injected [V]")
            for h in (5, 7, 11, 13):
                key = f"u_h{h}"
                if log.get(key):
                    ax.plot(t, log[key], lw=0.8, alpha=0.75, label=f"inj h{h}")
            if log.get("harmonic_thd_proxy") or log.get("harmonic_thd_residual_proxy"):
                ax2 = ax.twinx()
                if log.get("harmonic_thd_proxy"):
                    ax2.plot(t, log["harmonic_thd_proxy"], ":", lw=1.0, label="raw THD proxy")
                if log.get("harmonic_thd_residual_proxy"):
                    ax2.plot(t, log["harmonic_thd_residual_proxy"], "--", lw=1.0, label="residual THD proxy")
                ax2.set_ylabel("THD proxy")
                ax2.legend(loc="upper right", fontsize=7)
            ax.set_ylabel("harmonics")
            ax.legend(loc="best", fontsize=7)
        elif kind == "energy":
            if log.get("soc_pct"):
                ax.plot(t, log["soc_pct"], lw=1.3, label="SOC [%]")
            if log.get("p_bat_W"):
                ax.plot(t, [v/1000.0 for v in log["p_bat_W"]], lw=1.1, label="Pbat [kW]")
            if log.get("km_per_kwh_live"):
                ax.plot(t, log["km_per_kwh_live"], lw=1.0, label="km/kWh live")
            ax.set_ylabel("energy")
            ax.legend(loc="best", fontsize=8)
        elif kind == "error":
            ax.plot(t, log["e"], color="#d62728", lw=1.2, label="ω error")
            if log.get("torque_error"):
                ax.plot(t, log["torque_error"], lw=1.0, label="τ error")
            ax.axhline(0, color="#aaa", lw=0.8)
            ax.set_ylabel("errors")
            ax.legend(loc="best", fontsize=8)
        ax.grid(True, alpha=0.25)
    axes[-1].set_xlabel("time [s]")
    fig.suptitle(f"{scheme.name} — coupled loops + harmonic voltage injection", fontsize=11)
