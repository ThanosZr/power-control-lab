"""Indirect Learning Adaptive Inverse Control  (the scheme on the slide).

Two neural networks, exactly as in the figure:

  ANN 2 - the **emulator**: a forward model that learns the plant dynamics
          y_hat(k+1) = f_hat( measured_state(k), u(k) ), trained to drive
          e* = y - y_hat to zero.
  ANN 1 - the **controller** (F^-1): produces u(k) = g( y_target(k+1),
          measured_state(k) ) so the plant output follows the reference.

The controller has no target of its own, so it is trained on the *output*
error e = r - y back-propagated **through the emulator**: the emulator supplies
d y_hat / d u, which turns the output error into a gradient on the control
action (see MLP.input_grad). This is why the emulator exists and why the
architecture is called *indirect*.

Two engineering choices make it actually track a motor (rather than being a toy
that fails on a relative-degree-2 plant):

* the networks see the **measured state** the plant exposes (speed AND current),
  so the one-step input->output map is well-conditioned;
* the controller is asked for a **reference-model** target each step,
  y_target = y + alpha*(r - y), i.e. a reachable one-step move toward r, instead
  of demanding the full jump in a single sample. alpha sets the closed-loop
  approach speed; steady state still converges to r so the steady error -> 0.

Workflow = the step graph:
  excite      drive the plant with a random signal, record (state, u, y)
  emulator    train ANN 2 off-line on that data            (minimise e*)
  controller  pre-train ANN 1 off-line through the emulator (minimise e, no plant)
  online      run the closed loop, adapting BOTH nets every time step
"""
from __future__ import annotations

from typing import Dict, List

import numpy as np

from core.nn import MLP
from core.registry import register_scheme
from core.scheme import (ControlScheme, DrawContext, LayerSpec, Step)
from schemes.pid import _draw_timeseries


@register_scheme
class IndirectInverseControl(ControlScheme):
    id = "iaic"
    name = "Indirect adaptive inverse"
    color = "#d62728"

    STEPS = [
        Step("excite", "Collect excitation data", produces=["dataset"],
             description="Drive the plant with a random signal and record state, u, y."),
        Step("emulator", "Train emulator (ANN 2)", requires=["excite"],
             produces=["emulator"],
             description="Off-line: learn the forward dynamics, minimise e*=y-yhat."),
        Step("controller", "Pre-train controller (ANN 1)", requires=["emulator"],
             produces=["controller"],
             description="Off-line: learn the inverse by back-prop through ANN 2."),
        Step("online", "Online closed-loop", requires=["controller"],
             description="Track the reference; adapt both nets every time step.",
             rerunnable=True),
    ]

    def __init__(self, plant, reference, dt, params):
        super().__init__(plant, reference, dt, params)
        p = self.params
        self.h_emu = int(p.get("hidden_emu", 20))
        self.h_ctrl = int(p.get("hidden_ctrl", 20))
        self.lr_emu = float(p.get("lr_emu", 0.05))
        self.lr_ctrl = float(p.get("lr_ctrl", 0.05))
        self.lr_emu_on = float(p.get("lr_emu_online", 0.01))
        self.lr_ctrl_on = float(p.get("lr_ctrl_online", 0.02))
        self.excite_steps = int(p.get("excite_steps", 2000))
        self.epochs_emu = int(p.get("epochs_emu", 80))
        self.epochs_ctrl = int(p.get("epochs_ctrl", 80))
        self.ctrl_samples = int(p.get("ctrl_samples", 600))
        self.alpha = float(p.get("ref_model_alpha", 0.5))
        # cap the per-step target move to a physically reachable increment so the
        # controller query stays on the manifold it was trained on
        self.max_step_frac = float(p.get("max_step_frac", 0.07))
        self.adapt_emu = bool(p.get("adapt_emulator", True))
        self.adapt_ctrl = bool(p.get("adapt_controller", True))
        self.seed = int(p.get("seed", 1))

        ulo, uhi = plant.u_range()
        self.UN = max(abs(ulo), abs(uhi)) or 1.0
        self.SCALE = plant.measured_scale()         # per-entry normalisers
        self.YN = float(self.SCALE[0])              # output normaliser
        self.ds = len(self.SCALE)                   # measured-state dimension
        self.u_lo, self.u_hi = ulo, uhi

        # emulator: [state_n , u_n] -> y_n(k+1)   ;  controller: [ytarget_n, state_n] -> u_n
        self.emu = MLP([self.ds + 1, self.h_emu, 1], lr=self.lr_emu, seed=self.seed)
        self.ctrl = MLP([self.ds + 1, self.h_ctrl, 1], lr=self.lr_ctrl, seed=self.seed + 99)
        self._init_runtime()

    # ---- normalisers --------------------------------------------------- #
    def _nm(self, m):
        return np.asarray(m) / self.SCALE

    def _ny(self, v):
        return v / self.YN

    def _nu(self, v):
        return v / self.UN

    def _init_runtime(self):
        self.exc_M: List[np.ndarray] = []          # measured state (normalised)
        self.exc_U: List[float] = []               # input (normalised)
        self.exc_plant = self.plant.clone()
        self.exc_k = 0
        self.exc_signal = None
        self.dataset = None                        # (state_n, u_n, ynext_n)
        self.emu_epoch = 0
        self.ctrl_epoch = 0
        self.emu_mse_hist: List[float] = []
        self.ctrl_mse_hist: List[float] = []
        self.online_k = 0

    # ================================================================== #
    def micro_step(self):
        sid = self.active_step_id
        if sid is None:
            return None
        if self.status(sid) == "locked":
            nxt = self.next_ready_step()
            if nxt is None:
                return None
            sid = self.active_step_id = nxt
        return {"excite": self._ms_excite, "emulator": self._ms_emulator,
                "controller": self._ms_controller, "online": self._ms_online}[sid]()

    # ---- step 1: excitation ------------------------------------------- #
    def _ms_excite(self):
        if "excite" in self._done_steps:
            return None
        if self.exc_signal is None:
            self._make_excitation()
            self.exc_plant.reset_state()
            self.exc_M, self.exc_U, self.exc_k = [], [], 0
        self.cost.start()
        u = float(self.exc_signal[self.exc_k])
        self.exc_M.append(self._nm(self.exc_plant.measured()))
        self.exc_U.append(self._nu(u))
        y = self.exc_plant.output()
        self.exc_plant.step(u, self.dt)
        self.exc_k += 1
        self.cost.sim_steps += 1
        self.cost.stop()
        if self.exc_k >= self.excite_steps:
            self._build_dataset()
            self._done_steps.add("excite")
            self.active_step_id = "emulator"
        return self._frame("excite", "excite",
                           f"excitation  k={self.exc_k}/{self.excite_steps}  u={u:6.2f}  y={y:6.2f}",
                           signals={"r": 0.0, "y": y, "u": u, "e": 0.0,
                                    "y_hat": y, "e_star": 0.0},
                           viz=self.exc_plant.viz_state())

    def _make_excitation(self):
        rng = np.random.default_rng(self.seed)
        n = self.excite_steps
        sig = np.zeros(n)
        k = 0
        while k < n:
            hold = int(rng.integers(int(0.1 / self.dt), int(0.6 / self.dt) + 1))
            sig[k:k + hold] = float(rng.uniform(self.u_lo * 0.95, self.u_hi * 0.95))
            k += hold
        sig += rng.normal(0, 0.04 * self.UN, size=n)
        self.exc_signal = np.clip(sig, self.u_lo, self.u_hi)

    def _build_dataset(self):
        M = np.asarray(self.exc_M)          # (N, ds) normalised
        U = np.asarray(self.exc_U)          # (N,)    normalised
        X = np.column_stack([M[:-1], U[:-1]])      # state(k), u(k)
        Ynext = M[1:, 0]                            # output at k+1 (normalised)
        self.dataset = (X, Ynext, M[:-1])

    # ---- step 2: emulator --------------------------------------------- #
    def _ms_emulator(self):
        if "emulator" in self._done_steps:
            return None
        X, Ynext, _ = self.dataset
        rng = np.random.default_rng(self.seed + self.emu_epoch)
        idx = rng.permutation(len(X))
        self.cost.start()
        se = 0.0
        for j in idx:
            se += self.emu.train_sample(X[j], np.array([Ynext[j]]), lr=self.lr_emu)
            self.cost.grad_updates += 1
            self.cost.forward_evals += 1
        self.cost.epochs += 1
        self.cost.stop()
        mse = se / len(X)
        self.emu_mse_hist.append(mse)
        self.emu_epoch += 1
        if self.emu_epoch >= self.epochs_emu:
            self._done_steps.add("emulator")
            self.active_step_id = "controller"
        return self._frame("emulator", "train",
                           f"emulator epoch {self.emu_epoch}/{self.epochs_emu}  MSE(e*)={mse:.6f}",
                           notes={"emulator_mse": f"{mse:.6f}"})

    # ---- step 3: controller pre-training (direct inverse modelling) --- #
    def _ms_controller(self):
        """Initialise the inverse by supervised regression on the collected
        triples (state(k), y(k+1)) -> u(k). This is correctly scaled (unlike
        back-prop through the small plant gain), giving the on-line *indirect*
        adaptation a good starting point to refine."""
        if "controller" in self._done_steps:
            return None
        X, Ynext, M = self.dataset
        U = X[:, -1]                                   # normalised inputs u(k)
        rng = np.random.default_rng(self.seed + 1000 + self.ctrl_epoch)
        self.cost.start()
        se = 0.0
        for _ in range(self.ctrl_samples):
            j = int(rng.integers(0, len(X)))
            cvec = np.concatenate([[Ynext[j]], M[j]])   # [desired next out, state]
            se += self.ctrl.train_sample(cvec, np.array([U[j]]), lr=self.lr_ctrl)
            self.cost.grad_updates += 1
            self.cost.forward_evals += 1
        self.cost.epochs += 1
        self.cost.stop()
        mse = se / self.ctrl_samples
        self.ctrl_mse_hist.append(mse)
        self.ctrl_epoch += 1
        if self.ctrl_epoch >= self.epochs_ctrl:
            self._done_steps.add("controller")
            self.active_step_id = "online"
        return self._frame("controller", "train",
                           f"controller epoch {self.ctrl_epoch}/{self.epochs_ctrl}  inverse MSE(u)={mse:.6f}",
                           notes={"controller_mse": f"{mse:.6f}"})

    # ---- step 4: online ----------------------------------------------- #
    def _ms_online(self):
        if "online" in self._done_steps:
            return None
        if self.online_k == 0:
            self.plant.reset_state()
            self.log = {k: [] for k in
                        ("t", "r", "y", "u", "e", "e_star", "y_hat", "i_arm")}
        k = self.online_k
        live = self.setpoint is not None
        cont = self.run_continuous
        n = len(self.reference)
        if not live and not cont and k >= n - 1:
            self._done_steps.add("online")
            return None

        self.cost.start()
        if live:
            r = float(self.setpoint)
        elif cont:
            r = float(self.reference[(k + 1) % n])      # cycle the pattern
        else:
            r = float(self.reference[k + 1])
        y = self.plant.output()
        state_n = self._nm(self.plant.measured())
        # reference-model: reachable one-step target toward r (clipped so the
        # controller is queried only where it was trained)
        inc = self.max_step_frac * self.YN
        y_target = y + float(np.clip(self.alpha * (r - y), -inc, inc))
        target_n = self._ny(y_target)
        cvec = np.concatenate([[target_n], state_n])
        un = self.ctrl.forward(cvec)[0]
        self.cost.forward_evals += 1
        u = float(np.clip(un * self.UN, self.u_lo, self.u_hi))
        evec = np.concatenate([state_n, [un]])
        yhat_n = self.emu.forward(evec)[0]
        self.cost.forward_evals += 1
        y_hat = yhat_n * self.YN
        y_next = self.plant.step(u, self.dt)
        self.cost.sim_steps += 1
        ynext_n = self._ny(y_next)
        e_star = y_next - y_hat            # emulator prediction error
        e = r - y_next                    # true tracking error (for metrics)

        if self.adapt_emu:
            self.emu.train_sample(evec, np.array([ynext_n]), lr=self.lr_emu_on)
            self.cost.grad_updates += 1
        if self.adapt_ctrl:
            # indirect rule: push the (reachable) output error back through ANN 2,
            # Jacobian-normalised so a small plant gain ∂ŷ/∂u doesn't stall it
            e_ctrl = target_n - ynext_n
            J_u = self.emu.input_grad(evec)[-1]
            gain = J_u / (J_u * J_u + 1e-3)        # guarded pseudo-inverse
            dctrl = -e_ctrl * gain
            cache = {}
            self.ctrl.forward(cvec, cache)
            gW, gb, _ = self.ctrl.backward(cache, np.array([dctrl]))
            self.ctrl.apply(gW, gb, lr=self.lr_ctrl_on)
            self.cost.grad_updates += 1
        self.cost.stop()

        vz = self.plant.viz_state()
        for key, val in (("t", k * self.dt), ("r", r), ("y", y_next), ("u", u),
                         ("e", e), ("e_star", e_star), ("y_hat", y_hat),
                         ("i_arm", vz.get("current", 0.0))):
            self.log[key].append(val)
        self._append_viz_to_log(vz)
        self.online_k += 1
        if (live or cont) and len(self.log["t"]) > self.live_log_cap:
            for key in self.log:
                self.log[key] = self.log[key][-self.live_log_cap:]
        self.last_signals = {"r": r, "y": y_next, "u": u, "e": e,
                             "y_hat": y_hat, "e_star": e_star}
        return self._frame("online", "control",
                           f"t={k*self.dt:5.2f}s  r={r:6.2f}  y={y_next:6.2f}  e={e:6.2f}  e*={e_star:6.3f}",
                           signals=dict(self.last_signals), viz=vz)

    # ---- reset / re-run ------------------------------------------------ #
    def run_step(self, step_id):
        if step_id == "online" and "online" in self._done_steps:
            self._done_steps.discard("online")
            self.online_k = 0
        return super().run_step(step_id)

    def reset(self):
        f = super().reset()
        self.emu = MLP([self.ds + 1, self.h_emu, 1], lr=self.lr_emu, seed=self.seed)
        self.ctrl = MLP([self.ds + 1, self.h_ctrl, 1], lr=self.lr_ctrl, seed=self.seed + 99)
        self._init_runtime()
        return f

    # ---- results / comparison ----------------------------------------- #
    def result(self) -> dict:
        d = super().result()
        d["log"] = {k: list(v) for k, v in self.log.items()}
        d["metrics"] = self.metrics()
        d["emu_mse_hist"] = list(self.emu_mse_hist)
        d["ctrl_mse_hist"] = list(self.ctrl_mse_hist)
        d["emu"] = self.emu.to_dict()
        d["ctrl"] = self.ctrl.to_dict()
        return d

    def load_result(self, data):
        super().load_result(data)
        self.log = {k: list(v) for k, v in data.get("log", {}).items()}
        self.emu_mse_hist = list(data.get("emu_mse_hist", []))
        self.ctrl_mse_hist = list(data.get("ctrl_mse_hist", []))
        if "emu" in data:
            self.emu = MLP.from_dict(data["emu"])
        if "ctrl" in data:
            self.ctrl = MLP.from_dict(data["ctrl"])

    def comparison_rows(self) -> List[dict]:
        if not self.log.get("y"):
            return []
        m = self.metrics()
        row = {
            "scheme": self.name, "variant": "ANN1+ANN2", "plant": self.plant.name,
            "rmse": round(m["rmse"], 4), "sse": round(m["sse"], 4),
            "overshoot_pct": round(m["overshoot_pct"], 2),
            "control_effort": round(m["control_effort"], 3),
            "sim_steps": self.cost.sim_steps, "grad_updates": self.cost.grad_updates,
            "ms": round(self.cost.elapsed_ms, 1),
        }
        for key in ("km_per_kwh", "wh_per_km", "nm_per_kw", "rms_current_a",
                    "final_soc_pct", "soc_drop_pctpts", "peak_torque_nm", "mean_v_sag"):
            if key in m:
                row[key] = round(m[key], 4 if key in ("km_per_kwh", "nm_per_kw") else 3)
        return [row]

    # ---- visuals ------------------------------------------------------- #
    def layers(self) -> List[LayerSpec]:
        return [LayerSpec("track", "reference vs output", True),
                LayerSpec("error", "tracking error e", True),
                LayerSpec("control", "control voltage u", True),
                LayerSpec("emulator", "emulator yhat vs y", False),
                LayerSpec("energy", "EV energy / SOC", False)]

    def draw_signals(self, fig, ctx: DrawContext) -> None:
        _draw_timeseries(fig, self, ctx)
