# Patch notes v0.15 — harmonic sanity checks

This patch tightens the simplified SPMSM harmonic-injection extension after refining the simplified harmonic model.

## Why this patch exists

the reference technique does **not** compute THD from one instantaneous signed sum of EMF harmonics. It extracts harmonic **amplitude and phase** maps from detailed machine modelling, stores them in maps, reconstructs a voltage injection waveform, and superimposes it on the PWM/SVPWM voltage reference. The relevant injected orders are 5th, 7th, 11th and 13th.

Earlier Python versions exposed useful visuals, but the harmonic THD proxy could look misleading because it was too close to instantaneous EMF cancellation rather than a spectral/current-like proxy.

## Added scenario: `straight_flat`

A straight-line validation reference was added:

```bash
python cli.py run --plant spmsm_harm --scenario straight_flat --schemes hinj \
  --duration 8 --dt 0.02 --soc0 70 --grade 0 --grade-amp 0 --load-amp 0 \
  --vehicle-mass 115 --wheel-radius 0.255 --gear 7 --target-vmax 45 \
  --harmonic-gain 1.0 --metrics test_v15_on.csv --plot test_v15_on.png
```

OFF comparison:

```bash
python cli.py run --plant spmsm_harm --scenario straight_flat --schemes hinj \
  --duration 8 --dt 0.02 --soc0 70 --grade 0 --grade-amp 0 --load-amp 0 \
  --vehicle-mass 115 --wheel-radius 0.255 --gear 7 --target-vmax 45 \
  --harmonic-off --metrics test_v15_off.csv --plot test_v15_off.png
```

Use this instead of `grade_adaptive` when debugging harmonic injection. `grade_adaptive` deliberately changes load/grade/reference and is not a clean operating-point test.

## Harmonic model changes

The SPMSM harmonic plant now exposes both:

- instantaneous harmonic EMF samples: `bemf_h5`, `bemf_h7`, `bemf_h11`, `bemf_h13`
- per-order amplitudes: `bemf_amp_h5`, `bemf_amp_h7`, `bemf_amp_h11`, `bemf_amp_h13`

This better matches the reference structure, where amplitude/phase maps are used to reconstruct the injected waveform.

## Current THD proxy

The controller now reports a more honest current-harmonic proxy:

```text
I_h_proxy = residual_harmonic_voltage_amplitude / |Rs + j*h*omega_e*Lq|
current_THD_proxy = sqrt(sum(I_h_proxy^2)) / |Iq|
```

This is still a **proxy**, not FFT current THD. It is closer to the physics than the old instantaneous EMF-ratio proxy.

## New metric columns

The metrics CSV now includes:

- `mean_current_thd_raw_proxy`
- `mean_current_thd_residual_proxy`
- `settled_current_thd_raw_proxy`
- `settled_current_thd_residual_proxy`

The settled values use the last half of the run and ignore near-zero current samples. This is closer to the reference fixed operating-point comparison.

## Important limitation

This Python model is still not equivalent to the reference Simulink implementation:

- no three-phase abc current waveform
- no DQ-to-ABC/SVPWM inverter
- no FFT of actual phase current
- no detailed harmonic maps over operating condition
- no nonlinear flux-linkage maps

It is a workbench demonstration showing how a harmonic injection module can be plugged into the control architecture. The MATLAB/Simulink migration should implement the real version.
