# Patch notes v0.7 — First real multi-objective control loop

v0.7 adds the first explicit **multi-objective controller** to the EV/DC workbench.
Previous versions exposed EV metrics such as `km/kWh`, `Wh/km`, `Nm/kW`, SOC drop and torque, but the actual controller was still mainly a **single speed loop**.  In v0.7, a new controller named:

```text
Multi-objective EV cascade
scheme id: moev
```

implements multiple coordinated control objectives.

## New controller architecture

```text
ω reference
    ↓
Outer speed PI + road-load feed-forward
    ↓
τ_ref raw
    ↓
SOC / energy / power supervisor
    ↓
τ_ref limited
    ↓
Inner torque-current PI loop
    ↓
Vcmd to battery + boost + DC motor + vehicle plant
```

This gives the workbench two actual control loops:

1. **Speed loop**: tracks motor/vehicle speed `ω`.
2. **Torque/current loop**: tracks a motor torque reference through armature current.

A third supervisory layer applies multi-objective constraints:

- torque availability,
- current limit,
- battery power limit,
- SOC derating,
- eco/balanced/performance weighting.

## Why this matters

The project is no longer only:

> change `ω` and report energy metrics.

It now starts to become:

> coordinate speed tracking, torque delivery and battery-aware energy limits under conflicting objectives.

For example, if the route grade increases, the plant load torque rises.  The controller uses a road-load torque feed-forward term and asks for more torque.  If SOC is low or power/current constraints are active, the supervisor limits the torque reference, so tracking may degrade but energy/current stress is reduced.

## New logs and CSV columns

The signal export can now include:

- `torque_ref`
- `torque_ref_raw`
- `torque_error`
- `i_ref`
- `constraint_active`
- `target_vehicle_kph`

The metrics export can now include:

- `torque_rmse_nm`
- `mean_tau_ref_nm`
- `constraint_pct`

## How to run

```bash
python cli.py run --plant evdc --scenario grade_adaptive --schemes moev pid --duration 8 --dt 0.1 --soc0 55 --payload 35 --grade 4 --grade-amp 2.5 --vehicle-mass 115 --wheel-radius 0.255 --gear 7 --target-vmax 45 --metrics multiobj_metrics.csv --plot multiobj_plot.png
```

In the GUI:

```text
Plant    = evdc
Scenario = grade_adaptive
Scheme   = Multi-objective EV cascade
```

The plot includes speed, torque reference/actual torque, voltage/current command and optional energy/SOC layers.

## What is still not implemented

This is not yet the final ANN-pair architecture.  The v0.7 controller is a deterministic cascaded controller.  It is intentionally implemented first because it gives a clean baseline for the later AI modules:

- ANN speed emulator + inverse speed controller,
- ANN torque emulator + inverse torque controller,
- ANN energy/SOC supervisor.

