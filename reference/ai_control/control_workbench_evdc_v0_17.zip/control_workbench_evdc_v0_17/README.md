# AI Control Workbench for Electric Drives

An exploratory, part-time desktop/CLI workbench for experimenting with control
schemes on electric-drive plant models. It implements an **Indirect Learning
Adaptive Inverse Control** scheme (ANN emulator + ANN inverse controller) and a
**PID baseline**, and applies them to several plants through a small plugin
architecture.

> **Status.** This is a concept prototype, not a validated simulator. The machine
> models are control-level and approximate. The intended direction is to keep the
> architecture and orchestration in Python while high-fidelity physics (machine
> operating maps, power electronics) live in MATLAB/Simulink or other tools,
> plugged in behind the same `Plant` interface (e.g. via an FMU).

## Architecture

The GUI/CLI discover plants, schemes, reference trajectories and exporters
through registries and two contracts (`Plant`, `ControlScheme`). Adding a plant /
scheme / scenario / exporter is one small class or function plus a one-line
import in `bootstrap.py`; the GUI updates itself. See **ARCHITECTURE.md**.

## Install & run

```bash
pip install -r requirements.txt   # numpy, matplotlib (tkinter ships with Python)
python main.py                    # launch the GUI
```

In the GUI: pick a **plant** and **scenario**, then **Play** (step by step) or
**Run all**. Switch the **active scheme** to compare schemes in the table.

## Plants

* `dc` — DC motor
* `im` — induction motor
* `evdc` — battery SOC + simplified boost converter + DC motor + vehicle load,
  reporting energy metrics such as `km/kWh`, `Wh/km`, `Nm/kW`, RMS current and
  SOC drop
* `spmsm_harm` — a simplified synchronous-machine sandbox with a non-sinusoidal
  back-EMF, used to experiment with a harmonic-compensation control branch

## Headless examples

```bash
python cli.py run --plant dc --scenario multistep --schemes iaic pid --plot out.png --metrics m.csv
python cli.py run --plant evdc --scenario urban --schemes moev pid --duration 8 --dt 0.1 --metrics ev.csv --plot ev.png
```

## Operating modes (the **Mode** dropdown)

* **Train (offline)** — `excite → emulator → controller`
* **Run · follow reference (loop)**
* **Run · live target ω**

The **keep learning** checkbox decides whether the networks keep adapting during
a Run or run frozen with the off-line-trained weights.

## The method in one paragraph

The **emulator** (ANN 2) learns the plant's forward dynamics so its prediction
error `e* = y − ŷ → 0`. The **controller** (ANN 1) has no target of its own, so
its tracking error `e = r − y` is back-propagated **through the emulator** — the
emulator supplies `∂ŷ/∂u`, turning an output error into a gradient on the control
action. Both nets are trained off-line and then keep adapting on-line each step.
The networks see the measured state (speed and current) and are asked for a
reachable one-step reference-model target, so the inverse stays well-conditioned.

## Harmonic-compensation sandbox (`spmsm_harm` + `hinj`)

The `spmsm_harm` plant adds a synthetic non-sinusoidal back-EMF (5th/7th/11th/13th
electrical harmonics). The `hinj` scheme adds a parallel voltage branch that
approximately cancels it — a **control-level demonstration** of harmonic
injection. It is deliberately **not** a three-phase FOC/SVPWM or detailed machine modelling model; that
level of fidelity belongs to a MATLAB/Simulink stage. See **HARMONIC_INJECTION.md**.

Clean operating-point comparison (`straight_flat` removes grade/load effects):

```bash
python cli.py run --plant spmsm_harm --scenario straight_flat --schemes hinj \
  --duration 8 --dt 0.02 --harmonic-gain 1.0 --metrics on.csv --plot on.png

python cli.py run --plant spmsm_harm --scenario straight_flat --schemes hinj \
  --duration 8 --dt 0.02 --harmonic-off --metrics off.csv --plot off.png
```

Prefer the current-THD **proxies** for Python-level comparison; they are proxies,
not FFT phase-current THD.

## Extending

Add a plant / scheme / scenario / exporter and add a one-line import in
`bootstrap.py`. Details in **ARCHITECTURE.md → How to extend**.
