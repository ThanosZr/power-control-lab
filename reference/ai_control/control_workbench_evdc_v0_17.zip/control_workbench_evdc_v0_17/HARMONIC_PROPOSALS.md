# Harmonic Injection — status & migration notes

Status of the harmonic-injection feature (`schemes/harmonic_injection.py`, plant
`spmsm_harm`) and the recommended path toward a high-fidelity MATLAB/Simulink
implementation. This is engineering-direction notes, not a validated result.

## 1. Sampling limitation of the concept prototype

The injection voltage is computed **once per macro-step** and held constant by the
plant's zero-order hold across the RK4 substeps, while the harmonic back-EMF it is
meant to cancel runs far faster (hundreds of Hz to low kHz at the settled
operating point). A value sampled at the macro-step rate and frozen cannot track a
disturbance many times faster; the high orders can even sit above the substep
Nyquist and alias inside the integration. So at this fidelity the frozen injection
cancels almost nothing dynamically.

## 2. Path 1 — concept-demonstrator (done)

At this fidelity we stop pretending the time-stepped plant performs the
cancellation. The plant is driven by the clean base command; the harmonic term is
still computed and logged as the **intended** injection estimate for the plots,
and the benefit is expressed in the amplitude / AC-loss domain via proxies
(per-order residual, residual current-THD proxy, harmonic AC copper/iron-loss
proxy, harmonic torque-ripple proxy). This removes the earlier contradiction where
"injection ON" looked worse than OFF, and gives a clean optimum at gain = 1 with
under- and over-injection both leaving residual harmonics — the correct
pedagogical behaviour. Honest framing: describe this as a **simplified harmonic
injection concept demonstrator**, whose job is to show that the multi-loop control
framework can host a harmonic-compensation module and expose meaningful per-order
THD / torque-ripple / AC-loss diagnostics.

## 3. Path 2 — dynamically-faithful injection (for the MATLAB/Simulink stage)

This is the version that actually performs time-domain cancellation. It is
deliberately out of scope for the macro-step Python prototype.

**3A. Optional intermediate step (still in Python).** Inject **inside** the
integration rather than once per macro-step: pass an angle-dependent command so
`v_cmd(t) = u_base + gain * e_h(theta_e(t))` is re-evaluated at every substep, and
raise the substep rate so the highest harmonic order is resolved. Acceptance test:
the plant's own current ripple (FFT of `iq`) should drop and the integrated energy
metric should improve ON vs OFF — i.e. the benefit appears in the dynamics, not
only in the amplitude proxies.

**3B. The real target (MATLAB/Simulink).** A three-phase implementation rather than
a q-axis proxy:

* **Inverter** — averaged or switched SVPWM at a realistic switching frequency,
  which sets the real injection bandwidth.
* **Machine** — SPMSM with non-sinusoidal back-EMF in abc frame (or dq with
  harmonic terms) so the harmonic orders appear as genuine current harmonics.
* **Compensation** — amplitude/phase look-up tables from detailed machine modelling / field
  reconstruction, and a real-time abc voltage injection augmenting the PI + SVPWM
  references.
* **Metrics** — real FFT-based current THD and torque ripple at a fixed operating
  point, not amplitude proxies.

### Bridge from the Python proxies

The Python proxies mirror the structure a Simulink model would use, so they are a
useful specification: the per-order amplitude components map to an a detailed harmonic-amplitude
amplitude table; the residual = |A_h − Â_h| maps to what a real FFT of the
compensated current should show; the harmonic-loss, torque-ripple and current-THD
proxies map to the AC-loss, torque-ripple and current-THD numbers the
high-fidelity model should reproduce. When a Simulink model reproduces those
reductions with a real FFT and a real SVPWM inverter, any efficiency improvement
becomes a genuine dynamic result rather than an amplitude-domain estimate.

## 4. Summary

* **Path 1 (done):** decouple the plant command from the mis-sampled injection;
  show the benefit in the amplitude/AC-loss domain; clean optimum at gain = 1.
* **Path 2 (later, MATLAB/Simulink):** per-instant injection inside the
  integration at a switching-frequency-class sample rate, ideally a full
  three-phase SVPWM + detailed-map model with real FFT THD.
