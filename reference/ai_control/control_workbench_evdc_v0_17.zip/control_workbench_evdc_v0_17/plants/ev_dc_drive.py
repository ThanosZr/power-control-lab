"""Battery + bidirectional buck-boost converter + DC motor + simple EV load.

This plant is intentionally control-level, not power-electronics switching level.
The controller still outputs one scalar command, interpreted as desired armature
voltage. The plant converts that command through a simplified SOC-dependent
battery/DC-link envelope and logs energy metrics used by the workbench.

States
------
x = [i_a, omega_m, SOC, distance_m, energy_draw_J]

Input
-----
u = V_cmd, desired converter output / motor armature voltage [V]. The actual
armature voltage is limited by the available battery OCV, internal resistance
and simplified boost ratio.

Output
------
y = omega_m [rad/s].

This is a first-version EV-drive system-level plant: it is meant to support
multi-objective controller comparisons such as speed tracking vs Nm/kW vs
km/kWh across SOC and road/load conditions.
"""
from __future__ import annotations

from typing import Dict, Tuple

import numpy as np

from core.plant import Plant
from core.registry import register_plant


_EPS = 1e-9


@register_plant
class BatteryBoostDCDrivePlant(Plant):
    id = "evdc"
    name = "Battery + boost DC EV drive"
    input_name = "Vcmd"
    input_unit = "V"
    output_name = "ω"
    output_unit = "rad/s"

    substeps = 20

    PARAMS = {
        # DC motor / drivetrain
        "R": 0.22,              # armature resistance [ohm]
        "L": 0.003,             # armature inductance [H]
        "Ke": 0.20,             # back-EMF constant [V*s/rad]
        "Kt": 0.20,             # torque constant [N*m/A]
        "J_motor": 0.018,       # motor rotor inertia [kg*m^2]
        "B": 0.012,             # viscous friction [N*m*s/rad]
        "gear_ratio": 7.0,      # motor speed / wheel speed [-]
        "drivetrain_eta": 0.92, # wheel-to-motor reflected load efficiency [-]
        "wheel_radius": 0.255,  # wheel radius [m]
        "target_vmax_kph": 45.0, # scenario scaling cap for realistic vehicle speed [km/h]

        # Vehicle / road load
        "vehicle_mass": 115.0,      # vehicle + driver [kg]
        "payload_mass": 0.0,        # extra mass sweep variable [kg]
        "Crr": 0.012,               # rolling resistance coefficient [-]
        "CdA": 0.32,                # drag area [m^2]
        "rho_air": 1.225,           # air density [kg/m^3]
        "grade_pct": 0.0,           # constant road grade [%]
        "grade_amp_pct": 1.5,       # sinusoidal road grade amplitude [%]
        "grade_period_m": 90.0,     # grade spatial period [m]
        "T_load_base": 0.05,        # extra resisting motor torque [N*m]
        "T_load_amp": 0.45,         # variable resisting motor torque amplitude [N*m]
        "load_period_m": 55.0,      # variable-load spatial period [m]

        # Battery / converter
        "SOC0": 0.85,            # initial SOC [0..1]
        "capacity_Ah": 18.0,     # pack capacity [Ah]
        "OCV_min": 45.0,         # open-circuit voltage at 0% SOC [V]
        "OCV_max": 58.8,         # open-circuit voltage at 100% SOC [V]
        "Rint_base": 0.075,      # base internal resistance [ohm]
        "Rint_soc_gain": 2.6,    # low-SOC resistance multiplier coefficient [-]
        "converter_eta": 0.94,   # converter efficiency [-]
        "boost_ratio_max": 1.75, # max |Vout| / Vbat envelope [-]
        "Vout_abs_max": 96.0,    # absolute converter output limit [V]
        "I_bat_max": 140.0,      # current limit used in metrics/protection [A]
    }

    def initial_state(self) -> np.ndarray:
        return np.array([0.0, 0.0, float(self.p["SOC0"]), 0.0, 0.0], dtype=float)

    # ------------------------------------------------------------------ #
    # helper maps
    # ------------------------------------------------------------------ #
    def _soc_clip(self, soc: float) -> float:
        return float(np.clip(soc, 0.0, 1.0))

    def _ocv(self, soc: float) -> float:
        s = self._soc_clip(soc)
        # Small curvature: mid-SOC is relatively flat, low-SOC falls harder.
        lin = self.p["OCV_min"] + (self.p["OCV_max"] - self.p["OCV_min"]) * s
        knee = -1.8 * (1.0 - s) ** 3
        return float(max(1.0, lin + knee))

    def _rint(self, soc: float) -> float:
        s = self._soc_clip(soc)
        return float(self.p["Rint_base"] * (1.0 + self.p["Rint_soc_gain"] * (1.0 - s) ** 2))

    def _vehicle_quantities(self, x: np.ndarray) -> Dict[str, float]:
        i, w, soc, distance, _energy = x
        p = self.p
        m = p["vehicle_mass"] + p["payload_mass"]
        g = 9.80665
        gear = max(p["gear_ratio"], _EPS)
        rw = max(p["wheel_radius"], _EPS)
        v = w / gear * rw
        # Smooth sign avoids a discontinuous rolling-load jump at zero speed.
        sgn = float(np.tanh(v / 0.25))
        grade_pct = p["grade_pct"] + p["grade_amp_pct"] * np.sin(2.0 * np.pi * distance / max(p["grade_period_m"], 1.0))
        grade = grade_pct / 100.0
        f_roll = m * g * p["Crr"] * sgn
        f_drag = 0.5 * p["rho_air"] * p["CdA"] * v * abs(v)
        f_grade = m * g * np.sin(np.arctan(grade))
        f_total = f_roll + f_drag + f_grade
        t_wheel = f_total * rw
        t_road_motor = t_wheel / (gear * max(p["drivetrain_eta"], 0.1))
        t_variable = (p["T_load_base"] +
                      p["T_load_amp"] * (0.5 + 0.5 * np.sin(2.0 * np.pi * distance / max(p["load_period_m"], 1.0)))) * sgn
        j_equiv = p["J_motor"] + m * (rw / gear) ** 2
        return {
            "vehicle_speed_mps": float(v),
            "vehicle_speed_kph": float(3.6 * v),
            "distance_m": float(distance),
            "grade_pct_live": float(grade_pct),
            "road_force_N": float(f_total),
            "road_load_torque": float(t_road_motor),
            "variable_load_torque": float(t_variable),
            "load_torque": float(t_road_motor + t_variable),
            "J_equiv": float(j_equiv),
        }

    def _battery_converter(self, x: np.ndarray, u_cmd: float) -> Dict[str, float]:
        i, _w, soc, _distance, _energy = x
        p = self.p
        ocv = self._ocv(soc)
        rint = self._rint(soc)
        v_avail = min(p["Vout_abs_max"], p["boost_ratio_max"] * ocv)
        v_arm = float(np.clip(u_cmd, -v_avail, v_avail))

        p_motor_elec = v_arm * i
        eta = float(np.clip(p["converter_eta"], 0.01, 1.0))
        p_bat = p_motor_elec / eta if p_motor_elec >= 0.0 else p_motor_elec * eta

        # Solve P = I*(OCV - I*R). Positive I = discharge, negative = regen.
        p_cap = 0.95 * ocv * ocv / max(4.0 * rint, _EPS)
        p_bat_limited = float(np.clip(p_bat, -p_cap, p_cap))
        disc = max(ocv * ocv - 4.0 * rint * p_bat_limited, 0.0)
        i_bat = (ocv - np.sqrt(disc)) / max(2.0 * rint, _EPS)
        i_bat = float(np.clip(i_bat, -p["I_bat_max"], p["I_bat_max"]))
        v_bat = float(ocv - i_bat * rint)
        # Keep the displayed/logged battery power physically consistent with
        # the terminal battery quantities after current limiting.  Earlier
        # versions kept the pre-limit requested power in p_bat_W, which could
        # make the live panel show impossible combinations such as 50 V, 60 A
        # and hundreds of kW.  The requested/model power is still exposed for
        # debugging as p_bat_request_W.
        p_bat_terminal = float(v_bat * i_bat)
        duty_equiv = float(np.clip(abs(v_arm) / max(abs(v_arm) + max(v_bat, 1.0), 1.0), 0.0, 0.95))
        return {
            "v_arm": float(v_arm),
            "v_cmd": float(u_cmd),
            "v_ocv": float(ocv),
            "v_bat": v_bat,
            "v_sag": float(ocv - v_bat),
            "i_bat": i_bat,
            "p_motor_elec_W": float(p_motor_elec),
            "p_bat_W": float(p_bat_terminal),
            "p_bat_request_W": float(p_bat_limited),
            "p_bat_vi_W": float(p_bat_terminal),
            "converter_duty": duty_equiv,
            "v_available": float(v_avail),
        }

    # ------------------------------------------------------------------ #
    def deriv(self, x: np.ndarray, u: float) -> np.ndarray:
        i, w, soc, distance, energy_j = x
        p = self.p
        elec = self._battery_converter(x, u)
        road = self._vehicle_quantities(x)
        v_arm = elec["v_arm"]
        di = (v_arm - p["R"] * i - p["Ke"] * w) / p["L"]
        t_em = p["Kt"] * i
        dw = (t_em - p["B"] * w - road["load_torque"]) / max(road["J_equiv"], _EPS)
        q_coul = max(p["capacity_Ah"] * 3600.0, 1.0)
        dsoc = -elec["i_bat"] / q_coul
        ddist = max(road["vehicle_speed_mps"], 0.0)
        denergy = max(elec["p_bat_W"], 0.0)  # net drawn energy, no regen credit in v1 metric
        return np.array([di, dw, dsoc, ddist, denergy], dtype=float)

    def step(self, u: float, dt: float) -> float:
        y = super().step(u, dt)
        self.x[2] = np.clip(self.x[2], 0.0, 1.0)     # SOC
        self.x[3] = max(self.x[3], 0.0)              # distance
        self.x[4] = max(self.x[4], 0.0)              # drawn energy
        return y

    def output(self) -> float:
        return float(self.x[1])

    def measured(self) -> np.ndarray:
        road = self._vehicle_quantities(self.x)
        return np.array([self.x[1], self.x[0], self.x[2], road["load_torque"]], dtype=float)

    def measured_scale(self) -> np.ndarray:
        wmax = max(abs(self.y_range()[0]), abs(self.y_range()[1]), 1.0)
        imax = max(self.p["Vout_abs_max"] / max(self.p["R"], _EPS), 1.0)
        return np.array([wmax, imax, 1.0, 10.0], dtype=float)

    def u_range(self) -> Tuple[float, float]:
        v = float(self.p["Vout_abs_max"])
        return (-v, v)

    def y_range(self) -> Tuple[float, float]:
        p = self.p
        # Two limits are relevant for a user-facing EV demo:
        #   1) electrical/motor no-load envelope from available converter voltage
        #   2) mission-level vehicle-speed cap, exposed in Vehicle Settings
        # This keeps the reference trajectory from looking like a tiny RC toy
        # or, conversely, asking for an unrealistic motor speed.
        vmax_elec = min(p["Vout_abs_max"], p["boost_ratio_max"] * p["OCV_max"])
        wmax_elec = p["Kt"] * vmax_elec / max(p["R"] * p["B"] + p["Kt"] * p["Ke"], _EPS)
        v_target_mps = max(float(p.get("target_vmax_kph", 45.0)), 1.0) / 3.6
        wmax_vehicle = v_target_mps * max(p["gear_ratio"], _EPS) / max(p["wheel_radius"], _EPS)
        wmax = min(0.95 * wmax_elec, wmax_vehicle)
        return (-0.10 * wmax, wmax)  # EV examples are mostly forward motion

    def viz_state(self) -> Dict[str, float]:
        i, w, soc, distance, energy_j = self.x
        p = self.p
        road = self._vehicle_quantities(self.x)
        elec = self._battery_converter(self.x, self.last_u)
        torque = p["Kt"] * i
        p_bat_kw = elec["p_bat_W"] / 1000.0
        energy_kwh = energy_j / 3.6e6
        distance_km = distance / 1000.0
        km_per_kwh = distance_km / energy_kwh if energy_kwh > 1e-9 else 0.0
        wh_per_km = 1000.0 * energy_kwh / distance_km if distance_km > 1e-9 else 0.0
        nm_per_kw = abs(torque) / max(abs(p_bat_kw), 1e-6) if p_bat_kw > 1e-6 else 0.0
        # Instantaneous vehicle efficiency estimate. This is not cumulative,
        # so it is useful for live ON/OFF comparisons without being polluted by
        # the launch transient already stored in distance/energy. Units:
        # (km/h) / kW = km/kWh.
        km_per_kwh_inst = road["vehicle_speed_kph"] / p_bat_kw if p_bat_kw > 1e-6 else 0.0
        wh_per_km_inst = 1000.0 / km_per_kwh_inst if km_per_kwh_inst > 1e-9 else 0.0
        return {
            "current": float(i),
            "speed": float(w),
            "voltage": float(elec["v_arm"]),
            "command_voltage": float(self.last_u),
            "back_emf": float(p["Ke"] * w),
            "torque": float(torque),
            "i_max": p["Vout_abs_max"] / max(p["R"], _EPS),
            "soc": float(np.clip(soc, 0.0, 1.0)),
            "soc_pct": float(100.0 * np.clip(soc, 0.0, 1.0)),
            "energy_kwh": float(energy_kwh),
            "distance_m": float(distance),
            "distance_km": float(distance_km),
            "km_per_kwh_live": float(km_per_kwh),
            "wh_per_km_live": float(wh_per_km),
            "nm_per_kw_live": float(nm_per_kw),
            "km_per_kwh_inst": float(km_per_kwh_inst),
            "wh_per_km_inst": float(wh_per_km_inst),
            "vehicle_mass_total": float(p["vehicle_mass"] + p["payload_mass"]),
            "gear_ratio": float(p["gear_ratio"]),
            "wheel_radius": float(p["wheel_radius"]),
            "target_vmax_kph": float(p.get("target_vmax_kph", 45.0)),
            **elec,
            **road,
        }
