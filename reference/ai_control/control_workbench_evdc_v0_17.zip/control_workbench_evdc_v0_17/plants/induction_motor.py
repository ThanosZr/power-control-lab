"""A *simplified* induction-motor speed plant — included to demonstrate that the
indirect-inverse controller is genuinely plant-agnostic: it is a different,
nonlinear system, yet the same scheme controls it with no scheme-side changes.

This is NOT a full dq flux model. It is a reduced, physically-flavoured model
adequate for the workbench's teaching/visualisation goal:

States  x = [i, w]   (effective torque-producing current, shaft speed)
Input   u = Vs       (stator voltage magnitude)
Output  y = w        (shaft speed)

    Te = Kt * i * (1 - (w / w_sync))        nonlinear torque vs slip
    L di/dt = Vs - R i - c * w              field/winding dynamics
    J dw/dt = Te - B w - T_load

The (1 - w/w_sync) factor makes torque fall off as the rotor approaches
synchronous speed — the characteristic induction-machine nonlinearity the
linear inverse of a DC motor would not capture, so the learning controller has
to actually adapt.
"""
from __future__ import annotations

from typing import Dict, Tuple

import numpy as np

from core.plant import Plant
from core.registry import register_plant


@register_plant
class InductionMotorPlant(Plant):
    id = "im"
    name = "Induction motor (simplified)"
    input_name = "Vs"
    input_unit = "V"
    output_name = "ω"
    output_unit = "rad/s"

    PARAMS = {
        "R": 1.5,
        "L": 0.4,
        "Kt": 0.12,
        "c": 0.06,        # speed coupling into the winding equation
        "B": 0.04,
        "J": 0.03,
        "w_sync": 30.0,   # synchronous speed [rad/s]
        "T_load": 0.0,
        "V_max": 24.0,
    }

    def initial_state(self) -> np.ndarray:
        return np.array([0.0, 0.0])

    def deriv(self, x: np.ndarray, u: float) -> np.ndarray:
        i, w = x
        p = self.p
        slip_factor = 1.0 - (w / p["w_sync"])
        Te = p["Kt"] * i * slip_factor
        di = (u - p["R"] * i - p["c"] * w) / p["L"]
        dw = (Te - p["B"] * w - p["T_load"]) / p["J"]
        return np.array([di, dw])

    def output(self) -> float:
        return float(self.x[1])

    def measured(self) -> np.ndarray:
        return np.array([self.x[1], self.x[0]])   # [speed (output), current]

    def measured_scale(self) -> np.ndarray:
        wmax = abs(self.y_range()[1]) or 1.0
        return np.array([wmax, self.p["V_max"] / self.p["R"]])

    def u_range(self) -> Tuple[float, float]:
        v = self.p["V_max"]
        return (-v, v)

    def y_range(self) -> Tuple[float, float]:
        # bounded by synchronous speed; use ~85% as a safe trackable span
        return (-0.85 * self.p["w_sync"], 0.85 * self.p["w_sync"])

    def viz_state(self) -> Dict[str, float]:
        i, w = self.x
        p = self.p
        return {
            "current": float(i),
            "speed": float(w),
            "voltage": float(self.last_u),
            "back_emf": float(p["c"] * w),
            "torque": float(p["Kt"] * i * (1.0 - w / p["w_sync"])),
            "i_max": p["V_max"] / p["R"],
        }
