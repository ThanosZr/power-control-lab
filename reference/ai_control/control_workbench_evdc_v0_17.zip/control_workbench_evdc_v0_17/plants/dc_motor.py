"""Separately-excited / permanent-magnet DC motor — the default "System (F)".

States  x = [i, w]   (armature current A, shaft speed rad/s)
Input   u = V        (armature voltage, volts)        -> what the controller sets
Output  y = w        (shaft speed, rad/s)             -> what we track

    L di/dt = V - R i - Ke w          (electrical: KVL on the armature loop)
    J dw/dt = Kt i - B w - T_load     (mechanical: Newton on the rotor)

The default parameters are chosen to give clear, well-damped, easily-visualised
dynamics (electrical time constant L/R = 0.25 s, mechanical J/B = 0.4 s) rather
than to match a specific datasheet. All are editable in Settings.
"""
from __future__ import annotations

from typing import Dict, Tuple

import numpy as np

from core.plant import Plant
from core.registry import register_plant


@register_plant
class DCMotorPlant(Plant):
    id = "dc"
    name = "DC motor"
    input_name = "V"
    input_unit = "V"
    output_name = "ω"
    output_unit = "rad/s"

    PARAMS = {
        "R": 2.0,      # armature resistance [ohm]
        "L": 0.5,      # armature inductance [H]
        "Ke": 0.1,     # back-EMF constant [V*s/rad]
        "Kt": 0.1,     # torque constant [N*m/A]
        "J": 0.02,     # rotor inertia [kg*m^2]
        "B": 0.05,     # viscous friction [N*m*s]
        "T_load": 0.0,  # constant load torque disturbance [N*m]
        "V_max": 24.0,  # supply voltage limit [V]
    }

    def initial_state(self) -> np.ndarray:
        return np.array([0.0, 0.0])     # [current, speed]

    def deriv(self, x: np.ndarray, u: float) -> np.ndarray:
        i, w = x
        p = self.p
        di = (u - p["R"] * i - p["Ke"] * w) / p["L"]
        dw = (p["Kt"] * i - p["B"] * w - p["T_load"]) / p["J"]
        return np.array([di, dw])

    def output(self) -> float:
        return float(self.x[1])

    def measured(self) -> np.ndarray:
        return np.array([self.x[1], self.x[0]])   # [speed (output), current]

    def measured_scale(self) -> np.ndarray:
        wmax = abs(self.y_range()[1]) or 1.0
        return np.array([wmax, self.p["V_max"] / self.p["R"]])

    def u_range(self) -> Tuple[float, float]:
        v = self.p["V_max"]
        return (-v, v)

    def y_range(self) -> Tuple[float, float]:
        # steady-state speed at full voltage: w = Kt*Vmax / (R*B + Kt*Ke)
        p = self.p
        wmax = p["Kt"] * p["V_max"] / (p["R"] * p["B"] + p["Kt"] * p["Ke"])
        return (-wmax, wmax)

    def viz_state(self) -> Dict[str, float]:
        i, w = self.x
        p = self.p
        return {
            "current": float(i),
            "speed": float(w),
            "voltage": float(self.last_u),
            "back_emf": float(p["Ke"] * w),
            "torque": float(p["Kt"] * i),
            "i_max": p["V_max"] / p["R"],     # stall current, for circuit scaling
        }
