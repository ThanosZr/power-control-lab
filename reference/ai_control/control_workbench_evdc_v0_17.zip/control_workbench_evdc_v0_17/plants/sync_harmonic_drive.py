"""Simplified battery + inverter + surface-PMSM drive with EMF harmonics.

This plant is deliberately lightweight.  It is NOT a finite-element PMSM model
and it is NOT a switching inverter.  Its purpose is to give the workbench a
second, synchronous-machine-style plant where a harmonic-injection controller
can be demonstrated in Python before moving the idea to MATLAB/Simulink.

States
------
x = [i_q, omega_m, theta_m, SOC, distance_m, energy_draw_J]

Input
-----
u = v_q command [V].  The battery/inverter envelope clips the requested q-axis
voltage according to SOC, pack OCV, internal resistance, and DC-link limit.

Motor model
-----------
The q-axis current dynamics include a non-sinusoidal back-EMF disturbance:

    Lq di_q/dt = v_q - R_s i_q - Ke omega_m - e_h(theta_e, omega_m)

where e_h contains 5th, 7th, 11th and 13th electrical harmonics.  A controller
can reduce current ripple by adding approximately +e_h to the commanded voltage.
The torque model is also simplified:

    tau_e = Kt i_q + tau_cog(theta_e)

This gives visible ripple/THD-proxy signals without requiring a full three-phase
FOC/SVPWM simulation.
"""
from __future__ import annotations

from typing import Dict, Tuple

import numpy as np

from core.plant import Plant
from core.registry import register_plant

_EPS = 1e-9


@register_plant
class HarmonicSPMSMDrivePlant(Plant):
    id = "spmsm_harm"
    name = "Battery + inverter SPMSM harmonic model"
    input_name = "vq_cmd"
    input_unit = "V"
    output_name = "ω"
    output_unit = "rad/s"

    substeps = 24

    PARAMS = {
        # SPMSM-like equivalent q-axis model
        "Rs": 0.18,
        "Lq": 0.0035,
        "Ke": 0.18,
        "Kt": 0.18,
        "pole_pairs": 4.0,
        "J_motor": 0.015,
        "B": 0.010,
        "gear_ratio": 7.0,
        "drivetrain_eta": 0.92,
        "wheel_radius": 0.255,
        "target_vmax_kph": 45.0,

        # Harmonic back-EMF amplitudes as fraction of Ke*omega.
        "h5": 0.070,
        "h7": 0.050,
        "h11": 0.025,
        "h13": 0.020,
        "phi5": 0.30,
        "phi7": -0.45,
        "phi11": 0.80,
        "phi13": -1.10,
        "cogging_tau": 0.060,

        # Vehicle / road load, same meaning as evdc.
        "vehicle_mass": 115.0,
        "payload_mass": 0.0,
        "Crr": 0.012,
        "CdA": 0.32,
        "rho_air": 1.225,
        "grade_pct": 0.0,
        "grade_amp_pct": 1.5,
        "grade_period_m": 90.0,
        "T_load_base": 0.05,
        "T_load_amp": 0.45,
        "load_period_m": 55.0,

        # Battery + averaged inverter envelope.
        "SOC0": 0.85,
        "capacity_Ah": 18.0,
        "OCV_min": 45.0,
        "OCV_max": 58.8,
        "Rint_base": 0.075,
        "Rint_soc_gain": 2.6,
        "inverter_eta": 0.95,
        "boost_ratio_max": 1.75,
        "Vout_abs_max": 96.0,
        "I_bat_max": 140.0,
    }

    def initial_state(self) -> np.ndarray:
        return np.array([0.0, 0.0, 0.0, float(self.p["SOC0"]), 0.0, 0.0], dtype=float)

    # ------------------------------------------------------------------ #
    def _soc_clip(self, soc: float) -> float:
        return float(np.clip(soc, 0.0, 1.0))

    def _ocv(self, soc: float) -> float:
        s = self._soc_clip(soc)
        lin = self.p["OCV_min"] + (self.p["OCV_max"] - self.p["OCV_min"]) * s
        knee = -1.8 * (1.0 - s) ** 3
        return float(max(1.0, lin + knee))

    def _rint(self, soc: float) -> float:
        s = self._soc_clip(soc)
        return float(self.p["Rint_base"] * (1.0 + self.p["Rint_soc_gain"] * (1.0 - s) ** 2))

    def _theta_e(self, x: np.ndarray) -> float:
        return float(self.p["pole_pairs"] * x[2])

    def harmonic_bemf(self, x: np.ndarray) -> float:
        """Back-EMF harmonic disturbance [V] for the current state."""
        return float(sum(self.harmonic_components(x).values()))

    def harmonic_components(self, x: np.ndarray) -> Dict[int, float]:
        """Per-order harmonic back-EMF components [V].

        The total harmonic disturbance is the sum of these components.  Exposing
        the individual orders makes the GUI useful for explaining what the
        harmonic-injection controller is actually injecting: 5th, 7th, 11th and
        13th electrical harmonics.
        """
        _iq, w, _theta, _soc, _dist, _energy = x
        th = self._theta_e(x)
        base = self.p["Ke"] * w
        return {
            5: float(base * self.p["h5"] * np.sin(5.0 * th + self.p["phi5"])),
            7: float(base * self.p["h7"] * np.sin(7.0 * th + self.p["phi7"])),
            11: float(base * self.p["h11"] * np.sin(11.0 * th + self.p["phi11"])),
            13: float(base * self.p["h13"] * np.sin(13.0 * th + self.p["phi13"])),
        }


    def harmonic_amplitude_components(self, x: np.ndarray) -> Dict[int, float]:
        """Per-order harmonic back-EMF amplitudes [V].

        Unlike harmonic_components(), these are not instantaneous signed values.
        They are the amplitudes Ah used by the compensation-style reconstruction
        Uinj = sum Ah*cos(h*theta_e + phi_h + phase).  They are useful for
        THD-like proxies, because instantaneous harmonic samples can cancel even
        when harmonic content is high.
        """
        _iq, w, _theta, _soc, _dist, _energy = x
        base = abs(self.p["Ke"] * w)
        return {
            5: float(base * abs(self.p["h5"])),
            7: float(base * abs(self.p["h7"])),
            11: float(base * abs(self.p["h11"])),
            13: float(base * abs(self.p["h13"])),
        }

    def harmonic_unit_components(self, x: np.ndarray) -> Dict[int, float]:
        """Per-order dimensionless harmonic waveform components."""
        _iq, _w, _theta, _soc, _dist, _energy = x
        th = self._theta_e(x)
        return {
            5: float(self.p["h5"] * np.sin(5.0 * th + self.p["phi5"])),
            7: float(self.p["h7"] * np.sin(7.0 * th + self.p["phi7"])),
            11: float(self.p["h11"] * np.sin(11.0 * th + self.p["phi11"])),
            13: float(self.p["h13"] * np.sin(13.0 * th + self.p["phi13"])),
        }

    def harmonic_unit(self, x: np.ndarray) -> float:
        """Dimensionless harmonic waveform used for plots/control."""
        return float(sum(self.harmonic_unit_components(x).values()))

    def torque_ripple(self, x: np.ndarray) -> float:
        iq, _w, _theta, _soc, _dist, _energy = x
        th = self._theta_e(x)
        # Small cogging-like 6th electrical ripple plus current-dependent component.
        return float(self.p["cogging_tau"] * np.sin(6.0 * th) +
                     0.015 * abs(self.p["Kt"] * iq) * np.sin(12.0 * th + 0.4))

    def _vehicle_quantities(self, x: np.ndarray) -> Dict[str, float]:
        iq, w, _theta, _soc, distance, _energy = x
        p = self.p
        m = p["vehicle_mass"] + p["payload_mass"]
        g = 9.80665
        gear = max(p["gear_ratio"], _EPS)
        rw = max(p["wheel_radius"], _EPS)
        v = w / gear * rw
        sgn = float(np.tanh(v / 0.25))
        grade_pct = p["grade_pct"] + p["grade_amp_pct"] * np.sin(2.0 * np.pi * distance / max(p["grade_period_m"], 1.0))
        grade = grade_pct / 100.0
        f_roll = m * g * p["Crr"] * sgn
        f_drag = 0.5 * p["rho_air"] * p["CdA"] * v * abs(v)
        f_grade = m * g * np.sin(np.arctan(grade))
        f_total = f_roll + f_drag + f_grade
        t_wheel = f_total * rw
        t_road_motor = t_wheel / (gear * max(p["drivetrain_eta"], 0.1))
        t_variable = (p["T_load_base"] +
                      p["T_load_amp"] * (0.5 + 0.5 * np.sin(2.0 * np.pi * distance / max(p["load_period_m"], 1.0)))) * sgn
        j_equiv = p["J_motor"] + m * (rw / gear) ** 2
        return {
            "vehicle_speed_mps": float(v),
            "vehicle_speed_kph": float(3.6 * v),
            "distance_m": float(distance),
            "grade_pct_live": float(grade_pct),
            "road_force_N": float(f_total),
            "road_load_torque": float(t_road_motor),
            "variable_load_torque": float(t_variable),
            "load_torque": float(t_road_motor + t_variable),
            "J_equiv": float(j_equiv),
        }

    def _battery_inverter(self, x: np.ndarray, u_cmd: float) -> Dict[str, float]:
        iq, _w, _theta, soc, _distance, _energy = x
        p = self.p
        ocv = self._ocv(soc)
        rint = self._rint(soc)
        v_avail = min(p["Vout_abs_max"], p["boost_ratio_max"] * ocv)
        vq = float(np.clip(u_cmd, -v_avail, v_avail))
        p_motor_elec = vq * iq
        eta = float(np.clip(p["inverter_eta"], 0.01, 1.0))
        p_bat = p_motor_elec / eta if p_motor_elec >= 0.0 else p_motor_elec * eta
        p_cap = 0.95 * ocv * ocv / max(4.0 * rint, _EPS)
        p_bat_limited = float(np.clip(p_bat, -p_cap, p_cap))
        disc = max(ocv * ocv - 4.0 * rint * p_bat_limited, 0.0)
        i_bat = (ocv - np.sqrt(disc)) / max(2.0 * rint, _EPS)
        i_bat = float(np.clip(i_bat, -p["I_bat_max"], p["I_bat_max"]))
        v_bat = float(ocv - i_bat * rint)
        # Keep the displayed/logged battery power physically consistent with
        # the terminal battery quantities after current limiting.  Earlier
        # versions kept the pre-limit requested power in p_bat_W, which could
        # make the live panel show impossible combinations such as 50 V, 60 A
        # and hundreds of kW.  The requested/model power is still exposed for
        # debugging as p_bat_request_W.
        p_bat_terminal = float(v_bat * i_bat)
        duty_equiv = float(np.clip(abs(vq) / max(v_avail, 1.0), 0.0, 0.98))
        return {
            "v_arm": float(vq),
            "v_cmd": float(u_cmd),
            "v_ocv": float(ocv),
            "v_bat": v_bat,
            "v_sag": float(ocv - v_bat),
            "i_bat": i_bat,
            "p_motor_elec_W": float(p_motor_elec),
            "p_bat_W": float(p_bat_terminal),
            "p_bat_request_W": float(p_bat_limited),
            "p_bat_vi_W": float(p_bat_terminal),
            "converter_duty": duty_equiv,
            "v_available": float(v_avail),
        }

    # ------------------------------------------------------------------ #
    def deriv(self, x: np.ndarray, u: float) -> np.ndarray:
        iq, w, theta, soc, distance, energy_j = x
        p = self.p
        elec = self._battery_inverter(x, u)
        road = self._vehicle_quantities(x)
        vq = elec["v_arm"]
        eh = self.harmonic_bemf(x)
        diq = (vq - p["Rs"] * iq - p["Ke"] * w - eh) / p["Lq"]
        tau_e = p["Kt"] * iq + self.torque_ripple(x)
        dw = (tau_e - p["B"] * w - road["load_torque"]) / max(road["J_equiv"], _EPS)
        dtheta = w
        q_coul = max(p["capacity_Ah"] * 3600.0, 1.0)
        dsoc = -elec["i_bat"] / q_coul
        ddist = max(road["vehicle_speed_mps"], 0.0)
        denergy = max(elec["p_bat_W"], 0.0)
        return np.array([diq, dw, dtheta, dsoc, ddist, denergy], dtype=float)

    def step(self, u: float, dt: float) -> float:
        y = super().step(u, dt)
        self.x[2] = np.mod(self.x[2], 2.0 * np.pi)
        self.x[3] = np.clip(self.x[3], 0.0, 1.0)
        self.x[4] = max(self.x[4], 0.0)
        self.x[5] = max(self.x[5], 0.0)
        return y

    def output(self) -> float:
        return float(self.x[1])

    def measured(self) -> np.ndarray:
        road = self._vehicle_quantities(self.x)
        return np.array([self.x[1], self.x[0], self.x[3], road["load_torque"], self._theta_e(self.x)], dtype=float)

    def measured_scale(self) -> np.ndarray:
        wmax = max(abs(self.y_range()[0]), abs(self.y_range()[1]), 1.0)
        imax = max(self.p["Vout_abs_max"] / max(self.p["Rs"], _EPS), 1.0)
        return np.array([wmax, imax, 1.0, 10.0, 2*np.pi], dtype=float)

    def u_range(self) -> Tuple[float, float]:
        v = float(self.p["Vout_abs_max"])
        return (-v, v)

    def y_range(self) -> Tuple[float, float]:
        p = self.p
        vmax_elec = min(p["Vout_abs_max"], p["boost_ratio_max"] * p["OCV_max"])
        # no-load q-axis speed limit for the simplified PMSM model
        wmax_elec = 0.95 * vmax_elec / max(p["Ke"], _EPS)
        v_target_mps = max(float(p.get("target_vmax_kph", 45.0)), 1.0) / 3.6
        wmax_vehicle = v_target_mps * max(p["gear_ratio"], _EPS) / max(p["wheel_radius"], _EPS)
        wmax = min(wmax_elec, wmax_vehicle)
        return (-0.10 * wmax, wmax)

    def viz_state(self) -> Dict[str, float]:
        iq, w, theta, soc, distance, energy_j = self.x
        p = self.p
        road = self._vehicle_quantities(self.x)
        elec = self._battery_inverter(self.x, self.last_u)
        tau_base = p["Kt"] * iq
        tau_rip = self.torque_ripple(self.x)
        torque = tau_base + tau_rip
        p_bat_kw = elec["p_bat_W"] / 1000.0
        energy_kwh = energy_j / 3.6e6
        distance_km = distance / 1000.0
        km_per_kwh = distance_km / energy_kwh if energy_kwh > 1e-9 else 0.0
        wh_per_km = 1000.0 * energy_kwh / distance_km if distance_km > 1e-9 else 0.0
        nm_per_kw = abs(torque) / max(abs(p_bat_kw), 1e-6) if p_bat_kw > 1e-6 else 0.0
        # Instantaneous vehicle efficiency estimate. This is not cumulative,
        # so it is useful for live ON/OFF comparisons without being polluted by
        # the launch transient already stored in distance/energy. Units:
        # (km/h) / kW = km/kWh.
        km_per_kwh_inst = road["vehicle_speed_kph"] / p_bat_kw if p_bat_kw > 1e-6 else 0.0
        wh_per_km_inst = 1000.0 / km_per_kwh_inst if km_per_kwh_inst > 1e-9 else 0.0
        eh = self.harmonic_bemf(self.x)
        harmonic_components = self.harmonic_components(self.x)
        harmonic_amp_components = self.harmonic_amplitude_components(self.x)
        harmonic_unit_components = self.harmonic_unit_components(self.x)
        ebase = p["Ke"] * w
        th_e = self._theta_e(self.x)
        # Two useful harmonic indicators are exposed:
        #   signed-sum proxy: |h5+h7+h11+h13| / |fundamental|
        #       This can look deceptively small when harmonic orders cancel at
        #       one instant.
        #   RMS-order proxy: sqrt(h5^2+h7^2+h11^2+h13^2) / |fundamental|
        #       This is the default GUI THD proxy because it shows harmonic
        #       content even when the signed sum happens to be near zero.
        base_abs = max(abs(ebase), 1e-6)
        harmonic_rss = float(np.sqrt(sum(float(v) ** 2 for v in harmonic_components.values())))
        thd_signed_proxy = abs(eh) / base_abs
        thd_rms_proxy = harmonic_rss / base_abs
        return {
            "current": float(iq),
            "iq": float(iq),
            "speed": float(w),
            "theta_m": float(theta),
            "theta_e": float(np.mod(th_e, 2.0*np.pi)),
            "voltage": float(elec["v_arm"]),
            "command_voltage": float(self.last_u),
            "back_emf": float(ebase),
            "bemf_harmonic": float(eh),
            "bemf_h5": float(harmonic_components[5]),
            "bemf_h7": float(harmonic_components[7]),
            "bemf_h11": float(harmonic_components[11]),
            "bemf_h13": float(harmonic_components[13]),
            "bemf_amp_h5": float(harmonic_amp_components[5]),
            "bemf_amp_h7": float(harmonic_amp_components[7]),
            "bemf_amp_h11": float(harmonic_amp_components[11]),
            "bemf_amp_h13": float(harmonic_amp_components[13]),
            "harmonic_unit": float(self.harmonic_unit(self.x)),
            "harmonic_unit_h5": float(harmonic_unit_components[5]),
            "harmonic_unit_h7": float(harmonic_unit_components[7]),
            "harmonic_unit_h11": float(harmonic_unit_components[11]),
            "harmonic_unit_h13": float(harmonic_unit_components[13]),
            "harmonic_thd_proxy": float(thd_rms_proxy),
            "harmonic_thd_raw_proxy": float(thd_rms_proxy),
            "harmonic_thd_signed_proxy": float(thd_signed_proxy),
            "harmonic_rss_v": float(harmonic_rss),
            "torque": float(torque),
            "torque_base": float(tau_base),
            "torque_ripple": float(tau_rip),
            "i_max": p["Vout_abs_max"] / max(p["Rs"], _EPS),
            "soc": float(np.clip(soc, 0.0, 1.0)),
            "soc_pct": float(100.0 * np.clip(soc, 0.0, 1.0)),
            "energy_kwh": float(energy_kwh),
            "distance_m": float(distance),
            "distance_km": float(distance_km),
            "km_per_kwh_live": float(km_per_kwh),
            "wh_per_km_live": float(wh_per_km),
            "nm_per_kw_live": float(nm_per_kw),
            "km_per_kwh_inst": float(km_per_kwh_inst),
            "wh_per_km_inst": float(wh_per_km_inst),
            "vehicle_mass_total": float(p["vehicle_mass"] + p["payload_mass"]),
            "gear_ratio": float(p["gear_ratio"]),
            "wheel_radius": float(p["wheel_radius"]),
            "target_vmax_kph": float(p.get("target_vmax_kph", 45.0)),
            **elec,
            **road,
        }
