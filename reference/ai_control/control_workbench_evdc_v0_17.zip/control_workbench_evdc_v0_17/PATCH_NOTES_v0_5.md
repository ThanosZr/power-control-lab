# Patch Notes v0.6 — Grade-Adaptive Speed Target

This release adds a more realistic EV speed reference scenario.

## New scenario: `grade_adaptive`

The previous EV scenario `urban` was a fixed positive speed cycle. It did not
change its target speed when the route became steeper.

`grade_adaptive` keeps a normal speed target, but shapes it using the planned
road grade:

- launches from rest,
- cruises,
- moderates the target speed on uphill sections,
- allows mild recovery on downhill sections,
- applies a small low-SOC derating,
- remains a reference trajectory, not a hidden controller.

The plant still computes the real physical road load separately. Therefore the
experiment now has two distinct layers:

1. **Mission target**: what speed the driver/supervisor asks for.
2. **Plant physics**: what the battery + converter + DC motor + vehicle can
   actually achieve.

This is useful for comparing Eco / Balanced / Performance control strategies.

## Example CLI run

```bat
python cli.py run --plant evdc --scenario grade_adaptive --schemes pid --duration 8 --dt 0.1 --soc0 55 --payload 35 --grade 4 --grade-amp 2.5 --metrics grade_metrics.csv --plot grade_plot.png
```

## Why this matters

A fixed speed reference is useful for clean controller benchmarking, but EV
energy studies often need a mission-level target that reacts to road conditions.
For example, on steep uphill sections an energy-aware supervisor may intentionally
ask for a slightly lower speed target to preserve SOC, reduce current stress,
and improve km/kWh.

This update prepares the workbench for the next step: explicit multi-objective
modes such as Eco, Balanced, and Performance.
