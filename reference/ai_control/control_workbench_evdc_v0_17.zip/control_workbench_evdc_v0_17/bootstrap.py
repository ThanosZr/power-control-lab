"""Import once to populate every registry (scenarios, plants, schemes,
exporters). main.py and cli.py both `import bootstrap` before building a
Session, so registration always happens first."""
from __future__ import annotations

import core.scenario            # noqa: F401  scenarios self-register
import core.export              # noqa: F401  exporters self-register
import plants.dc_motor          # noqa: F401
import plants.induction_motor   # noqa: F401
import plants.ev_dc_drive       # noqa: F401
import plants.sync_harmonic_drive  # noqa: F401
import schemes.pid              # noqa: F401
import schemes.indirect_inverse  # noqa: F401
import schemes.multi_objective  # noqa: F401
import schemes.harmonic_injection  # noqa: F401
