# Migration Context — Multi-Objective AI Control Workbench v0.16

## Project name
**Multi-Objective AI Control Workbench for Electric Drive Energy Optimization**

## Why this project exists
This started as a Python prototype to explore AI/control ideas for electric drives before migrating the concept to MATLAB/Simulink. The long-term direction is a MATLAB/Simulink + App Designer workbench where the user can select plants, controllers, objectives, converter models, and optional modules such as harmonic injection.

The current Python version is **not** a high-fidelity EV/PMSM simulator. It is a control-oriented concept prototype used to test architecture, GUI workflow, signals, metrics, and before/after comparisons.

## Latest package
Upload and continue from:

- `control_workbench_evdc_v0_16.zip`

The zip includes the documentation files:

- `README.md`
- `HOW_TO_RUN.md`
- `ARCHITECTURE.md`
- `EV_EXTENSION.md`
- `COUPLED_CONTROL_PLAN.md`
- `HARMONIC_INJECTION.md`
- `PATCH_NOTES_v0_16.md`
- earlier patch notes

## Most relevant model for the current direction
The model we care about now is:

```text
Plant    = spmsm_harm
Scenario = straight_flat
Scheme   = hinj
```

In the GUI this appears roughly as:

```text
Plant    = Battery + inverter SPMSM harmonic model / spmsm_harm
Scenario = straight_flat
Scheme   = SPMSM harmonic injection control / hinj
```

This is the cleanest setup for debugging harmonic injection because it removes grade/load disturbance. Use `grade_adaptive` only after `straight_flat` behaves logically.

## Why `straight_flat` matters
In previous tests, `grade_adaptive` made `Pbat`, torque, load, and energy metrics swing because the load/grade target was changing during the run. That made it hard to tell whether harmonic injection improved anything.

For harmonic injection validation, use a clean steady condition first:

```text
straight_flat + spmsm_harm + hinj
```

Then compare ON/OFF using the harmonic metrics, not cumulative mission km/kWh.

## How to run
Install dependencies:

```bash
pip install -r requirements.txt
```

Run diagnostics:

```bash
python diagnose.py
```

Launch GUI:

```bash
python main.py
```

CLI clean ON test:

```bash
python cli.py run --plant spmsm_harm --scenario straight_flat --schemes hinj --duration 8 --dt 0.02 --soc0 70 --grade 0 --grade-amp 0 --load-amp 0 --vehicle-mass 115 --wheel-radius 0.255 --gear 7 --target-vmax 45 --harmonic-gain 1.0 --metrics v16_on.csv --plot v16_on.png
```

CLI clean OFF test:

```bash
python cli.py run --plant spmsm_harm --scenario straight_flat --schemes hinj --duration 8 --dt 0.02 --soc0 70 --grade 0 --grade-amp 0 --load-amp 0 --vehicle-mass 115 --wheel-radius 0.255 --gear 7 --target-vmax 45 --harmonic-off --metrics v16_off.csv --plot v16_off.png
```

## Current important interpretation
For `hinj`, do **not** judge live ON/OFF from cumulative `km/kWh`. That value depends on the whole run history, SOC history, transient launch, distance integration, and previous ON/OFF state.

Judge harmonic injection from these metrics instead:

```text
settled_current_thd_raw_proxy
settled_current_thd_residual_proxy
mean_harmonic_loss_residual_W
rms_current_harmonic_torque_ripple_nm
```

The GUI should also show same-state ON/OFF estimates. Those are intended to compare ON and OFF at the same state, not at different time instants.

## What the reference technique actually does

Harmonic compensation is a known general technique for a surface-PMSM
drive. In outline its method is:

```text
a detailed machine model
→ extraction of the dominant EMF harmonics
→ amplitude/phase maps for 5th, 7th, 11th, 13th harmonics
→ real-time voltage harmonic injection in abc reference
→ conventional PI + SVPWM reference is augmented
→ current THD and torque ripple are reduced
```

A high-fidelity model would be expected to reduce current THD and torque ripple at a fixed operating point, validated in a Simulink model.

## What our Python model does
The Python model is only a simplified concept demonstrator. It does **not** yet include:

- true abc phase currents,
- dq-to-abc transformation,
- real SVPWM,
- detailed harmonic maps,
- FFT-based current THD,
- nonlinear flux maps,
- proper inverter switching model.

It currently approximates harmonic effects using a simplified q-axis SPMSM-like plant with harmonic EMF orders and an injection voltage proxy.

## Current concern / next debugging target
The user observed that toggling harmonic injection ON/OFF sometimes caused weird cumulative `km/kWh` behavior and inconsistent results. The likely causes were:

1. comparing cumulative energy/distance values after different state histories,
2. using `grade_adaptive` while debugging harmonic injection,
3. relying on proxies instead of real current waveform FFT,
4. simplified plant dynamics being too artificial.

v0.16 partially addressed this by adding same-state comparison and better proxy metrics, but the next chat should verify the implementation carefully.

## Recommended next patch
Focus on making `hinj` scientifically cleaner rather than adding more GUI features.

Recommended next steps:

1. Add an explicit harmonic validation mode:
   ```text
   Plant = spmsm_harm
   Scenario = straight_flat
   Scheme = hinj
   Fixed operating point: speed, torque/current, SOC
   ```

2. Run ON and OFF from identical initial conditions and same duration.

3. Add a reproducible comparison button or CLI command:
   ```text
   compare_hinj --same-initial-state --straight-flat
   ```

4. Add a simple synthetic abc current reconstruction for visualization:
   ```text
   ia = I1 sin(theta) + I5 sin(5 theta + phi5) + ...
   ```
   Then compute actual FFT-style THD on this synthetic current.

5. Make the GUI show:
   ```text
   raw harmonic orders: h5 h7 h11 h13
   injected harmonic voltage: u5 u7 u11 u13
   residual harmonic voltage/current: r5 r7 r11 r13
   synthetic current THD before/after
   torque ripple before/after
   ```

6. Avoid claiming the Python model is equivalent to the reference technique. Phrase it as:
   ```text
   simplified harmonic-injection concept demonstrator inspired by map-based harmonic compensation
   ```

## Suggested first message in a new chat
Copy/paste this after uploading the zip and this markdown:

```text
We are continuing a project called “Multi-Objective AI Control Workbench for Electric Drive Energy Optimization”. I uploaded `control_workbench_evdc_v0_16.zip` and this migration context markdown.

Please inspect the package and continue from v0.16. The current priority is debugging the harmonic injection branch. The relevant setup is `Plant=spmsm_harm`, `Scenario=straight_flat`, `Scheme=hinj`. Do not focus on `grade_adaptive` yet. I want a scientifically cleaner before/after harmonic injection comparison, preferably with same-state ON/OFF comparison and synthetic abc-current reconstruction so that THD is more meaningful.

First, tell me how to run the current clean test. Then propose and implement the next patch.
```

## What to upload to the new chat
Upload these:

1. `control_workbench_evdc_v0_16.zip`
2. `MIGRATION_CONTEXT_v0_16.md`
3. screenshots showing weird harmonic behavior, if available
4. terminal errors, if any

