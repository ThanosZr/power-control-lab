# Patch notes — v0.11

## Main goal

Reduce GUI chaos and add a first expandable harmonic-injection sandbox.

## Added Help button

A new top-bar button was added:

```text
❓ Help
```

It opens a structured help window with topic navigation:

- Quick start
- Plants
- Schemes / loops
- Vehicle settings
- Multi-objective idea
- Harmonic injection
- MATLAB / Simulink path
- Files / docs

The window can also open `HOW_TO_RUN.md` and `HARMONIC_INJECTION.md` directly.

## Added simplified synchronous machine plant

New plant:

```text
spmsm_harm
```

Display name:

```text
Battery + inverter SPMSM harmonic model
```

It includes:

- SOC-dependent battery model
- averaged inverter voltage envelope
- q-axis SPMSM current dynamics
- electrical rotor angle
- 5th, 7th, 11th, 13th synthetic back-EMF harmonics
- simplified torque ripple
- same vehicle/load/grade metrics as the EV/DC plant

## Added harmonic-injection control scheme

New scheme:

```text
hinj
```

Display name:

```text
SPMSM harmonic injection control
```

It uses:

- speed reference governor
- outer speed loop
- vehicle-dynamics torque synthesis
- SOC/power allocator
- inner current/torque loop
- harmonic voltage feed-forward branch

The command is:

```text
v_total = v_base + v_harm
```

with:

```text
v_harm ≈ harmonic_gain * e_h(theta_e, omega)
```

## Updated Loop diagram

When `hinj` is active, the first tab now shows an additional harmonic branch:

```text
theta_e, omega → harmonic model → v_harm → voltage command
```

## Updated Settings

The Settings window now includes harmonic-injection controls:

- enable/disable harmonic injection
- harmonic gain
- harmonic voltage limit

These are applied on Rebuild.

## Updated State panel

When the selected plant exposes harmonic variables, the State panel shows:

- electrical angle `theta_e`
- harmonic back-EMF `e_h`
- harmonic THD proxy
- torque ripple
- q-axis current/current

## CLI smoke test

```bash
python cli.py run --plant spmsm_harm --scenario grade_adaptive --schemes hinj pid --duration 8 --dt 0.05 --soc0 70 --grade 3 --grade-amp 2 --vehicle-mass 115 --wheel-radius 0.255 --gear 7 --target-vmax 45 --metrics spmsm_hinj_metrics.csv --plot spmsm_hinj_plot.png
```

## Important limitation

This is a simplified Python control sandbox. It is not a high-fidelity PMSM/FOC/SVPWM model. The value is architectural: the workbench can now host a harmonic-injection module in parallel with the speed/torque/energy loops.
