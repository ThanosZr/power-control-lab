# Patch Notes v0.8 — Coupled Multi-Loop EV Control

## Added

New scheme:

```text
moevc = Coupled multi-loop EV control
```

This scheme explicitly couples speed and torque through vehicle dynamics.
Instead of treating torque as a passive metric, it computes torque demand from:

```text
tau_required = J_equiv * alpha_ref + B * omega + tau_load
```

Then it sends that torque demand through a multi-objective allocator that
considers SOC, current limit, power limit and energy/performance weights.

## New control structure

```text
mission omega target
    -> reference governor
    -> governed omega target
    -> speed loop / acceleration planner
    -> vehicle dynamics torque coupler
    -> SOC/power/energy torque allocator
    -> torque/current loop
    -> voltage command
    -> battery + boost + DC motor + vehicle plant
```

## New logged variables

```text
r_cmd
r_governed
omega_feasible_next
alpha_cmd
alpha_feasible
tau_road_ff
tau_accel
tau_available_pos
tau_available_neg
allocation_keep
p_pred_kw
constraint_reason
vehicle_speed_ref_kph
vehicle_speed_governed_kph
```

## Why this matters

v0.7 had a speed loop, torque/current loop and energy supervisor, but the loops
were still mostly cascaded.  v0.8 adds the missing scientific coupling: desired
speed trajectory implies desired acceleration, desired acceleration implies
shaft torque, shaft torque implies current and battery power.

This is the structure needed before adding separate ANN emulator/inverse pairs
for each loop.

## Example

```bat
python cli.py run --plant evdc --scenario grade_adaptive --schemes moevc moev pid --duration 8 --dt 0.1 --soc0 55 --payload 35 --grade 4 --grade-amp 2.5 --vehicle-mass 115 --wheel-radius 0.255 --gear 7 --target-vmax 45 --metrics multiobj_coupled.csv --plot multiobj_coupled.png
```
