# Patch notes v0.17 — harmonic injection: ZOH-decoupling + iron-loss energy model

v0.17 builds on the v0.16 harmonic-injection sanity work. It fixes the remaining
"injection ON is not better than OFF" behaviour and finally makes the effective
efficiency respond to the toggle, in a physically-motivated way.

All changes are in `schemes/harmonic_injection.py` and a display tweak in
`gui/app.py`. The plant, core and other schemes are unchanged.

## 1. Decoupled the integrated plant command from the frozen injection

The injection voltage is computed once per macro-step (dt = 20 ms at most → 50 Hz)
and then held constant by the plant's zero-order hold across the RK4 substeps,
while the harmonic back-EMF it must cancel runs at ~700–1800 Hz (the 5th does
~14 cycles per step, the 13th ~36). A 50 Hz-sampled, frozen value cannot track
that, so feeding it into the integrated voltage cancelled nothing dynamically
and only injected spurious ZOH energy — which made injection ON look *worse*
than OFF in km/kWh.

`micro_step` now drives the plant with the clean base command
`u_applied = clip(u_base)`. `u_harm` / `u_h*` are still computed and logged as
the *intended* injection estimate (`u_total`) for the harmonic plots, and the
harmonic benefit is expressed in the amplitude / AC-loss domain. Anti-windup and
`plant.step` use `u_applied`.

Consequence (by design): the cumulative `km/kWh` is now identical ON vs OFF —
it is not the metric to judge harmonic compensation by. Use the harmonic metrics instead.

## 2. Added a frequency-weighted harmonic IRON / eddy-current loss proxy

Earlier proxies only modelled harmonic *copper* loss, `Rs · Σ i_h²`. Because Lq
filters the harmonic currents down to ~1 % THD, that loss is ~0.02 W on ~1 kW —
so cancelling it changed the effective km/kWh by < 0.01 %, i.e. nothing visible.

But the efficiency gain of interest is driven mainly by
**core / eddy losses**, which track the harmonic *flux* (i.e. the harmonic
back-EMF), not the heavily-filtered terminal current. v0.17 adds that term:

```
P_fe(h) = harmonic_iron_loss_scale · h^harmonic_iron_freq_exp · E_h²
```

summed over h ∈ {5,7,11,13}, using the per-order harmonic back-EMF amplitude
`E_h`. The injection cancels `E_h`, so the residual iron loss → 0 with injection
ON. This finally makes the effective km/kWh respond ON vs OFF, mirroring the
reference's mechanism. Total harmonic loss reported is copper + iron.

New scheme parameters (all optional):

| param | default | meaning |
|---|---|---|
| `harmonic_iron_loss_scale` | `0.18` | W per (V² · order-weight); `0` recovers the pure copper model |
| `harmonic_iron_freq_exp`   | `1.0`  | order weighting exponent (higher → high-order harmonics cost more) |
| `harmonic_loss_scale`      | `3.0`  | copper-loss proxy scale (unchanged from v0.16) |

The default `0.18` is deliberately conservative: it yields about a **1–1.5 %**
effective-efficiency benefit at a typical operating point and ≈ 0.75 % on the
clean `straight_flat` test — visible, but below the full-model figure, which belongs
to a full detailed iron-loss model in the MATLAB/Simulink stage.

New diagnostic fields: `harmonic_iron_loss_raw_W`, `harmonic_iron_loss_residual_W`,
`harmonic_copper_loss_raw_W`, `harmonic_copper_loss_residual_W`.

## 3. GUI display precision

`gui/app.py` now prints the harmonic loss with two decimals (was one), so the
residual loss is visible rather than rounding to `0.0 W`.

## What to look at for ON/OFF judgement

- **same-state A/B** block (live, identical state): `Ithd` 0.0108 → 0,
  `loss` ~12–15 W → 0, `km/kWh*` improves ~1–1.5 %.
- current THD proxy and torque ripple: the honest, fidelity-independent signals.
- NOT the cumulative `km/kWh` (decoupled by design), and NOT the
  "last ON/OFF comparison" snapshot block (it samples two different time
  instants when you toggle the live switch, so its gap is an instant artifact).

## Verification (clean `straight_flat`, dt = 0.02, gain = 1)

| metric | ON | OFF |
|---|---|---|
| base km/kWh                  | 14.7095 | 14.7095 |
| effective km/kWh             | 14.7513 | 14.6413 |
| mean harmonic loss residual  | 0.0 W   | 12.65 W |
| settled residual current THD | 0.0000  | 0.0123  |

Gain sweep still shows the correct optimum at gain = 1 (100 % cancellation),
with under- and over-injection both leaving residual harmonics.

See `HARMONIC_PROPOSALS.md` for the path-2 (dynamically-faithful, per-substep /
SVPWM / detailed-map) plan for the MATLAB/Simulink migration.
