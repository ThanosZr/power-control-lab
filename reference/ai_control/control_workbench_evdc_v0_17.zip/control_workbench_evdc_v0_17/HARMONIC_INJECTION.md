# Simplified synchronous-machine harmonic-injection extension

A lightweight synchronous-machine sandbox so the workbench can demonstrate a
harmonic-injection control idea at concept level, before any move to
MATLAB/Simulink.

## New plant: `spmsm_harm`

A simplified battery + averaged-inverter + surface-PMSM drive model. It is **not**
a finite-element model, not a three-phase SVPWM model, and not intended to replace
MATLAB/Simulink or a detailed machine model. It is a control-level model with just enough physics to
demonstrate the principle:

```text
Battery + averaged inverter envelope
        ↓
q-axis SPMSM current dynamics
        ↓
rotor speed + electrical angle
        ↓
vehicle load + grade + SOC/energy metrics
```

The q-axis current equation is:

```text
Lq * diq/dt = vq - Rs*iq - Ke*omega - e_h(theta_e, omega)
```

where `e_h` is a synthetic non-sinusoidal back-EMF component containing 5th, 7th,
11th and 13th electrical harmonics. The torque model is:

```text
torque = Kt*iq + torque_ripple(theta_e)
```

This gives visible current/torque ripple without a full PMSM FOC/SVPWM model.

## New control scheme: `hinj`

`hinj` (synchronous-machine harmonic injection control) uses the coupled
multi-loop structure (reference governor → speed loop → vehicle-dynamics torque
synthesis → SOC/power allocator → inner torque-current loop → base voltage
command) and adds a parallel harmonic branch:

```text
theta_e, omega → harmonic model → v_harm
v_total = v_base + v_harm
```

Because the harmonic back-EMF subtracts from the current equation, a first-order
active cancellation command is `v_harm ≈ harmonic_gain * e_h(theta_e, omega)`.
This is a control-level analogue of **harmonic compensation**, a known
general technique. In a real PMSM drive it would become a three-phase voltage
reference modification before PWM/SVPWM.

## How to run

```text
Plant    = spmsm_harm
Scenario = grade_adaptive   (or straight_flat for a clean operating point)
Scheme   = synchronous-machine harmonic injection control
Mode     = Run · live target
```

CLI smoke test:

```bash
python cli.py run --plant spmsm_harm --scenario grade_adaptive --schemes hinj pid \
  --duration 8 --dt 0.05 --metrics spmsm_hinj_metrics.csv --plot spmsm_hinj_plot.png
```

## What to look at

GUI: the loop diagram shows the harmonic branch for `hinj`; the Signals tab has a
`harmonic injection` layer; the State/cost tab shows `theta_e`, `e_h`, a harmonic
THD proxy and a torque-ripple proxy. Metrics CSV: `u_base`, `u_harm`, `u_total`,
`bemf_harmonic`, `harmonic_thd_proxy`, `torque_ripple`.

For clean debugging use `straight_flat`, compare `--harmonic-gain 1.0` against
`--harmonic-off`, and prefer `settled_current_thd_*` as the sanity metric. These
are amplitude/EMF-residual **proxies**, not phase-current FFT THD.

## Relation to harmonic compensation (general technique)

compensation-style methods reconstruct an injection signal from per-order harmonic
amplitude/phase information and add it to the converter/PWM voltage reference. A
high-fidelity implementation would derive those amplitude/phase maps from detailed machine modelling or
detailed machine modelling and validate current THD with a real phase-current FFT.

This Python extension does **not** reproduce that fidelity. It only captures the
control-architecture idea:

```text
base motor control + model-aware harmonic voltage feed-forward
```

## Fidelity note / next stage

A later MATLAB/Simulink version can replace this simple harmonic model with a
FOC/SVPWM PMSM model, a Simscape inverter, measured or model-derived harmonic maps,
an ANN/map harmonic-coefficient module, and real current-THD / torque-ripple
metrics from phase-current FFT. That keeps the project expandable:

```text
DC EV drive baseline
        ↓
Coupled speed + torque + energy loops
        ↓
Synchronous-machine harmonic sandbox (this layer)
        ↓
MATLAB/Simulink high-fidelity PMSM + inverter
```

### Live ON/OFF tests — what to trust

Use the **same-state A/B** lines (computed at the same plant state): residual
current-THD proxy, harmonic copper-loss proxy, instantaneous effective `km/kWh`
proxy. Do **not** judge harmonic injection from cumulative `km/kWh` right after
toggling — cumulative mission energy includes the whole prior acceleration
history, so it can drift simply because time has passed.
