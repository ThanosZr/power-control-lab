# Patch Notes v0.9 — Active multi-loop diagram

## Why this patch exists

In v0.8 the `moev` and `moevc` controllers already implemented speed, torque/current, and SOC/energy allocation loops, but the first GUI tab still showed the original ANN inverse-control diagram.

That was misleading: the active loops existed in the scheme code and CSV logs, but they were not visible in the loop diagram.

## What changed

The **Loop diagram** tab now switches diagram automatically based on the selected scheme:

- `iaic` / ANN inverse schemes show the original:

  ```text
  reference -> ANN inverse -> plant -> output
                   |             |
                   v             v
                ANN emulator <- error
  ```

- `moev` and `moevc` show the active EV multi-loop architecture:

  ```text
  mission speed target
        ↓
  reference governor / feasibility check
        ↓
  outer speed loop
        ↓
  vehicle dynamics coupler
        ↓
  SOC / power allocator
        ↓
  inner torque-current loop
        ↓
  battery + boost + DC motor + vehicle plant
  ```

## Signals displayed in the multi-loop diagram

The new diagram exposes live values for:

- `ωcmd`
- `ωgov`
- measured `ω`
- speed error `eω`
- requested torque `τreq`
- limited torque reference `τref`
- torque error `eτ`
- current reference `iref`
- voltage command `u`
- SOC
- battery power
- grade
- load torque
- EV metrics such as km/kWh and Nm/kW

## Important distinction

The `moevc` scheme is still deterministic, not yet ANN-trained. It is the **coupled-loop scaffold** that will later allow module-by-module replacement with ANN emulator + inverse-controller pairs.

The intended next-stage AI mapping is:

```text
Speed module:
  speed emulator + speed inverse controller

Torque/current module:
  torque/current emulator + torque inverse controller

Energy/SOC module:
  energy emulator + supervisory inverse/allocation controller
```

This makes the workbench visually consistent with the multi-objective direction: speed tracking, torque/current control, and energy/SOC constraints are separate but coupled loops.
