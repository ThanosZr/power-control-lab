# Patch notes v0.14 — Harmonic THD proxy fix

## Why this patch exists

In v0.13 the live harmonic panel reported a very small `THD proxy` even when harmonic injection was OFF.  This was misleading because the displayed value used the **instantaneous signed sum** of the harmonic EMF orders:

```text
e_h = h5 + h7 + h11 + h13
THD_proxy_old = abs(e_h) / abs(Efund)
```

At some rotor angles the 5th, 7th, 11th and 13th terms partially cancel each other, so the signed sum can be small even though individual harmonic orders are still present.

## What changed

The default displayed harmonic proxy now uses an RMS-style order magnitude:

```text
raw_THD_proxy = sqrt(h5^2 + h7^2 + h11^2 + h13^2) / abs(Efund)
```

The harmonic injection controller also computes an effective/residual proxy:

```text
residual_h = EMF_h - injected_h
residual_THD_proxy = sqrt(residual_h5^2 + residual_h7^2 + residual_h11^2 + residual_h13^2) / abs(Efund)
```

Therefore:

- Harmonic injection OFF: residual ≈ raw
- Harmonic injection ON with gain ≈ 1: residual should drop
- Harmonic injection ON with bad gain/sign: residual can worsen

## GUI changes

The state panel now shows:

```text
THD proxy: raw=... residual=... cancel=...%
EMF orders: h5, h7, h11, h13
injected: h5, h7, h11, h13
residual: h5, h7, h11, h13
```

The ON/OFF snapshot panel now stores both raw and residual values so the before/after comparison is clearer.

## Export changes

Metrics CSV now includes:

```text
mean_harmonic_thd_proxy
mean_harmonic_thd_residual_proxy
mean_harmonic_cancellation_pct
```

Signals CSV now includes the per-order EMF, injected and residual harmonic components.

## Important limitation

This is still a simplified Python harmonic proxy.  It is not a real FFT of three-phase current and it is not an model-derived PMSM THD calculation.  It exists to demonstrate the control architecture before migrating the idea to MATLAB/Simulink.
