# Patch Notes v0.10 — Vehicle speed target slider

## Why this patch exists

In v0.9 the GUI exposed only a live motor-speed target:

```text
target omega [rad/s]
```

That was technically correct because the control schemes internally regulate motor angular speed. However, for the EV/DC plant it was not user-friendly: the user wants to command vehicle speed in km/h and let the workbench convert it to motor omega using wheel radius and gear ratio.

## What changed

The Scheme Control panel now has two synchronized live-target sliders:

```text
motor target omega [rad/s]
vehicle target speed [km/h]
```

Both represent the same target. Moving one updates the other.

The conversion is:

```text
v_vehicle[km/h] = omega_motor[rad/s] * wheel_radius[m] / gear_ratio * 3.6
```

and inversely:

```text
omega_motor[rad/s] = v_vehicle[km/h] / 3.6 * gear_ratio / wheel_radius
```

## Important distinction

`target max speed km/h` in Vehicle Settings is not the live target. It is the scenario/reference scaling cap. It defines the maximum speed used when a scenario such as `urban` or `grade_adaptive` is converted into a physical motor-speed reference.

The new `vehicle target speed [km/h]` slider is the live target used in:

```text
Mode = Run · live target
```

## What this fixes

Before v0.10, the workflow was:

```text
choose live target omega directly
```

Now the EV workflow can be:

```text
choose live target vehicle speed in km/h
GUI converts it to motor omega
controller tracks the equivalent motor-speed reference
```

This makes the model easier to interpret as an EV/vehicle model rather than a standalone motor-speed toy demo.

## Test command

```bat
python diagnose.py
python cli.py run --plant evdc --scenario grade_adaptive --schemes moevc pid --duration 2 --dt 0.1 --soc0 55 --payload 35 --grade 4 --grade-amp 2.5 --vehicle-mass 115 --wheel-radius 0.255 --gear 7 --target-vmax 45 --metrics test_v10.csv --plot test_v10.png
python main.py
```
