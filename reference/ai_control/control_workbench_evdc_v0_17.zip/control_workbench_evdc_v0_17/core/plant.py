"""The Plant contract — the "System (F)" box in the inverse-control diagram.

A Plant is any continuous dynamical system we want to control. The control
schemes are **plant-agnostic**: they only ever touch a plant through this
interface (`step`, `output`, ranges, `viz_state`). That is exactly why a DC
motor and an induction motor can be driven by the *same* indirect-inverse
controller with zero changes in the scheme — add a plant, it appears in the GUI
plant dropdown and every scheme can control it.

This module is framework-free (no tkinter / matplotlib) so the CLI and tests
reuse it. Numerical integration is RK4 with optional sub-stepping so stiff
electrical dynamics stay stable at the GUI animation timestep.
"""
from __future__ import annotations

from typing import Dict, List, Tuple

import numpy as np


class Plant:
    """Base class. Subclasses set `id/name/...`, `PARAMS`, and implement
    `deriv`, `reset_state`, `output`, `viz_state`."""

    id: str = "base"
    name: str = "Base plant"
    # signal labels, used for axis titles and the block diagram
    input_name: str = "u"
    input_unit: str = ""
    output_name: str = "y"
    output_unit: str = ""
    # default parameters (shown in Settings, overridable per session)
    PARAMS: Dict[str, float] = {}

    # number of RK4 sub-steps taken inside one `step(dt)` call
    substeps: int = 8

    def __init__(self, params: Dict[str, float] | None = None) -> None:
        self.p = {**self.PARAMS, **(params or {})}
        self.x = self.initial_state()
        self.last_u = 0.0

    # ---- to override --------------------------------------------------- #
    def initial_state(self) -> np.ndarray:
        return np.zeros(1)

    def deriv(self, x: np.ndarray, u: float) -> np.ndarray:
        raise NotImplementedError

    def output(self) -> float:
        """Measured output y (what the controller tracks)."""
        raise NotImplementedError

    def measured(self) -> np.ndarray:
        """Vector of measured signals fed to the emulator/controller. The FIRST
        entry MUST be the tracked output. Exposing the full measurable state
        (e.g. speed AND current) makes the one-step inverse well-conditioned;
        with output only it would be relative-degree-2 and near-singular."""
        return np.array([self.output()])

    def measured_scale(self) -> np.ndarray:
        """Per-entry normalisers for `measured()` (same length)."""
        ylo, yhi = self.y_range()
        return np.array([max(abs(ylo), abs(yhi)) or 1.0])

    def viz_state(self) -> Dict[str, float]:
        """Physical quantities for the circuit / 3-D / diagram visuals."""
        return {}

    def u_range(self) -> Tuple[float, float]:
        raise NotImplementedError

    def y_range(self) -> Tuple[float, float]:
        raise NotImplementedError

    # ---- generic integration ------------------------------------------ #
    def reset_state(self) -> None:
        self.x = self.initial_state()
        self.last_u = 0.0

    def clone(self) -> "Plant":
        return type(self)(dict(self.p))

    def step(self, u: float, dt: float) -> float:
        """Advance the plant by `dt` seconds under constant input u; return y."""
        lo, hi = self.u_range()
        u = float(np.clip(u, lo, hi))
        self.last_u = u
        h = dt / self.substeps
        x = self.x
        for _ in range(self.substeps):
            k1 = self.deriv(x, u)
            k2 = self.deriv(x + 0.5 * h * k1, u)
            k3 = self.deriv(x + 0.5 * h * k2, u)
            k4 = self.deriv(x + h * k3, u)
            x = x + (h / 6.0) * (k1 + 2 * k2 + 2 * k3 + k4)
        self.x = x
        return self.output()

    # ---- (de)serialise the numeric parameter set ---------------------- #
    def params_dict(self) -> Dict[str, float]:
        return dict(self.p)
