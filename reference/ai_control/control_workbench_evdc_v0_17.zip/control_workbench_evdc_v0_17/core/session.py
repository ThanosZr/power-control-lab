"""A Session bundles one experiment — a chosen plant, a reference trajectory and
every registered control scheme (each with its **own** plant instance so they do
not perturb each other) — and serialises the whole thing to JSON.

This is the single object the GUI and CLI both operate on, mirroring the TSP
workbench's Session.
"""
from __future__ import annotations

import datetime as _dt
import json
from typing import Dict, List, Optional

import numpy as np

from core.registry import (get_plant, get_scenario, scheme_classes)
from core.scheme import ControlScheme

SESSION_VERSION = 1


class Session:
    def __init__(self, plant_id: str = "dc", plant_params: Optional[dict] = None,
                 scenario_id: str = "multistep", dt: float = 0.1,
                 duration: float = 12.0, seed: int = 7,
                 scheme_params: Optional[Dict[str, dict]] = None) -> None:
        self.plant_id = plant_id
        self.plant_params = plant_params or {}
        self.scenario_id = scenario_id
        self.dt = float(dt)
        self.duration = float(duration)
        self.seed = int(seed)
        self.scheme_params: Dict[str, dict] = scheme_params or {}
        self.history: List[str] = []
        self.schemes: Dict[str, ControlScheme] = {}
        self.reference = np.zeros(2)
        self._build()

    # ------------------------------------------------------------------ #
    def _make_plant(self):
        return get_plant(self.plant_id)(self.plant_params)

    def _build(self) -> None:
        # reference is generated in [-1,1] then scaled to this plant's output range
        probe = self._make_plant()
        ylo, yhi = probe.y_range()
        span = max(abs(ylo), abs(yhi))
        # Scenario generators normally return a normalized reference in [-1, 1].
        # Newer EV scenarios may also use plant/session context, e.g. road grade
        # or SOC, to build a more realistic speed target.  Keep old scenario
        # functions backward-compatible by falling back to the 3-argument call.
        scenario_fn = get_scenario(self.scenario_id)
        try:
            norm = scenario_fn(self.duration, self.dt, self.seed,
                               plant_id=self.plant_id,
                               plant_params=dict(self.plant_params),
                               y_range=(ylo, yhi))
        except TypeError:
            norm = scenario_fn(self.duration, self.dt, self.seed)
        self.reference = np.asarray(norm, dtype=float) * span
        self.schemes = {}
        for cls in scheme_classes():
            self.schemes[cls.id] = cls(self._make_plant(), self.reference, self.dt,
                                       self.scheme_params.get(cls.id, {}))

    def rebuild(self, **kw) -> None:
        for k, v in kw.items():
            setattr(self, k, v)
        self._build()

    def log_msg(self, msg: str) -> None:
        self.history.append(msg)
        if len(self.history) > 500:
            self.history = self.history[-500:]

    def scheme_list(self) -> List[ControlScheme]:
        return list(self.schemes.values())

    # ------------------------------------------------------------------ #
    def comparison_rows(self) -> List[dict]:
        rows: List[dict] = []
        for s in self.scheme_list():
            rows.extend(s.comparison_rows())
        # gap% vs the best (lowest) tracking RMSE
        rmses = [r["rmse"] for r in rows if r.get("rmse")]
        ref = min(rmses) if rmses else None
        for r in rows:
            v = r.get("rmse")
            r["gap_pct"] = (100.0 * (v - ref) / ref) if (ref and v) else None
        return rows

    # ------------------------------------------------------------------ #
    def to_dict(self) -> dict:
        return {
            "version": SESSION_VERSION,
            "saved_at": _dt.datetime.now().isoformat(timespec="seconds"),
            "instance": {
                "plant_id": self.plant_id,
                "plant_params": self.plant_params,
                "scenario_id": self.scenario_id,
                "dt": self.dt,
                "duration": self.duration,
                "seed": self.seed,
            },
            "scheme_params": self.scheme_params,
            "results": {sid: s.result() for sid, s in self.schemes.items()},
            "history": self.history[-200:],
        }

    @classmethod
    def from_dict(cls, d: dict) -> "Session":
        inst = d.get("instance", {})
        s = cls(plant_id=inst.get("plant_id", "dc"),
                plant_params=inst.get("plant_params", {}),
                scenario_id=inst.get("scenario_id", "multistep"),
                dt=float(inst.get("dt", 0.1)),
                duration=float(inst.get("duration", 12.0)),
                seed=int(inst.get("seed", 7)),
                scheme_params=d.get("scheme_params", {}))
        s.history = list(d.get("history", []))
        for sid, res in d.get("results", {}).items():
            if sid in s.schemes:
                s.schemes[sid].load_result(res)
        return s

    def save(self, path: str) -> None:
        with open(path, "w", encoding="utf-8") as f:
            json.dump(self.to_dict(), f, indent=2)

    @classmethod
    def load(cls, path: str) -> "Session":
        with open(path, "r", encoding="utf-8") as f:
            return cls.from_dict(json.load(f))
