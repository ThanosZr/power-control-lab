"""Exporters. Each self-registers so it appears in the GUI export menu and the
CLI. Add a format = one decorated function."""
from __future__ import annotations

import csv
import json

from core.registry import register_exporter
from core.render import render_signals


@register_exporter("Signals (CSV)", "csv")
def export_signals_csv(session, path: str, scheme_id: str = "iaic") -> None:
    scheme = session.schemes.get(scheme_id) or next(iter(session.schemes.values()))
    log = scheme.log
    preferred = ["t", "r", "y", "u", "e", "e_star", "y_hat", "i_arm",
                 "current", "torque", "load_torque", "soc_pct", "v_bat",
                 "i_bat", "p_bat_W", "energy_kwh", "distance_km",
                 "km_per_kwh_live", "wh_per_km_live", "nm_per_kw_live",
                 "torque_ref", "torque_ref_raw", "torque_error", "i_ref",
                 "constraint_active", "target_vehicle_kph",
                 "u_base", "u_harm", "u_total", "bemf_harmonic",
                 "bemf_h5", "bemf_h7", "bemf_h11", "bemf_h13",
                 "u_h5", "u_h7", "u_h11", "u_h13",
                 "resid_h5", "resid_h7", "resid_h11", "resid_h13",
                 "harmonic_thd_proxy", "harmonic_thd_raw_proxy",
                 "harmonic_thd_residual_proxy", "current_thd_raw_proxy",
                 "current_thd_residual_proxy", "harmonic_cancellation_pct",
                 "i_harm_raw_rms_A", "i_harm_residual_rms_A",
                 "torque_ripple_current_raw_nm", "torque_ripple_current_residual_nm",
                 "harmonic_loss_raw_W", "harmonic_loss_residual_W",
                 "p_bat_effective_W", "km_per_kwh_effective_inst",
                 "cf_on_current_thd_residual_proxy", "cf_off_current_thd_residual_proxy",
                 "cf_on_harmonic_loss_residual_W", "cf_off_harmonic_loss_residual_W",
                 "torque_ripple", "theta_e"]
    keys = [k for k in preferred if log.get(k)]
    keys += [k for k in sorted(log.keys()) if k not in keys and log.get(k)]
    n = min(len(log[k]) for k in keys) if keys else 0
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(keys)
        for k in range(n):
            w.writerow([f"{log[c][k]:.6f}" for c in keys])


@register_exporter("Metrics table (CSV)", "csv")
def export_metrics_csv(session, path: str) -> None:
    rows = session.comparison_rows()
    cols = ["scheme", "variant", "plant", "rmse", "gap_pct", "sse",
            "overshoot_pct", "control_effort", "km_per_kwh", "wh_per_km",
            "nm_per_kw", "rms_current_a", "final_soc_pct", "soc_drop_pctpts",
            "peak_torque_nm", "mean_v_sag", "torque_rmse_nm",
            "mean_tau_ref_nm", "constraint_pct",
            "rms_harmonic_voltage_v", "mean_harmonic_thd_proxy",
            "mean_harmonic_thd_residual_proxy", "mean_current_thd_raw_proxy",
            "mean_current_thd_residual_proxy", "settled_current_thd_raw_proxy",
            "settled_current_thd_residual_proxy", "mean_harmonic_cancellation_pct",
            "rms_torque_ripple_nm", "rms_current_harmonic_torque_ripple_nm",
            "mean_harmonic_loss_raw_W", "mean_harmonic_loss_residual_W",
            "km_per_kwh_effective", "wh_per_km_effective",
            "sim_steps", "grad_updates", "ms"]
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(cols)
        for r in rows:
            w.writerow([r.get(c, "") for c in cols])


@register_exporter("Signal plot (PNG)", "png")
def export_plot_png(session, path: str, scheme_id: str = "iaic", layer_on=None) -> None:
    import matplotlib
    matplotlib.use("Agg", force=False)
    from matplotlib.figure import Figure
    scheme = session.schemes.get(scheme_id) or next(iter(session.schemes.values()))
    fig = Figure(figsize=(9, 7), dpi=130)
    render_signals(fig, scheme, layer_on=layer_on)
    fig.savefig(path, bbox_inches="tight")


@register_exporter("Session (JSON)", "json")
def export_session_json(session, path: str) -> None:
    with open(path, "w", encoding="utf-8") as f:
        json.dump(session.to_dict(), f, indent=2)
