"""Reference trajectory generators — the "instance" the schemes are compared on.

Each is registered so it appears in the GUI/CLI scenario dropdown automatically.
A generator returns the desired output r(k) sampled at `dt` over `duration`
seconds, scaled into [-1, 1] of the plant's reachable output range (the Session
rescales it to physical units for the chosen plant).
"""
from __future__ import annotations

import numpy as np

from core.registry import register_scenario


def _n(duration: float, dt: float) -> int:
    return max(2, int(round(duration / dt)) + 1)


@register_scenario("step")
def _step(duration: float, dt: float, seed: int = 0) -> np.ndarray:
    n = _n(duration, dt)
    r = np.zeros(n)
    r[n // 6:] = 0.7
    return r


@register_scenario("multistep")
def _multistep(duration: float, dt: float, seed: int = 0) -> np.ndarray:
    n = _n(duration, dt)
    r = np.zeros(n)
    levels = [0.4, 0.8, 0.2, 0.6, -0.5]
    seg = max(1, n // (len(levels) + 1))
    for i, lv in enumerate(levels):
        r[(i + 1) * seg:] = lv
    return r


@register_scenario("sine")
def _sine(duration: float, dt: float, seed: int = 0) -> np.ndarray:
    n = _n(duration, dt)
    t = np.arange(n) * dt
    f = 0.4
    return 0.65 * np.sin(2 * np.pi * f * t)


@register_scenario("staircase")
def _staircase(duration: float, dt: float, seed: int = 0) -> np.ndarray:
    n = _n(duration, dt)
    rng = np.random.default_rng(seed)
    r = np.zeros(n)
    k = 0
    while k < n:
        hold = rng.integers(int(0.6 / dt), int(1.4 / dt) + 1)
        level = float(rng.uniform(-0.8, 0.8))
        r[k:k + hold] = level
        k += hold
    return r

@register_scenario("urban")
def _urban(duration: float, dt: float, seed: int = 0) -> np.ndarray:
    """Positive EV-style speed command: launch, cruise, coast, re-accelerate.

    Values are normalised; Session scales them to the selected plant's output
    range. This avoids the reverse-speed sections of `multistep` and is better
    for km/kWh and road-load examples.
    """
    n = _n(duration, dt)
    t = np.linspace(0.0, duration, n)
    r = np.zeros(n)
    # piecewise target with smooth-ish transitions through interpolation
    knots_t = np.array([0.0, 0.12, 0.22, 0.42, 0.55, 0.70, 0.82, 1.0]) * duration
    knots_y = np.array([0.0, 0.28, 0.58, 0.58, 0.32, 0.72, 0.48, 0.62])
    r = np.interp(t, knots_t, knots_y)
    # tiny deterministic perturbation so repeated plateaus are not perfectly identical
    r += 0.015 * np.sin(2.0 * np.pi * t / max(duration / 3.0, dt))
    return np.clip(r, 0.0, 0.85)


@register_scenario("grade_adaptive")
def _grade_adaptive(duration: float, dt: float, seed: int = 0, **kw) -> np.ndarray:
    """EV-style target speed that reacts to planned road grade.

    This is still a *reference trajectory*, not a feedback controller.  It gives
    the controller a realistic mission target: launch, cruise, uphill speed
    moderation, downhill recovery, and a final cruise section.  The actual plant
    may still fail to track it if SOC, boost, load, or torque limits are severe.

    Context used when available
    ---------------------------
    plant_params["grade_pct"]      : constant route grade [%]
    plant_params["grade_amp_pct"]  : sinusoidal grade ripple [%]
    plant_params["grade_period_m"] : spatial period of grade ripple [m]
    plant_params["SOC0"]           : mild low-SOC target derating

    Output is normalized speed command in [0, 0.88].  Session scales it to the
    selected plant output range, so it appears as a normal speed target ω.
    """
    n = _n(duration, dt)
    t = np.linspace(0.0, duration, n)
    pp = dict(kw.get("plant_params") or {})

    # Base mission: smooth launch, mid cruise, second acceleration, final cruise.
    knots_t = np.array([0.0, 0.10, 0.22, 0.45, 0.58, 0.72, 0.86, 1.0]) * duration
    knots_y = np.array([0.0, 0.34, 0.66, 0.66, 0.50, 0.74, 0.58, 0.64])
    base = np.interp(t, knots_t, knots_y)

    # Approximate distance progress from the base command.  We only need a
    # route coordinate for the grade profile; the plant computes the real road
    # load separately during simulation.
    dist_proxy = np.cumsum(np.maximum(base, 0.0)) * dt * 12.0  # roughly metres
    grade0 = float(pp.get("grade_pct", 0.0))
    grade_amp = float(pp.get("grade_amp_pct", 1.5))
    grade_period = max(float(pp.get("grade_period_m", 90.0)), 1.0)
    grade = grade0 + grade_amp * np.sin(2.0 * np.pi * dist_proxy / grade_period)

    # Target policy: reduce desired speed on uphill, allow slight recovery on
    # downhill, and derate mildly at low SOC.  These are mission-level choices,
    # not hidden plant physics.
    uphill = np.maximum(grade, 0.0)
    downhill = np.maximum(-grade, 0.0)
    grade_factor = 1.0 - 0.030 * uphill + 0.010 * downhill

    soc0 = float(pp.get("SOC0", 0.85))
    low_soc_penalty = np.clip((0.45 - soc0) / 0.35, 0.0, 1.0)
    soc_factor = 1.0 - 0.12 * low_soc_penalty

    # Add a tiny deterministic driver/traffic variation so it is not a perfect
    # filtered grade curve.
    driver_variation = 0.012 * np.sin(2.0 * np.pi * t / max(duration / 4.0, dt) + 0.3)
    ref = base * grade_factor * soc_factor + driver_variation

    return np.clip(ref, 0.0, 0.88)

@register_scenario("straight_flat")
def _straight_flat(duration: float, dt: float, seed: int = 0, **kw) -> np.ndarray:
    """Straight-line constant-speed mission for harmonic/debug validation.

    This scenario is intentionally boring: it ramps to a fixed positive target
    and then holds it.  Use it with grade=0, grade_amp=0, load_amp=0 to isolate
    motor/control effects from road-grade and route disturbances.  It is the
    closest Python sanity check to the constant operating point used in the
    harmonic ON/OFF comparison.
    """
    n = _n(duration, dt)
    t = np.linspace(0.0, duration, n)
    cruise = 0.62
    ramp_time = max(0.20 * duration, dt)
    r = cruise * np.clip(t / ramp_time, 0.0, 1.0)
    return np.clip(r, 0.0, 0.85)
