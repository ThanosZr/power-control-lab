"""The plugin contract every control scheme implements.

This is the control-domain twin of the TSP workbench's `Algorithm` contract and
keeps the same ideas on purpose:

* The GUI never hard-codes a scheme. It iterates registered schemes and talks to
  them only through the `ControlScheme` interface below.
* Each scheme declares its work as a **step graph** (`Step` with `requires`) so
  the UI shows dependencies and colour-codes readiness. For indirect inverse
  control the graph *is* the method:  excite → emulator → controller → online.
* Cost is metered honestly through `CostMeter`: simulation steps, gradient
  updates, network forward passes and wall-clock are tracked separately, so
  "10000 steps" never masquerades as the real work done.

Add a scheme = subclass `ControlScheme`, declare `STEPS`, implement the bodies,
register it. Nothing in the GUI changes. See ARCHITECTURE.md.
"""
from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Dict, List, Optional

import numpy as np

from core.plant import Plant


# --------------------------------------------------------------------------- #
# Step graph (identical semantics to the TSP workbench)
# --------------------------------------------------------------------------- #
@dataclass(frozen=True)
class Step:
    id: str
    label: str
    requires: List[str] = field(default_factory=list)
    produces: List[str] = field(default_factory=list)
    description: str = ""
    rerunnable: bool = False


LOCKED = "locked"
READY = "ready"
RUNNING = "running"
DONE = "done"


# --------------------------------------------------------------------------- #
# Honest cost model for a learning controller
# --------------------------------------------------------------------------- #
@dataclass
class CostMeter:
    sim_steps: int = 0        # plant integrations performed (each = `substeps` RK4 steps)
    grad_updates: int = 0     # SGD weight updates applied (emulator + controller)
    forward_evals: int = 0    # network forward passes
    epochs: int = 0           # offline training epochs completed
    elapsed_ms: float = 0.0

    _t0: Optional[float] = field(default=None, repr=False, compare=False)

    def start(self) -> None:
        self._t0 = time.perf_counter()

    def stop(self) -> None:
        if self._t0 is not None:
            self.elapsed_ms += (time.perf_counter() - self._t0) * 1000.0
            self._t0 = None

    def reset(self) -> None:
        self.sim_steps = self.grad_updates = self.forward_evals = self.epochs = 0
        self.elapsed_ms = 0.0
        self._t0 = None

    def to_dict(self) -> dict:
        return {
            "sim_steps": self.sim_steps,
            "grad_updates": self.grad_updates,
            "forward_evals": self.forward_evals,
            "epochs": self.epochs,
            "elapsed_ms": round(self.elapsed_ms, 3),
        }

    @classmethod
    def from_dict(cls, d: dict) -> "CostMeter":
        m = cls()
        m.sim_steps = int(d.get("sim_steps", 0))
        m.grad_updates = int(d.get("grad_updates", 0))
        m.forward_evals = int(d.get("forward_evals", 0))
        m.epochs = int(d.get("epochs", 0))
        m.elapsed_ms = float(d.get("elapsed_ms", 0.0))
        return m


# --------------------------------------------------------------------------- #
# Per-tick visual snapshot (drives the live diagram / circuit / 3-D / plots)
# --------------------------------------------------------------------------- #
@dataclass
class SimFrame:
    scheme_id: str
    step_id: str
    phase: str
    message: str
    signals: Dict[str, float] = field(default_factory=dict)   # r, u, y, y_hat, e, e_star...
    viz: Dict[str, float] = field(default_factory=dict)        # plant.viz_state()
    notes: Dict[str, str] = field(default_factory=dict)


@dataclass(frozen=True)
class LayerSpec:
    id: str
    label: str
    default_on: bool = True


@dataclass
class DrawContext:
    layer_on: Dict[str, bool]
    emphasis: bool = False
    z_base: int = 1


# --------------------------------------------------------------------------- #
# ControlScheme base class
# --------------------------------------------------------------------------- #
class ControlScheme:
    """Base class. Subclasses MUST set `id`, `name`, `color`, `STEPS`."""

    id: str = "base"
    name: str = "Base scheme"
    color: str = "#1f77b4"
    STEPS: List[Step] = []

    def __init__(self, plant: Plant, reference: np.ndarray, dt: float,
                 params: Dict[str, object]) -> None:
        self.plant = plant                 # this scheme's own plant instance
        self.reference = np.asarray(reference, dtype=float)
        self.dt = float(dt)
        self.params = dict(params)
        self.cost = CostMeter()
        self._done_steps: set[str] = set()
        self.active_step_id: Optional[str] = self.STEPS[0].id if self.STEPS else None
        # recorded closed-loop signals (filled by the online step)
        self.log: Dict[str, List[float]] = {}
        self.last_signals: Dict[str, float] = {}
        # live set-point: when not None the online loop tracks this held value
        # (set interactively) instead of replaying the pre-baked reference array.
        self.setpoint: Optional[float] = None
        self.live_log_cap: int = 2000
        # when True the online loop keeps cycling the reference forever (until
        # the GUI stops it) instead of terminating at the end of the array
        self.run_continuous: bool = False

    def set_setpoint(self, value: Optional[float]) -> None:
        self.setpoint = None if value is None else float(value)

    # ---- step graph introspection (same as TSP Algorithm) -------------- #
    def steps(self) -> List[Step]:
        return list(self.STEPS)

    def _step(self, step_id: str) -> Step:
        for s in self.STEPS:
            if s.id == step_id:
                return s
        raise KeyError(step_id)

    def status(self, step_id: str) -> str:
        step = self._step(step_id)
        if step_id in self._done_steps and not step.rerunnable:
            return DONE
        if any(r not in self._done_steps for r in step.requires):
            return LOCKED
        return READY

    def is_step_done(self, step_id: str) -> bool:
        return step_id in self._done_steps

    def is_done(self) -> bool:
        return len(self.STEPS) > 0 and all(s.id in self._done_steps for s in self.STEPS)

    def next_ready_step(self) -> Optional[str]:
        for s in self.STEPS:
            if s.id in self._done_steps:
                continue
            if all(r in self._done_steps for r in s.requires):
                return s.id
        return None

    # ---- lifecycle (override the bodies, keep this scaffolding) -------- #
    def reset(self) -> SimFrame:
        self.cost.reset()
        self._done_steps.clear()
        self.active_step_id = self.STEPS[0].id if self.STEPS else None
        self.log = {}
        self.last_signals = {}
        self.plant.reset_state()
        return self._frame("reset", "reset", "Scheme reset.")

    def micro_step(self) -> Optional[SimFrame]:
        raise NotImplementedError

    def run_step(self, step_id: str) -> List[SimFrame]:
        if self.status(step_id) == LOCKED:
            return [self._frame(step_id, "blocked",
                                f"'{self._step(step_id).label}' is locked; "
                                f"run prerequisites first.")]
        if self._step(step_id).rerunnable and step_id in self._done_steps:
            self._done_steps.discard(step_id)
        self.active_step_id = step_id
        frames: List[SimFrame] = []
        guard = 0
        while not self.is_step_done(step_id) and guard < 5_000_000:
            f = self.micro_step()
            guard += 1
            if f is None:
                break
            frames.append(f)
            if f.step_id != step_id and self.is_step_done(step_id):
                break
        return frames

    def run_all(self) -> List[SimFrame]:
        frames: List[SimFrame] = []
        guard = 0
        while not self.is_done() and guard < 50:
            nxt = self.next_ready_step()
            if nxt is None:
                break
            frames.extend(self.run_step(nxt))
            guard += 1
        return frames

    # ---- results / serialisation (override) ---------------------------- #
    def result(self) -> dict:
        return {"done_steps": sorted(self._done_steps), "cost": self.cost.to_dict()}

    def load_result(self, data: dict) -> None:
        self._done_steps = set(data.get("done_steps", []))
        self.cost = CostMeter.from_dict(data.get("cost", {}))

    def comparison_rows(self) -> List[dict]:
        return []

    # ---- visuals (override) -------------------------------------------- #
    def layers(self) -> List[LayerSpec]:
        return []

    def draw_signals(self, fig, ctx: DrawContext) -> None:
        """Render this scheme's time-series onto a matplotlib Figure."""
        return None

    # ---- helpers ------------------------------------------------------- #
    def _frame(self, step_id, phase, message, **kw) -> SimFrame:
        return SimFrame(scheme_id=self.id, step_id=step_id, phase=phase,
                        message=message, **kw)

    def metrics(self) -> Dict[str, float]:
        """Tracking metrics from the recorded closed-loop log."""
        if not self.log.get("y"):
            return {}
        r = np.asarray(self.log["r"]); y = np.asarray(self.log["y"])
        u = np.asarray(self.log["u"])
        e = r - y
        rmse = float(np.sqrt(np.mean(e ** 2)))
        # steady-state error: mean |e| over the last 20% of the run
        tail = max(1, len(e) // 5)
        sse = float(np.mean(np.abs(e[-tail:])))
        peak = float(np.max(np.abs(y))) if len(y) else 0.0
        target = float(np.max(np.abs(r))) if len(r) else 0.0
        overshoot = (100.0 * (peak - target) / target) if target > 1e-6 else 0.0
        effort = float(np.sqrt(np.mean(u ** 2)))
        out = {"rmse": rmse, "sse": sse, "overshoot_pct": overshoot,
               "control_effort": effort}

        # Optional EV/energy metrics. Plants can expose these through viz_state(),
        # and schemes append them to the log. The base class computes them when
        # present, keeping old plants/schemes backward-compatible.
        log = self.log
        if log.get("energy_kwh") and log.get("distance_km"):
            energy_kwh = float(log["energy_kwh"][-1])
            distance_km = float(log["distance_km"][-1])
            if energy_kwh > 1e-9:
                out["km_per_kwh"] = distance_km / energy_kwh
            if distance_km > 1e-9:
                out["wh_per_km"] = 1000.0 * energy_kwh / distance_km
        if log.get("torque") and log.get("p_bat_W"):
            tq = np.asarray(log["torque"], dtype=float)
            pb = np.asarray(log["p_bat_W"], dtype=float) / 1000.0
            mask = pb > 1e-6
            if np.any(mask):
                out["nm_per_kw"] = float(np.mean(np.abs(tq[mask])) / max(np.mean(pb[mask]), 1e-9))
            out["mean_torque_nm"] = float(np.mean(np.abs(tq)))
            out["peak_torque_nm"] = float(np.max(np.abs(tq)))
        if log.get("current"):
            cur = np.asarray(log["current"], dtype=float)
            out["rms_current_a"] = float(np.sqrt(np.mean(cur ** 2)))
        elif log.get("i_arm"):
            cur = np.asarray(log["i_arm"], dtype=float)
            out["rms_current_a"] = float(np.sqrt(np.mean(cur ** 2)))
        if log.get("soc_pct"):
            soc0 = float(log["soc_pct"][0]); soc1 = float(log["soc_pct"][-1])
            out["final_soc_pct"] = soc1
            out["soc_drop_pctpts"] = soc0 - soc1
        if log.get("v_sag"):
            out["mean_v_sag"] = float(np.mean(np.asarray(log["v_sag"], dtype=float)))
        return out

    def _append_viz_to_log(self, viz: Dict[str, float]) -> None:
        """Append numeric plant-viz values to the scheme log. This lets new
        plant-level variables (SOC, battery power, converter duty, load torque,
        km/kWh...) show up in metrics/CSV without changing every exporter.
        Existing keys are not duplicated in a step if the caller already wrote
        them manually.
        """
        if not self.log:
            return
        target = len(self.log.get("t", []))
        if target <= 0:
            target = max((len(v) for v in self.log.values()), default=0)
        for key, val in (viz or {}).items():
            if not isinstance(val, (int, float, np.integer, np.floating)):
                continue
            arr = self.log.setdefault(key, [])
            if len(arr) < target - 1:
                arr.extend([float("nan")] * ((target - 1) - len(arr)))
            if len(arr) < target:
                arr.append(float(val))
