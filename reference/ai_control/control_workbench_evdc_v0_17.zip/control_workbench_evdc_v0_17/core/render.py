"""One drawing path for the time-series, reused by the GUI 'Signals' tab and the
PNG exporter (mirrors the TSP workbench's render.py).

The diagram / circuit / 3-D renderers live in the gui package because they are
purely presentational; this module only needs the recorded signal log, so it
stays import-light and is safe to call head-less (Agg).
"""
from __future__ import annotations

from typing import Dict, Optional

from core.scheme import ControlScheme, DrawContext


def render_signals(fig, scheme: ControlScheme,
                   layer_on: Optional[Dict[str, bool]] = None) -> None:
    layer_on = layer_on or {ls.id: ls.default_on for ls in scheme.layers()}
    ctx = DrawContext(layer_on=layer_on)
    fig.clear()
    scheme.draw_signals(fig, ctx)
