"""Tiny decorator-based registries (mirrors the TSP workbench design).

Register a plant / control scheme / reference generator / exporter once and it
appears everywhere — GUI dropdowns, CLI, export menu — with no further wiring.
"""
from __future__ import annotations

from typing import Callable, Dict, List, Type

# -------------------------------- plants ----------------------------------- #
_PLANTS: Dict[str, Type] = {}


def register_plant(cls: Type) -> Type:
    if not getattr(cls, "id", None):
        raise ValueError("Plant subclass must define a unique `id`.")
    _PLANTS[cls.id] = cls
    return cls


def plant_classes() -> List[Type]:
    return list(_PLANTS.values())


def plant_ids() -> List[str]:
    return list(_PLANTS.keys())


def get_plant(plant_id: str) -> Type:
    return _PLANTS[plant_id]


# -------------------------------- schemes ---------------------------------- #
_SCHEMES: Dict[str, Type] = {}


def register_scheme(cls: Type) -> Type:
    if not getattr(cls, "id", None):
        raise ValueError("ControlScheme subclass must define a unique `id`.")
    _SCHEMES[cls.id] = cls
    return cls


def scheme_classes() -> List[Type]:
    return list(_SCHEMES.values())


def get_scheme(scheme_id: str) -> Type:
    return _SCHEMES[scheme_id]


# ------------------------- reference generators ---------------------------- #
# name -> callable(duration, dt, seed, **kw) -> np.ndarray
_SCENARIOS: Dict[str, Callable] = {}


def register_scenario(name: str) -> Callable:
    def deco(fn: Callable) -> Callable:
        _SCENARIOS[name] = fn
        return fn
    return deco


def scenario_names() -> List[str]:
    return list(_SCENARIOS.keys())


def get_scenario(name: str) -> Callable:
    return _SCENARIOS[name]


# -------------------------------- exporters -------------------------------- #
_EXPORTERS: Dict[str, dict] = {}


def register_exporter(label: str, ext: str) -> Callable:
    def deco(fn: Callable) -> Callable:
        _EXPORTERS[label] = {"fn": fn, "ext": ext}
        return fn
    return deco


def exporters() -> Dict[str, dict]:
    return dict(_EXPORTERS)
