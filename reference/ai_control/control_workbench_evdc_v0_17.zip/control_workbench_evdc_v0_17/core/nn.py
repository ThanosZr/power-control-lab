"""A tiny dependency-free MLP (numpy only).

It is deliberately small and transparent because it is used for **two** roles in
the indirect-learning scheme and the difference between them is the whole point
of that architecture:

* the **emulator** (ANN 2) learns the forward dynamics  y(k+1) ≈ f(regressor),
* the **controller** (ANN 1) learns the inverse  u(k) ≈ f⁻¹(regressor).

The controller cannot be trained directly (there is no target u), so its error
signal is the *output* error e = r − y back-propagated **through the emulator**.
That requires the gradient of the emulator output w.r.t. its input — the
`input_grad` method below. Everything here is hand-written so that path is
explicit and inspectable, not hidden inside a framework.

Architecture: fully-connected, tanh hidden layers, linear output. SGD per
sample (matching the on-line, one-sample-per-time-step nature of the scheme).
"""
from __future__ import annotations

from typing import Dict, List, Optional

import numpy as np


class MLP:
    def __init__(self, sizes: List[int], lr: float = 0.02, seed: int = 0) -> None:
        if len(sizes) < 2:
            raise ValueError("MLP needs at least an input and an output layer.")
        self.sizes = list(sizes)
        self.lr = float(lr)
        rng = np.random.default_rng(seed)
        self.W: List[np.ndarray] = []
        self.b: List[np.ndarray] = []
        for i in range(len(sizes) - 1):
            scale = np.sqrt(1.0 / sizes[i])          # Xavier-ish
            self.W.append(rng.normal(0.0, scale, (sizes[i], sizes[i + 1])))
            self.b.append(np.zeros(sizes[i + 1]))

    # ------------------------------------------------------------------ #
    # forward / backward (single sample, x is a 1-D vector)
    # ------------------------------------------------------------------ #
    def forward(self, x: np.ndarray, cache: Optional[dict] = None) -> np.ndarray:
        a = np.asarray(x, dtype=float)
        acts = [a]
        zs: List[np.ndarray] = []
        L = len(self.W)
        for i in range(L):
            z = a @ self.W[i] + self.b[i]
            zs.append(z)
            a = np.tanh(z) if i < L - 1 else z      # linear output layer
            acts.append(a)
        if cache is not None:
            cache["acts"] = acts
            cache["zs"] = zs
        return a

    def backward(self, cache: dict, dout: np.ndarray):
        """Given dL/d(output), return (gW, gb, dL/dinput).

        Does NOT mutate weights — call `apply` to take the SGD step. Returning
        the input gradient is what lets the controller be trained through the
        emulator.
        """
        acts, zs = cache["acts"], cache["zs"]
        L = len(self.W)
        gW: List[Optional[np.ndarray]] = [None] * L
        gb: List[Optional[np.ndarray]] = [None] * L
        delta = np.atleast_1d(np.asarray(dout, dtype=float))   # dL/dz of output (linear)
        dinput = None
        for i in reversed(range(L)):
            gW[i] = np.outer(acts[i], delta)
            gb[i] = delta
            da_prev = self.W[i] @ delta                        # dL/d(acts[i])
            if i > 0:
                delta = da_prev * (1.0 - np.tanh(zs[i - 1]) ** 2)
            else:
                dinput = da_prev                               # dL/dx
        return gW, gb, dinput

    def apply(self, gW, gb, lr: Optional[float] = None, clip: float = 5.0) -> None:
        lr = self.lr if lr is None else lr
        for i in range(len(self.W)):
            gw = np.clip(gW[i], -clip, clip)
            gb_ = np.clip(gb[i], -clip, clip)
            self.W[i] -= lr * gw
            self.b[i] -= lr * gb_

    # ------------------------------------------------------------------ #
    # convenience
    # ------------------------------------------------------------------ #
    def predict(self, x: np.ndarray) -> float:
        out = self.forward(x)
        return float(out[0]) if out.shape[0] == 1 else out

    def input_grad(self, x: np.ndarray, out_index: int = 0) -> np.ndarray:
        """d(output[out_index]) / d(input) — the emulator Jacobian row used to
        push the tracking error back onto the controller."""
        cache: dict = {}
        out = self.forward(x, cache)
        seed = np.zeros_like(out)
        seed[out_index] = 1.0
        _, _, dinput = self.backward(cache, seed)
        return dinput

    def train_sample(self, x: np.ndarray, target: np.ndarray,
                     lr: Optional[float] = None) -> float:
        """One SGD step on 0.5*(pred-target)^2. Returns squared error."""
        cache: dict = {}
        pred = self.forward(x, cache)
        target = np.atleast_1d(np.asarray(target, dtype=float))
        err = pred - target
        gW, gb, _ = self.backward(cache, err)        # dL/dpred = (pred-target)
        self.apply(gW, gb, lr=lr)
        return float(err @ err)

    # ------------------------------------------------------------------ #
    # serialisation (lists, so the Session JSON stays human-readable)
    # ------------------------------------------------------------------ #
    def to_dict(self) -> dict:
        return {
            "sizes": self.sizes,
            "lr": self.lr,
            "W": [w.tolist() for w in self.W],
            "b": [bb.tolist() for bb in self.b],
        }

    @classmethod
    def from_dict(cls, d: dict) -> "MLP":
        m = cls(d["sizes"], lr=d.get("lr", 0.02))
        m.W = [np.array(w, dtype=float) for w in d["W"]]
        m.b = [np.array(bb, dtype=float) for bb in d["b"]]
        return m
