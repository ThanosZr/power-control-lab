# Patch Notes v0.4 — EV/DC Control Variables in GUI

## Why this patch exists

In v0.3 the GUI could only change the live speed target `ω` during online run mode. That was useful for tracking tests, but it did not expose the EV-level variables that matter for the new project direction: battery state, converter envelope, road/load conditions and energy metrics.

v0.4 adds a visible EV/DC plant control panel so the experiment is no longer only “change target speed”. You can now change the operating condition of the battery + converter + DC motor + load model and compare how the same controller behaves under different constraints.

## New GUI section

A new panel appears under **Scheme control**:

**EV/DC plant variables — applied on Rebuild**

It exposes:

| GUI variable | Plant parameter | Meaning |
|---|---:|---|
| SOC0 % | `SOC0` | Initial battery state of charge |
| payload kg | `payload_mass` | Extra vehicle/load mass |
| grade % | `grade_pct` | Constant road slope |
| grade ripple % | `grade_amp_pct` | Sinusoidal road-grade disturbance |
| capacity Ah | `capacity_Ah` | Battery capacity |
| load base Nm | `T_load_base` | Constant additional motor load torque |
| load amp Nm | `T_load_amp` | Variable additional motor load torque amplitude |
| boost max | `boost_ratio_max` | Simplified DC/DC boost envelope |
| Vout max V | `Vout_abs_max` | Absolute converter output voltage limit |

Press **Apply/Rebuild** or the top **Rebuild** button after changing these values.

## Important distinction

The live slider still changes:

```text
online target ω [rad/s]
```

The new EV/DC controls change the physical operating condition:

```text
battery SOC, payload, road grade, converter voltage envelope, variable load
```

So the intended workflow is:

1. Set EV/DC variables.
2. Press Rebuild.
3. Train or run controller.
4. Compare `km/kWh`, `Wh/km`, `Nm/kW`, RMS current and tracking error.

## CLI additions

The headless runner also supports EV/DC overrides:

```bat
python cli.py run --plant evdc --scenario urban --schemes pid --duration 8 --dt 0.1 ^
  --soc0 60 --payload 40 --grade 3 --load-amp 0.8 --boost 1.6 --vout-max 90 ^
  --metrics ev_metrics.csv --plot ev_plot.png
```

Supported CLI flags:

```text
--soc0       initial SOC in percent
--payload    extra payload mass [kg]
--grade      constant road grade [%]
--grade-amp  sinusoidal grade amplitude [%]
--load-base  base motor load torque [Nm]
--load-amp   variable load torque amplitude [Nm]
--boost      max boost ratio envelope
--vout-max   max converter output voltage [V]
--capacity   battery capacity [Ah]
```

## What this improves

v0.4 is a better bridge toward MATLAB/Simulink because it separates:

- control target: speed reference `ω`,
- plant constraints: battery/converter/load state,
- evaluation metrics: `km/kWh`, `Wh/km`, `Nm/kW`, SOC drop, RMS current.

This makes the workbench suitable for early multi-objective experiments before moving the same architecture to more detailed MATLAB/Simulink motor-drive models.
