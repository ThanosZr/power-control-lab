"""Headless runner — same core as the GUI, so every registered plant / scheme /
exporter works without a display.

Examples
--------
  python cli.py run --plant dc --scenario multistep --schemes iaic pid \
      --plot out.png --metrics m.csv --save s.json

  python cli.py run --plant evdc --scenario urban --schemes pid \
      --soc0 60 --payload 40 --grade 3 --load-amp 0.8 \
      --metrics ev_metrics.csv --plot ev_plot.png

  python cli.py run --plant evdc --scenario grade_adaptive --schemes pid \
      --soc0 55 --payload 35 --grade 4 --grade-amp 2.5 \
      --vehicle-mass 115 --wheel-radius 0.255 --gear 7 --target-vmax 45 \
      --metrics grade_metrics.csv --plot grade_plot.png

  python cli.py benchmark --plant dc --scenario staircase --seeds 0-5
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

import bootstrap  # noqa: F401
from core.export import export_plot_png
from core.registry import exporters, plant_ids, scheme_classes, scenario_names
from core.session import Session


def _ev_plant_params(args) -> dict:
    """Optional EV/DC plant overrides from CLI flags."""
    out = {}
    if getattr(args, "soc0", None) is not None:
        out["SOC0"] = float(args.soc0) / 100.0
    if getattr(args, "payload", None) is not None:
        out["payload_mass"] = float(args.payload)
    if getattr(args, "grade", None) is not None:
        out["grade_pct"] = float(args.grade)
    if getattr(args, "grade_amp", None) is not None:
        out["grade_amp_pct"] = float(args.grade_amp)
    if getattr(args, "load_base", None) is not None:
        out["T_load_base"] = float(args.load_base)
    if getattr(args, "load_amp", None) is not None:
        out["T_load_amp"] = float(args.load_amp)
    if getattr(args, "boost", None) is not None:
        out["boost_ratio_max"] = float(args.boost)
    if getattr(args, "vout_max", None) is not None:
        out["Vout_abs_max"] = float(args.vout_max)
    if getattr(args, "capacity", None) is not None:
        out["capacity_Ah"] = float(args.capacity)
    if getattr(args, "vehicle_mass", None) is not None:
        out["vehicle_mass"] = float(args.vehicle_mass)
    if getattr(args, "wheel_radius", None) is not None:
        out["wheel_radius"] = float(args.wheel_radius)
    if getattr(args, "gear", None) is not None:
        out["gear_ratio"] = float(args.gear)
    if getattr(args, "eta", None) is not None:
        out["drivetrain_eta"] = float(args.eta)
    if getattr(args, "crr", None) is not None:
        out["Crr"] = float(args.crr)
    if getattr(args, "cda", None) is not None:
        out["CdA"] = float(args.cda)
    if getattr(args, "target_vmax", None) is not None:
        out["target_vmax_kph"] = float(args.target_vmax)
    if getattr(args, "grade_period", None) is not None:
        out["grade_period_m"] = float(args.grade_period)
    if getattr(args, "load_period", None) is not None:
        out["load_period_m"] = float(args.load_period)
    return out


def _scheme_params(args) -> dict:
    out = {}
    hp = {}
    if getattr(args, "harmonic_off", False):
        hp["harmonic_enabled"] = False
    if getattr(args, "harmonic_gain", None) is not None:
        hp["harmonic_gain"] = float(args.harmonic_gain)
    if getattr(args, "harmonic_limit", None) is not None:
        hp["harmonic_limit_v"] = float(args.harmonic_limit)
    if hp:
        out["hinj"] = hp
    return out


def _run(args) -> None:
    sess = Session(plant_id=args.plant,
                   plant_params=_ev_plant_params(args),
                   scenario_id=args.scenario,
                   dt=args.dt,
                   duration=args.duration,
                   seed=args.seed,
                   scheme_params=_scheme_params(args))
    chosen = args.schemes or [c.id for c in scheme_classes()]
    for sid in chosen:
        scheme = sess.schemes[sid]
        scheme.run_all()
        m = scheme.metrics()
        extra = ""
        if "km_per_kwh" in m:
            extra = (f"  km/kWh={m.get('km_per_kwh', float('nan')):.3f}"
                     f"  Nm/kW={m.get('nm_per_kw', float('nan')):.3f}"
                     f"  SOC={m.get('final_soc_pct', float('nan')):.2f}%")
        print(f"[{sid:5}] {scheme.name:28} "
              f"RMSE={m.get('rmse', float('nan')):.4f}  "
              f"sse={m.get('sse', float('nan')):.4f}  "
              f"overshoot={m.get('overshoot_pct', 0):.1f}%"
              f"{extra}  "
              f"grad_updates={scheme.cost.grad_updates}  "
              f"{scheme.cost.elapsed_ms:.0f} ms")
    if args.plot:
        export_plot_png(sess, args.plot, scheme_id=chosen[0])
        print("plot ->", args.plot)
    if args.metrics:
        exporters()["Metrics table (CSV)"]["fn"](sess, args.metrics)
        print("metrics ->", args.metrics)
    if args.save:
        sess.save(args.save)
        print("session ->", args.save)


def _benchmark(args) -> None:
    lo, hi = (args.seeds.split("-") + [args.seeds])[:2]
    seeds = range(int(lo), int(hi) + 1)
    rmses = []
    for s in seeds:
        sess = Session(plant_id=args.plant, scenario_id=args.scenario,
                       dt=args.dt, duration=args.duration, seed=s)
        sc = sess.schemes[args.scheme]
        sc.run_all()
        m = sc.metrics()
        rmses.append(m.get("rmse", float("nan")))
        print(f"seed {s:3}: RMSE={m.get('rmse', float('nan')):.4f}")
    import statistics
    print(f"\n{args.scheme} on {args.plant}/{args.scenario}: "
          f"mean RMSE={statistics.mean(rmses):.4f} "
          f"(±{statistics.pstdev(rmses):.4f}) over {len(rmses)} seeds")


def main() -> None:
    ap = argparse.ArgumentParser(description="Adaptive Inverse Control Workbench (headless)")
    sub = ap.add_subparsers(dest="cmd", required=True)

    r = sub.add_parser("run")
    r.add_argument("--plant", default="dc", choices=plant_ids())
    r.add_argument("--scenario", default="multistep", choices=scenario_names())
    r.add_argument("--schemes", nargs="*", default=None)
    r.add_argument("--dt", type=float, default=0.1)
    r.add_argument("--duration", type=float, default=12.0)
    r.add_argument("--seed", type=int, default=7)
    r.add_argument("--soc0", type=float, default=None, help="Initial SOC in percent for evdc")
    r.add_argument("--payload", type=float, default=None, help="Extra payload mass [kg] for evdc")
    r.add_argument("--grade", type=float, default=None, help="Constant road grade [%] for evdc")
    r.add_argument("--grade-amp", dest="grade_amp", type=float, default=None, help="Sinusoidal grade amplitude [%] for evdc")
    r.add_argument("--load-base", dest="load_base", type=float, default=None, help="Base motor load torque [Nm] for evdc")
    r.add_argument("--load-amp", dest="load_amp", type=float, default=None, help="Variable load torque amplitude [Nm] for evdc")
    r.add_argument("--boost", type=float, default=None, help="Max boost ratio envelope for evdc")
    r.add_argument("--vout-max", dest="vout_max", type=float, default=None, help="Max converter output voltage [V] for evdc")
    r.add_argument("--capacity", type=float, default=None, help="Battery capacity [Ah] for evdc")
    r.add_argument("--vehicle-mass", dest="vehicle_mass", type=float, default=None, help="Vehicle + driver mass [kg] for evdc")
    r.add_argument("--wheel-radius", dest="wheel_radius", type=float, default=None, help="Wheel radius [m] for evdc")
    r.add_argument("--gear", type=float, default=None, help="Motor speed / wheel speed gear ratio for evdc")
    r.add_argument("--eta", type=float, default=None, help="Drivetrain efficiency for evdc")
    r.add_argument("--crr", type=float, default=None, help="Rolling resistance coefficient for evdc")
    r.add_argument("--cda", type=float, default=None, help="Aerodynamic drag area CdA [m^2] for evdc")
    r.add_argument("--target-vmax", dest="target_vmax", type=float, default=None, help="Max reference vehicle speed [km/h] for evdc")
    r.add_argument("--grade-period", dest="grade_period", type=float, default=None, help="Grade spatial period [m] for evdc")
    r.add_argument("--load-period", dest="load_period", type=float, default=None, help="Variable-load spatial period [m] for evdc")
    r.add_argument("--harmonic-off", action="store_true", help="Disable harmonic injection for hinj scheme")
    r.add_argument("--harmonic-gain", dest="harmonic_gain", type=float, default=None, help="Harmonic injection gain for hinj")
    r.add_argument("--harmonic-limit", dest="harmonic_limit", type=float, default=None, help="Harmonic injection voltage limit [V] for hinj")
    r.add_argument("--plot")
    r.add_argument("--metrics")
    r.add_argument("--save")
    r.set_defaults(func=_run)

    b = sub.add_parser("benchmark")
    b.add_argument("--plant", default="dc", choices=plant_ids())
    b.add_argument("--scenario", default="staircase", choices=scenario_names())
    b.add_argument("--scheme", default="iaic")
    b.add_argument("--dt", type=float, default=0.1)
    b.add_argument("--duration", type=float, default=12.0)
    b.add_argument("--seeds", default="0-5")
    b.set_defaults(func=_benchmark)

    args = ap.parse_args()
    args.func(args)


if __name__ == "__main__":
    main()
