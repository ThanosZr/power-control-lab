# Coupled Multi-Objective EV/DC Control Plan

This note explains how the speed, torque/current and energy objectives should be
connected.  The point is to avoid treating `omega`, torque and km/kWh as isolated
plots.  In an electric drive they are coupled through vehicle dynamics and
battery power.

## 1. Key physical coupling

For the EV/DC plant:

```text
vehicle speed:      v = omega_motor * wheel_radius / gear_ratio
motor torque:       tau_motor = Kt * i_arm
battery power:      P_bat ~= V_bat * I_bat
mechanical power:   P_mech = tau_motor * omega_motor
```

The important relationship is not simply “torque equals omega”.  More correctly:

```text
torque is the effort required to achieve a target omega trajectory under road load.
```

A useful control-level equation is:

```text
tau_required = J_equiv * alpha_ref + B * omega + tau_load
```

where:

```text
alpha_ref  = desired angular acceleration [rad/s^2]
J_equiv    = motor inertia + vehicle mass reflected through wheel/gear
B*omega    = viscous/friction component
tau_load   = rolling + aero + grade + variable external load reflected to motor shaft
```

For the vehicle side:

```text
F_load = F_roll + F_drag + F_grade
F_roll = m*g*Crr
F_drag = 0.5*rho*CdA*v*|v|
F_grade = m*g*sin(atan(grade))
tau_load_motor = (F_load * wheel_radius) / (gear_ratio * drivetrain_eta) + tau_extra
```

So a speed target implies an acceleration target, which implies a torque target,
which implies a current target, which implies battery power and SOC drop.

## 2. Coupled loop architecture in v0.8

The new scheme is:

```text
scheme id: moevc
name: Coupled multi-loop EV control
```

Architecture:

```text
mission speed target omega_cmd
        |
        v
reference governor / feasibility check
        |
        v
omega_governed
        |
        v
speed loop -> alpha_ref
        |
        v
vehicle-dynamics coupler
        |
        v
tau_request = J_eq*alpha_ref + B*omega + tau_load
        |
        v
multi-objective torque/power/SOC allocator
        |
        v
tau_ref limited / softened
        |
        v
torque-current loop: i_ref = tau_ref / Kt
        |
        v
voltage command to battery + boost + DC motor plant
```

This is now a coupled multi-loop structure:

- loop 1: speed/reference loop
- loop 2: torque/current loop
- loop 3: SOC/power/energy supervisor

The speed loop does not directly produce voltage.  It produces a physically
meaningful torque demand through the vehicle dynamics.

## 3. Why a reference governor is needed

If the target speed asks for an acceleration that is impossible at the current
SOC, voltage, power limit or grade, the controller should not blindly chase it.
That creates current spikes and bad km/kWh.

The reference governor estimates feasible acceleration from available torque:

```text
alpha_pos = (tau_available_pos - tau_load - B*omega) / J_eq
alpha_neg = (tau_available_neg - tau_load - B*omega) / J_eq
```

Then it builds a feasible internal speed target:

```text
omega_governed ≈ omega + feasible_delta_omega
```

This means the GUI can still show the driver/mission target, but the controller
also shows the feasible governed target.

## 4. Multi-objective allocation

The torque request is not accepted blindly.  It is softened or clipped based on:

- speed tracking priority
- torque/performance priority
- energy efficiency priority
- SOC derating
- power limit
- current limit

Conceptually:

```text
tau_ref = allocator(tau_request, SOC, P_limit, I_limit, weights)
```

The trade-off is explicit:

```text
Performance mode: preserve more torque, worse energy use
Eco mode: preserve less torque, better current/power discipline
Balanced mode: compromise
```

The GUI/CSV logs include:

```text
r_cmd                   mission speed target
r_governed              feasible speed target after governor
alpha_cmd               desired angular acceleration
tau_road_ff             road-load torque feed-forward
tau_accel               acceleration torque component
torque_ref_raw          requested torque before allocation
torque_ref              allocated/limited torque command
i_ref                   current target from torque target
constraint_active       whether limits were active
allocation_keep         how much of raw torque request was preserved
p_pred_kw               estimated mechanical power request
```

## 5. How this becomes ANN-based later

The deterministic v0.8 controller is the scaffold.  The next AI version should
replace or augment each block with emulator + inverse ANN pairs.

### Module A: speed / vehicle dynamics

Forward emulator:

```text
E_speed: [omega, SOC, grade, load, tau_ref] -> omega_next
```

Inverse controller:

```text
C_speed: [omega_target, omega, SOC, grade, load] -> tau_ref_candidate
```

### Module B: torque / current / motor voltage

Forward emulator:

```text
E_torque: [i_arm, omega, Vcmd, SOC] -> [torque_next, current_next]
```

Inverse controller:

```text
C_torque: [tau_ref, torque, i_arm, omega, SOC] -> Vcmd
```

### Module C: battery / energy supervisor

Forward emulator:

```text
E_energy: [SOC, omega, tau_ref, grade, payload, mode] -> [Wh/km, Nm/kW, V_sag, SOC_drop]
```

Inverse / supervisor:

```text
C_energy: [desired trade-off, SOC, route, target] -> [speed_weight, torque_weight, energy_weight, limits]
```

The final research framing is not “one ANN learned control”.  It is:

```text
paired emulator-inverse ANN modules coordinated by a multi-objective supervisor.
```

## 6. Suggested loss functions for training

Each module can have its own training target.

Speed inverse objective:

```text
J_speed = w_e * (omega_ref - omega)^2 + w_tau * tau_ref^2
```

Torque/current inverse objective:

```text
J_torque = w_tau * (tau_ref - tau)^2 + w_i * i_rms^2 + w_u * Vcmd^2
```

Energy supervisor objective:

```text
J_energy = w_track*tracking_error + w_E*Wh_per_km - w_Nm*Nm_per_kW + w_sag*V_sag + w_SOC*SOC_drop
```

This is where the multi-objective contribution becomes clear: increasing torque
or tracking aggressiveness can reduce km/kWh, so the supervisor must choose the
trade-off rather than optimize only one metric.
