# Patch notes v0.2

- Repacked the project with a clearer top-level folder name: `control_workbench_evdc_v0_2`.
- Added `diagnose.py` to verify local imports and the presence of `plants/ev_dc_drive.py`.
- Added robust local-project path insertion in `main.py` and `cli.py`.
- Removed `__pycache__` folders from the distribution archive.

The EV/DC plant module is located at:

```text
plants/ev_dc_drive.py
```

Run a non-GUI smoke test first:

```bash
python diagnose.py
python cli.py run --plant evdc --scenario urban --schemes pid --duration 2 --dt 0.1 --metrics ev_metrics.csv --plot ev_plot.png
```
