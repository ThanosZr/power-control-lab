# Patch notes v0.16 — harmonic injection sanity fix

v0.16 fixes the misleading live behaviour observed in v0.15, where switching harmonic injection ON/OFF could appear to improve cumulative km/kWh every time the toggle was changed.

## What was wrong

The previous live comparison stored cumulative `km/kWh` snapshots. Cumulative distance/energy depends heavily on when the snapshot was taken during the acceleration transient, so later samples could look better even if harmonic injection had not improved the state.

Also, the harmonic model displayed THD-like values but did not expose the more important reference-style quantities:

- per-order residual harmonic current proxy,
- harmonic-current torque-ripple proxy,
- harmonic copper-loss proxy,
- same-state ON/OFF comparison.

## What changed

### 1. Same-state ON/OFF comparison

The GUI now computes an A/B estimate at the exact same plant state:

```text
same-state A/B:
  ON  Ithd, harmonic loss, km/kWh*
  OFF Ithd, harmonic loss, km/kWh*
```

This is the value to trust for live comparison. It does not use the cumulative mission `km/kWh`.

### 2. Instantaneous/effective km/kWh

The plant now exposes:

```text
km_per_kwh_inst
wh_per_km_inst
km_per_kwh_effective_inst
```

where the effective values include the harmonic-loss proxy. These are useful for live comparisons. The old cumulative `km_per_kwh_live` remains available for mission-level energy tracking.

### 3. Harmonic-current proxy

For each harmonic order, the controller estimates the induced harmonic current using:

```text
Ih ≈ Eh_residual / |Rs + j h ωe Lq|
```

Then it computes:

```text
current_thd_proxy ≈ sqrt(sum(Ih²)) / |Iq|
```

This is still not real FFT THD, but it is more meaningful than comparing signed instantaneous voltage samples.

### 4. Harmonic torque-ripple proxy

A current-harmonic torque-ripple proxy is exposed:

```text
T_ripple_h ≈ Kt * sqrt(sum(Ih²))
```

This is separate from cogging/load torque ripple.

### 5. Harmonic copper-loss proxy

The controller now computes:

```text
P_harm_loss ≈ scale * Rs * sum(Ih²)
```

This lets the GUI show why cancelling current harmonics can improve efficiency in principle, without pretending that the simplified Python model is a full three-phase detailed machine modelling/SVPWM simulation.

## How to test

Use a clean straight-line test first:

```bat
python cli.py run --plant spmsm_harm --scenario straight_flat --schemes hinj --duration 8 --dt 0.02 --soc0 70 --grade 0 --grade-amp 0 --load-amp 0 --vehicle-mass 115 --wheel-radius 0.255 --gear 7 --target-vmax 45 --harmonic-gain 1.0 --metrics v16_on.csv --plot v16_on.png
```

Then OFF:

```bat
python cli.py run --plant spmsm_harm --scenario straight_flat --schemes hinj --duration 8 --dt 0.02 --soc0 70 --grade 0 --grade-amp 0 --load-amp 0 --vehicle-mass 115 --wheel-radius 0.255 --gear 7 --target-vmax 45 --harmonic-off --metrics v16_off.csv --plot v16_off.png
```

Compare primarily:

```text
settled_current_thd_residual_proxy
mean_harmonic_loss_residual_W
rms_current_harmonic_torque_ripple_nm
```

Do not use cumulative `km/kWh` from two separate transient runs as proof that harmonic compensation works.

## Honest limitation

This is still a Python concept model. It is not equivalent to the reference a detailed three-phase model. The correct MATLAB/Simulink next step should include abc phase currents and FFT-based THDi.
