function chars = waveform_characteristics(t, i)
% Compute IEC-style front and tail times for either impulse polarity.
% Ipeak retains its sign. Threshold times use the dominant-peak polarity.

    chars = struct('Ipeak', NaN, 't_peak', NaN, 'T1', NaN, 'T2', NaN, ...
                   't10', NaN, 't90', NaN, 't50', NaN, 't_virtual_origin', NaN);

    if numel(i) < 2 || numel(t) ~= numel(i) || ~isreal(i) || ~isreal(t)
        return;
    end
    t = t(:);
    i = i(:);
    if any(~isfinite(t)) || any(~isfinite(i)) || any(diff(t) <= 0)
        return;
    end

    [peakMagnitude, idx_peak] = max(abs(i));
    if peakMagnitude <= 0, return; end

    chars.Ipeak = i(idx_peak);
    chars.t_peak = t(idx_peak);
    % Orient toward the dominant peak only for timing calculations.
    % Returned peaks and plotted/stored waveforms keep their original sign.
    i = sign(chars.Ipeak) * i;

    i10 = 0.1 * peakMagnitude;
    i90 = 0.9 * peakMagnitude;
    i50 = 0.5 * peakMagnitude;

    idx10 = find(i >= i10, 1, 'first');
    idx90 = find(i >= i90, 1, 'first');
    if isempty(idx10) || isempty(idx90) || idx90 <= idx10
        return;
    end

    chars.t10 = interp_crossing(t, i, i10, idx10);
    chars.t90 = interp_crossing(t, i, i90, idx90);

    chars.T1 = 1.25 * (chars.t90 - chars.t10);
    chars.t_virtual_origin = chars.t10 - 0.125 * (chars.t90 - chars.t10);

    idx50_after_peak = find(i(idx_peak:end) <= i50, 1, 'first');
    if isempty(idx50_after_peak)
        return;
    end
    idx50_after_peak = idx50_after_peak + idx_peak - 1;
    chars.t50 = interp_crossing_desc(t, i, i50, idx50_after_peak);
    chars.T2 = chars.t50 - chars.t_virtual_origin;
end

function tc = interp_crossing(t, y, level, idx)
    if idx <= 1
        tc = t(idx);
        return;
    end
    x1 = t(idx-1); x2 = t(idx);
    y1 = y(idx-1); y2 = y(idx);
    if y2 == y1
        tc = x2;
    else
        tc = x1 + (level-y1)*(x2-x1)/(y2-y1);
    end
end

function tc = interp_crossing_desc(t, y, level, idx)
    if idx <= 1
        tc = t(idx);
        return;
    end
    x1 = t(idx-1); x2 = t(idx);
    y1 = y(idx-1); y2 = y(idx);
    if y2 == y1
        tc = x2;
    else
        tc = x1 + (level-y1)*(x2-x1)/(y2-y1);
    end
end
