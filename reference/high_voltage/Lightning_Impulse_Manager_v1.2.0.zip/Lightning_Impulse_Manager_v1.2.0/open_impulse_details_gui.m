function open_impulse_details_gui(row)
% Open a details window for one impulse row.

    fig = uifigure('Name', 'Impulse Details', 'Position', [220 120 1100 720]);

    g = uigridlayout(fig, [2 2]);
    g.RowHeight = {'1x', 90};
    g.ColumnWidth = {'2.1x', '1x'};

    ax = uiaxes(g);
    ax.Layout.Row = 1;
    ax.Layout.Column = 1;
    title(ax, 'Lightning Current Waveform');
    xlabel(ax, 't (\mus)');
    ylabel(ax, 'I (kA)');
    grid(ax, 'on');

    side = uipanel(g, 'Title', 'Parameters and Errors');
    side.Layout.Row = 1;
    side.Layout.Column = 2;

    sideGrid = uigridlayout(side, [1 1]);
    tg = uitextarea(sideGrid, 'Editable', 'off');

    controls = uigridlayout(g, [2 4]);
    controls.Layout.Row = 2;
    controls.Layout.Column = [1 2];
    controls.RowHeight = {28, 32};
    controls.ColumnWidth = {'1x', '1x', '1x', '1x'};

    cbInit = uicheckbox(controls, 'Text', 'Show initial waveform', 'Value', true);
    cbOpt  = uicheckbox(controls, 'Text', 'Show optimized waveform', 'Value', true);
    ddLegend = uidropdown(controls, 'Items', {'show','hide'}, 'Value', 'show');
    btnRefresh = uibutton(controls, 'push', 'Text', 'Refresh Plot');
    btnRefresh.ButtonPushedFcn = @(~,~) refreshPlot();

    btnVerify = uibutton(controls, 'push', 'Text', 'Import EMTP CSV / Verify', ...
        'FontWeight', 'bold', 'BackgroundColor', [0.15 0.40 0.68], ...
        'FontColor', [1 1 1], 'Tag', 'ImportEMTPCSV', ...
        'ButtonPushedFcn', @(~,~)openVerification());
    btnVerify.Layout.Row = 2;
    btnVerify.Layout.Column = [1 2];
    hint = uilabel(controls, 'Text', 'CSV: column 1 = time [s]; choose the current column.');
    hint.Layout.Row = 2;
    hint.Layout.Column = [3 4];

    refreshPlot();

    function openVerification()
        try
            verify_emtp_gui(row);
        catch ME
            uialert(fig, ME.message, 'EMTP Verification Error');
        end
    end

    function refreshPlot()
        cla(ax);
        hold(ax, 'on');

        T1 = getField('T1_target_us', 1);
        T2 = getField('T2_target_us', 200);
        Im = getField('Im_A', 100e3);

        H_input = getField('H_input', getField('H', 0.93));
        H_used  = getField('H_used', H_input);
        H_mode  = toText(getField('H_mode', 'FixedH'));

        n = getField('n', 10);
        tau1g = getField('tau1_guess_us', 5);
        tau2g = getField('tau2_guess_us', 200);
        tau1o = getField('tau1_opt_us', tau1g);
        tau2o = getField('tau2_opt_us', tau2g);

        tend = max(500e-6, 1.5*T2*1e-6);
        t = 0:1e-9:tend;

        if strcmpi(H_mode, 'AutoH')
            Hg = local_compute_auto_H(tau1g, tau2g, n, t);
        else
            Hg = H_input;
        end

        if cbInit.Value
            ig = lightning_current(Im, Hg, tau1g, tau2g, n, t);
            plot(ax, t*1e6, ig/1e3, 'LineWidth', 1.2, 'DisplayName', 'Initial');
        end

        if cbOpt.Value
            io = lightning_current(Im, H_used, tau1o, tau2o, n, t);
            plot(ax, t*1e6, io/1e3, 'LineWidth', 1.5, 'DisplayName', 'Optimized');
        end

        if strcmp(ddLegend.Value, 'show')
            legend(ax, 'show', 'Location', 'best');
        else
            legend(ax, 'off');
        end

        hold(ax, 'off');

        tg.Value = {
            sprintf('Name: %s', toText(getField('name', '-')))
            ' '
            sprintf('Target T1/T2: %.6g / %.6g us', ...
                getField('T1_target_us', NaN), getField('T2_target_us', NaN))
            sprintf('Signed Im: %.6g A', getField('Im_A', NaN))
            sprintf('H mode: %s', H_mode)
            sprintf('H input: %.6g', H_input)
            sprintf('H used: %.6g', H_used)
            sprintf('n: %.6g', getField('n', NaN))
            ' '
            sprintf('Initial tau1/tau2: %.6g / %.6g us', ...
                getField('tau1_guess_us', NaN), getField('tau2_guess_us', NaN))
            sprintf('Initial signed peak: %.6g A', getField('peak_guess_A', NaN))
            sprintf('Initial calc T1/T2: %.6g / %.6g us', ...
                getField('T1_guess_calc_us', NaN), getField('T2_guess_calc_us', NaN))
            sprintf('Initial errors T1/T2/Peak: %.6g%% / %.6g%% / %.6g%%', ...
                getField('T1_guess_err_pct', NaN), ...
                getField('T2_guess_err_pct', NaN), ...
                getField('Peak_guess_err_pct', NaN))
            ' '
            sprintf('Optimized tau1/tau2: %.6g / %.6g us', ...
                getField('tau1_opt_us', NaN), getField('tau2_opt_us', NaN))
            sprintf('Optimized signed peak: %.6g A', getField('peak_opt_A', NaN))
            sprintf('Optimized calc T1/T2: %.6g / %.6g us', ...
                getField('T1_opt_calc_us', NaN), getField('T2_opt_calc_us', NaN))
            sprintf('Optimized errors T1/T2/Peak: %.6g%% / %.6g%% / %.6g%%', ...
                getField('T1_opt_err_pct', NaN), ...
                getField('T2_opt_err_pct', NaN), ...
                getField('Peak_opt_err_pct', NaN))
            ' '
            sprintf('Source: %s', toText(getField('source', '-')))
            sprintf('Created: %s', toText(getField('created_at', '-')))
        };
    end

    function v = getField(fieldName, defaultVal)
        if ismember(fieldName, row.Properties.VariableNames)
            v = row.(fieldName)(1);
            if iscell(v)
                v = v{1};
            end
        else
            v = defaultVal;
        end
    end

    function s = toText(v)
        if isstring(v) || ischar(v)
            s = char(string(v));
        elseif isnumeric(v)
            s = num2str(v);
        else
            s = '-';
        end
    end

    function H = local_compute_auto_H(tau1_us, tau2_us, n, t)
        shape = lightning_current(1, 1, tau1_us, tau2_us, n, t);
        H = max(shape);

        if ~isfinite(H) || H <= 0
            H = NaN;
        end
    end
end
