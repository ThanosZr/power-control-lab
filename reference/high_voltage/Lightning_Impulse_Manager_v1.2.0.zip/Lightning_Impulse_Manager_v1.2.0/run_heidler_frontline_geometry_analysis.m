%% ================= USER PARAMETERS =================
% Heidler parameters (you define them manually)
% I0   = 100e3;     % peak scaling current [A]
%tau1 = 1.83193e-6;    % front time constant [s]
%tau2 = 284.844e-6;     % tail time constant [s]
%n    = 10;        % Heidler exponent
%eta  = 0.986297;      % correction factor

% Time axis
%dt   = 1e-9;      % time step [s]
%tend = 200e-6;    % end time [s]
%t    = 0:dt:tend;

clc;
clear;
close all;

%% ============================================================
%  Run Script for Heidler Front-Line Geometry Analysis
%  Calls the function:
%      heidler_frontline_geometry_analysis(...)
%% ============================================================

%% ================= USER PARAMETERS =================
% Heidler parameters
%{
I0   = 118e3;        % peak scaling current [A]
tau1 = 5.1002e-6;    % front time constant [s]
tau2 = 65.0497e-6;    % tail time constant [s]
n    = 10;           % Heidler exponent [-]
eta  = 0.8746;       % correction factor [-]
%}
%{
I0   = 10e3;        % peak scaling current [A]
tau1 = 16.6519e-6;    % front time constant [s]
tau2 = 16.6519e-6;    % tail time constant [s]
n    = 10;           % Heidler exponent [-]
eta  = 0.2597;       % correction factor [-]
%}
%{
I0   = 100e3;        % peak scaling current [A]
tau1 = 7.5273e-6;    % front time constant [s]
tau2 = 276.2213e-6;    % tail time constant [s]
n    = 10;           % Heidler exponent [-]
eta  = 9.5;       % correction factor [-]
%}

%{
I0   = 100e3;        % peak scaling current [A]
tau1 = 15.4709e-6;    % front time constant [s]
tau2 = 266.0070e-6;    % tail time constant [s]
n    = 10;           % Heidler exponent [-]
eta  = 0.9029;       % correction factor [-]
%}
%{
I0   = 30e3;        % peak scaling current [A]
tau1 = 1.8226e-6;    % front time constant [s]
tau2 = 500.9671e-6;    % tail time constant [s]
n    = 10;           % Heidler exponent [-]
eta  = 0.9918;       % correction factor [-]
%}
I0   = 50e3;        % peak scaling current [A]
tau1 = 0.4552e-6;    % front time constant [s]
tau2 = 143.258e-6;    % tail time constant [s]
n    = 10;           % Heidler exponent [-]
eta  = 0.9928;       % correction factor [-]

% Time axis
dt   = 1e-9;         % time step [s]
tend = 500e-6;       % end time [s]

showPointLabels = true;

plotStyle = struct();

plotStyle.fontName        = 'Times New Roman';

plotStyle.tickFontSize    = 24;
plotStyle.labelFontSize   = 30;
plotStyle.titleFontSize   = 35;
plotStyle.legendFontSize  = 24;
plotStyle.textboxFontSize = 15;
plotStyle.pointFontSize   = 14;

plotStyle.axisLineWidth   = 1.2;
plotStyle.waveLineWidth   = 2.2;
plotStyle.imagLineWidth   = 2.4;
plotStyle.refLineWidth    = 1.8;
plotStyle.markerSize      = 8;
plotStyle.markerLineWidth = 1.4;

%% ================= RUN ANALYSIS =================
results = heidler_frontline_geometry_analysis( ...
    I0, tau1, tau2, n, eta, dt, tend, showPointLabels, plotStyle);

%% ================= OPTIONAL DISPLAY IN COMMAND WINDOW =================
disp(' ');
disp('===== Returned results structure =====');
disp(results);