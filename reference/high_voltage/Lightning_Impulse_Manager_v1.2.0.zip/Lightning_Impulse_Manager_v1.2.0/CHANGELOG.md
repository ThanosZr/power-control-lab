# Changelog

## 1.2.0 - 2026-09-15

### Added
- Positive (+) / Negative (-) polarity selector, synchronized with signed Im input.
- Negative current support in fitting, stored result rows, Details, EMTP verification and front-line geometry.
- Signed peak reporting and matching/opposite polarity indication in verification.
- MATLAB regression checks in test_polarity_support.m (not run here).

### Fixed
- Timing extraction now uses dominant-peak polarity; T1/T2 are invariant when a unipolar waveform is inverted.
- Peak-error denominators use absolute target current, preventing negative percentages.
- Signed verification peak error distinguishes equal-magnitude opposite-polarity signals.
- Launcher clears the updated numerical functions when starting the new package.

### Validation
- Independent Python numerical checks passed for analytic timing and positive/negative FixedH and AutoH fits.
- Static MATLAB parsing/lint passed. MATLAB GUI runtime validation was unavailable.


## 1.1.2 - 2026-09-15

### Fixed
- Visible Import EMTP CSV / Verify button in the main toolbar and Impulse Details.
- Main toolbar uses two button rows; the sidebar action grid has sufficient height.
- Persistent Load EMTP CSV button inside the verification window, including after cancellation.
- Mandatory manual current-column selection with numeric column indices; removed name-based detection and automatic fallback.
- Text-only columns are excluded without changing the original column indices.
- New signal selections recompute peak alignment using the same cleaned data as metrics.
- No EMTP comparison is displayed until a current column has been chosen.
- Invalid imports and canceled file pickers preserve the previous successful import.
- Details parameter panel now resizes with its window.
- Canonical MATLAB filenames and a launcher that prioritizes its own package folder.

### Preserved
- Heidler waveform and fitting functions, reference-row reconstruction, unit choices, optional normalization, manual shift, views, and metric definitions.


## 1.1.0 - 2026-09-14

### Added
- EMTP Verification workflow from a selected impulse result row.
- No-selection flow with Create New / Load Saved / Cancel.
- EMTP CSV import with preserved column names.
- Automatic current-column suggestion plus manual signal dropdown.
- Current units: Auto detect, A, kA, mA, MA.
- Automatic peak alignment using `max(abs(i))`.
- Manual EMTP time shift numeric field and slider.
- Align peaks now and Reset shift controls.
- Optional peak-magnitude normalization, disabled by default and polarity-preserving.
- Full waveform and Front detail views.
- Comparison metrics: peaks, peak error, shift, normalization factor, RMSE, normalized RMSE, correlation, common-sample count.
- Plot-only decimation for large waveforms while preserving full-resolution metrics.
- README, CHANGELOG, and VERSION files.

### Changed
- Main window title now includes v1.1.0.
- Main control/action areas include EMTP Verification entry points.
- Compute dialog can continue directly into EMTP Verification when invoked from the no-selection verification flow.

### Preserved
- Existing load, compute, details, merge, save, reload, row removal, and Heidler fitting behavior.
