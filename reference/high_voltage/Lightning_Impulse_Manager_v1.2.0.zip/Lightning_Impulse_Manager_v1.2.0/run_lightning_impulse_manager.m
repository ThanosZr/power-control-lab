% Run this launcher from the extracted v1.2.0 folder.
% Make the functions in this package take precedence over older path copies.
clear; clc;
impulseManagerFolder = fileparts(mfilename('fullpath'));
cd(impulseManagerFolder);
addpath(impulseManagerFolder, '-begin');
clear lightning_impulse_manager_gui open_impulse_details_gui verify_emtp_gui;
clear fit_heidler_impulse waveform_characteristics lightning_current heidler_frontline_geometry_analysis;
rehash;
lightning_impulse_manager_gui();
