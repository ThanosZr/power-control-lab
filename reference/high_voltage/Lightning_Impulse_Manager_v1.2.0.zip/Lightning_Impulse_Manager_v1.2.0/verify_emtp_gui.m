function verify_emtp_gui(row)
%VERIFY_EMTP_GUI Compare a stored/computed GUI impulse against an EMTP CSV.
% Reference waveform is regenerated from the selected result row using the
% same lightning_current() implementation as the main GUI.
%
% Version: 1.2.0

    if nargin < 1 || isempty(row) || ~istable(row) || height(row) ~= 1
        error('verify_emtp_gui requires exactly one impulse result row.');
    end

    % -------- Build reference waveform from the exact selected row --------
    T2 = getField(row, 'T2_target_us', 200);
    Im = getField(row, 'Im_A', NaN);
    n = getField(row, 'n', NaN);
    tau1 = getField(row, 'tau1_opt_us', getField(row, 'tau1_guess_us', NaN));
    tau2 = getField(row, 'tau2_opt_us', getField(row, 'tau2_guess_us', NaN));
    H_input = getField(row, 'H_input', getField(row, 'H', NaN));
    H_used = getField(row, 'H_used', H_input);
    H_mode = char(string(getField(row, 'H_mode', 'FixedH')));

    validateattributes(Im, {'numeric'}, {'real','finite','scalar','nonzero'}, ...
        mfilename, 'Im_A');
    vals = [T2, n, tau1, tau2];
    if any(~isfinite(vals)) || any(vals <= 0)
        error('T2, n, tau1 and tau2 must be finite and positive. Im_A may have either sign.');
    end

    dtRef = 1e-9;
    tendRef = max(500e-6, 1.5*T2*1e-6);
    tRef = (0:dtRef:tendRef).';

    % H_used is stored in each computed row and is the exact correction
    % factor used for the optimized waveform. Prefer it for both modes.
    Href = H_used;
    if (~isfinite(Href) || Href <= 0) && strcmpi(H_mode, 'AutoH')
        Href = local_compute_auto_H(tau1, tau2, n, tRef);
    end
    if ~isfinite(Href) || Href <= 0
        error('Selected row contains an invalid H value.');
    end

    iRefA = lightning_current(Im, Href, tau1, tau2, n, tRef).';
    iRefA = iRefA(:);

    % Build the window before asking for a file. Import remains available if
    % the file picker or the mandatory current-column selection is canceled.
    fig = uifigure('Name', 'EMTP Verification v1.2.0', ...
        'Tag', 'EMTPVerification', 'Position', [120 60 1280 840]);
    root = uigridlayout(fig, [4 1]);
    root.RowHeight = {118, 142, '1x', 178};
    root.Padding = [10 10 10 10];

    filePanel = uipanel(root, 'Title', '1. Import CSV and choose the current column');
    filePanel.Layout.Row = 1;
    fg = uigridlayout(filePanel, [3 4]);
    fg.RowHeight = {30, 28, 18};
    fg.ColumnWidth = {200, 140, '1x', 180};
    fg.RowSpacing = 4;
    fg.Padding = [8 6 8 6];

    btnLoadCSV = uibutton(fg, 'push', 'Text', 'Load EMTP CSV...', ...
        'FontWeight', 'bold', 'BackgroundColor', [0.15 0.40 0.68], ...
        'FontColor', [1 1 1], 'Tag', 'LoadEMTPCSV');
    lblFile = uilabel(fg, 'Text', 'No EMTP CSV loaded.');
    lblFile.Layout.Row = 1;
    lblFile.Layout.Column = [2 4];
    currentLabel = uilabel(fg, 'Text', 'Current column (manual)');
    currentLabel.Layout.Row = 2;
    currentLabel.Layout.Column = 1;
    ddSignal = uidropdown(fg, 'Items', {'Load an EMTP CSV first'}, ...
        'ItemsData', 0, 'Value', 0, 'Enable', 'off', 'Tag', 'EMTPCurrentColumn');
    ddSignal.Layout.Row = 2;
    ddSignal.Layout.Column = [2 3];
    btnChooseColumn = uibutton(fg, 'push', 'Text', 'Choose current column...', 'Enable', 'off');
    btnChooseColumn.Layout.Row = 2;
    btnChooseColumn.Layout.Column = 4;
    lblImportHint = uilabel(fg, ...
        'Text', 'Column 1 = time in seconds. Select any numeric signal by its column number/name.');
    lblImportHint.Layout.Row = 3;
    lblImportHint.Layout.Column = [1 4];

    controls = uipanel(root, 'Title', '2. Compare waveforms');
    controls.Layout.Row = 2;
    cg = uigridlayout(controls, [3 6]);
    cg.RowHeight = {28, 32, 30};
    cg.ColumnWidth = {130, 120, 130, 130, '1x', 170};
    cg.RowSpacing = 8;
    cg.Padding = [8 6 8 6];

    unitLabel = uilabel(cg, 'Text', 'CSV current unit');
    unitLabel.Layout.Row = 1; unitLabel.Layout.Column = 1;
    ddUnit = uidropdown(cg, 'Items', {'Auto detect','A','kA','mA','MA'}, 'Value', 'Auto detect');
    ddUnit.Layout.Row = 1; ddUnit.Layout.Column = 2;
    cbNorm = uicheckbox(cg, 'Text', 'Normalize EMTP peak magnitude', 'Value', false);
    cbNorm.Layout.Row = 1; cbNorm.Layout.Column = [3 5];
    ddView = uidropdown(cg, 'Items', {'Full waveform','Front detail'}, 'Value', 'Full waveform');
    ddView.Layout.Row = 1; ddView.Layout.Column = 6;

    shiftLabel = uilabel(cg, 'Text', 'EMTP time shift [s]');
    shiftLabel.Layout.Row = 2; shiftLabel.Layout.Column = 1;
    efShift = uieditfield(cg, 'numeric', 'Value', 0, 'Limits', [-Inf Inf], ...
        'ValueDisplayFormat', '%.9g');
    efShift.Layout.Row = 2; efShift.Layout.Column = 2;
    defaultSpan = max(tRef) - min(tRef);
    slShift = uislider(cg, 'Limits', [-0.25*defaultSpan, 0.25*defaultSpan], 'Value', 0);
    slShift.Layout.Row = 2; slShift.Layout.Column = [3 6];
    btnAlign = uibutton(cg, 'push', 'Text', 'Align peaks now');
    btnAlign.Layout.Row = 3; btnAlign.Layout.Column = [1 2];
    btnReset = uibutton(cg, 'push', 'Text', 'Reset shift');
    btnReset.Layout.Row = 3; btnReset.Layout.Column = [3 4];

    ax = uiaxes(root);
    ax.Layout.Row = 3;
    grid(ax, 'on'); box(ax, 'on');
    xlabel(ax, 'Time [s]');
    ylabel(ax, 'Current [kA]');
    title(ax, 'GUI impulse vs EMTP');

    resultsPanel = uipanel(root, 'Title', 'Comparison results');
    resultsPanel.Layout.Row = 4;
    rg = uigridlayout(resultsPanel, [1 2]);
    rg.ColumnWidth = {'1x','1x'};
    txtLeft = uitextarea(rg, 'Editable', 'off');
    txtRight = uitextarea(rg, 'Editable', 'off');

    state = struct();
    state.T = table();
    state.timeRaw = [];
    state.signalColumns = [];
    state.signalLabels = {};
    state.row = row;
    state.tRef = tRef;
    state.iRefA = iRefA;
    state.shift = 0;
    state.manualAlignment = false;
    state.emtpPath = '';
    state.hasSignal = false;
    state.maxPlotPoints = 12000;
    fig.UserData = state;

    btnLoadCSV.ButtonPushedFcn = @(~,~)loadCSV();
    btnChooseColumn.ButtonPushedFcn = @(~,~)chooseCurrentColumn();
    ddSignal.ValueChangedFcn = @(~,~)onSignalChanged();
    ddUnit.ValueChangedFcn = @(~,~)refreshAll(false);
    cbNorm.ValueChangedFcn = @(~,~)refreshAll(false);
    ddView.ValueChangedFcn = @(~,~)refreshAll(false);
    efShift.ValueChangedFcn = @(~,~)onNumericShift();
    slShift.ValueChangedFcn = @(~,evt)onSliderShift();
    slShift.ValueChangingFcn = @(~,evt)onSliderChanging(evt.Value);
    btnAlign.ButtonPushedFcn = @(~,~)alignPeaksNow();
    btnReset.ButtonPushedFcn = @(~,~)resetShift();

    setComparisonEnabled(false);
    showReferenceOnly();
    drawnow;
    loadCSV();

    function loadCSV()
        [fileName, pathName] = uigetfile({'*.csv','CSV Files (*.csv)'}, ...
            'Select EMTP waveform CSV (column 1 = time in seconds)');
        if ~isvalid(fig) || isequal(fileName, 0)
            return;
        end
        emtpPath = fullfile(pathName, fileName);
        % Validate before replacing a previous successful import.
        try
            T = readtable(emtpPath, 'TextType', 'string', 'VariableNamingRule', 'preserve');
            if width(T) < 2
                error('EMTP CSV must contain time in column 1 and at least one signal column.');
            end
            timeRaw = numericColumn(T{:,1});
            if nnz(isfinite(timeRaw)) < 2
                error('Column 1 must contain numeric time values in seconds.');
            end
            signalColumns = [];
            signalLabels = {};
            for col = 2:width(T)
                raw = numericColumn(T{:,col});
                valid = isfinite(timeRaw) & isfinite(raw);
                if nnz(valid) >= 2 && numel(unique(timeRaw(valid))) >= 2
                    signalColumns(end+1) = col; %#ok<AGROW>
                    signalLabels{end+1} = sprintf('Column %d | %s | %d valid samples', ...
                        col, T.Properties.VariableNames{col}, nnz(valid)); %#ok<AGROW>
                end
            end
            if isempty(signalColumns)
                error(['No signal column contains at least two numeric samples ' ...
                    'paired with distinct numeric times in column 1.']);
            end
        catch ME
            uialert(fig, sprintf('Could not load EMTP CSV:\n%s', ME.message), 'CSV Import Error');
            return;
        end

        st = fig.UserData;
        st.T = T;
        st.timeRaw = timeRaw(:);
        st.signalColumns = signalColumns;
        st.signalLabels = signalLabels;
        st.emtpPath = emtpPath;
        st.hasSignal = false;
        st.shift = 0;
        st.manualAlignment = false;
        fig.UserData = st;
        efShift.Value = 0;
        slShift.Value = 0;
        ddUnit.Value = 'Auto detect';
        cbNorm.Value = false;
        % Zero is an explicit placeholder, never a physical CSV column.
        ddSignal.ItemsData = [];
        ddSignal.Items = [{'-- Choose the current column --'}, signalLabels];
        ddSignal.ItemsData = [0, signalColumns];
        ddSignal.Value = 0;
        ddSignal.Enable = 'on';
        btnChooseColumn.Enable = 'on';
        lblFile.Text = emtpPath;
        lblFile.Tooltip = emtpPath;
        lblImportHint.Text = 'CSV loaded. Choose the current column; no column is selected automatically.';
        setComparisonEnabled(false);
        showReferenceOnly();
        chooseCurrentColumn();
    end

    function chooseCurrentColumn()
        st = fig.UserData;
        if isempty(st.signalColumns), return; end
        initial = find(st.signalColumns == ddSignal.Value, 1);
        if isempty(initial), initial = 1; end
        [sel, ok] = listdlg('Name', 'Select EMTP Current Column', ...
            'PromptString', {'Choose which column is the current signal.', ...
                             'Column 1 is time in seconds. Column names are not interpreted.'}, ...
            'SelectionMode', 'single', 'ListString', st.signalLabels, ...
            'InitialValue', initial, 'ListSize', [740 320], ...
            'OKString', 'Use this column', 'CancelString', 'Cancel');
        if ~isvalid(fig) || ~ok || isempty(sel)
            % On initial import the placeholder remains active. No fallback.
            return;
        end
        ddSignal.Value = st.signalColumns(sel);
        onSignalChanged();
    end

    function onSignalChanged()
        st = fig.UserData;
        st.hasSignal = ddSignal.Value ~= 0;
        fig.UserData = st;
        setComparisonEnabled(st.hasSignal);
        if ~st.hasSignal
            lblImportHint.Text = 'Choose the current column to calculate the comparison.';
            showReferenceOnly();
            return;
        end
        lblImportHint.Text = sprintf('Current = column %d: %s. Time = column 1 [s].', ...
            ddSignal.Value, st.T.Properties.VariableNames{ddSignal.Value});
        % Every manually selected column gets a fresh unit estimate and
        % peak alignment, using the same cleaned samples as the metrics.
        alignPeaksNow();
    end

    function setComparisonEnabled(enabled)
        if enabled, mode = 'on'; else, mode = 'off'; end
        widgets = {ddUnit, cbNorm, ddView, efShift, slShift, btnAlign, btnReset};
        for w = 1:numel(widgets)
            widgets{w}.Enable = mode;
        end
    end

    function showReferenceOnly()
        st = fig.UserData;
        cla(ax);
        [tp, yp] = decimateForPlot(st.tRef, st.iRefA/1e3, st.maxPlotPoints);
        plot(ax, tp, yp, 'LineWidth', 1.6, 'DisplayName', 'GUI reference');
        grid(ax, 'on'); box(ax, 'on');
        xlabel(ax, 'Time [s]'); ylabel(ax, 'Current [kA]');
        title(ax, 'GUI impulse vs EMTP');
        legend(ax, 'show', 'Location', 'best', 'Interpreter', 'none');
        xlim(ax, 'auto'); ylim(ax, 'auto');
        [~, peakIndex] = max(abs(st.iRefA));
        txtLeft.Value = {sprintf('GUI signed peak current: %.9g A', st.iRefA(peakIndex)), ...
            'Load an EMTP CSV, then choose the current column.'};
        txtRight.Value = {'No EMTP current column selected. No comparison has been calculated.'};
    end

    function [tE, yRaw] = selectedSignal(st)
        raw = numericColumn(st.T{:,ddSignal.Value});
        valid = isfinite(st.timeRaw) & isfinite(raw);
        tE = st.timeRaw(valid);
        yRaw = raw(valid);
        [tE, ord] = sort(tE);
        yRaw = yRaw(ord);
        [tE, uniq] = unique(tE, 'stable');
        yRaw = yRaw(uniq);
    end

    function refreshAll(recomputeAutoUnit)
        st = fig.UserData;
        if ~st.hasSignal, return; end
        [tE, yRaw] = selectedSignal(st);
        signalName = st.T.Properties.VariableNames{ddSignal.Value};

        if recomputeAutoUnit || ~isfield(st, 'lastAutoUnit')
            [autoUnit, autoMult] = detectUnit(yRaw, st.iRefA);
            st.lastAutoUnit = autoUnit;
            st.lastAutoMult = autoMult;
            fig.UserData = st;
        end

        unitChoice = ddUnit.Value;
        if strcmp(unitChoice, 'Auto detect')
            multiplier = st.lastAutoMult;
            unitResolved = st.lastAutoUnit;
        else
            [multiplier, unitResolved] = unitMultiplier(unitChoice);
        end
        iEA = yRaw * multiplier;
        [rawPeakA, rawPeakIndex] = max(abs(iEA));
        [refPeakA, refPeakIndex] = max(abs(st.iRefA));
        rawSignedPeakA = iEA(rawPeakIndex);
        refSignedPeakA = st.iRefA(refPeakIndex);

        normFactor = 1;
        iEPlotA = iEA;
        if cbNorm.Value
            if rawPeakA > 0 && isfinite(rawPeakA)
                normFactor = refPeakA / rawPeakA;
                iEPlotA = iEA * normFactor;
            end
        end

        tShifted = tE + st.shift;

        % Cache processed full-resolution data. The slider's live-drag callback
        % uses only plot-decimated cached data and defers full metrics until release.
        st.cachedTE = tE;
        st.cachedIEA = iEPlotA;
        st.cachedLabel = signalName;
        fig.UserData = st;

        % Accurate metrics use the full-resolution vectors, not plot-decimated data.
        [rmseA, nrmsePct, corrVal, nCommon] = computeMetrics(st.tRef, st.iRefA, tShifted, iEPlotA);
        peakErrPct = abs(rawSignedPeakA - refSignedPeakA) / refPeakA * 100;
        if rawPeakA == 0
            polarityText = 'EMTP signal is zero';
        elseif sign(rawSignedPeakA) == sign(refSignedPeakA)
            polarityText = 'Matching';
        else
            polarityText = 'Opposite';
        end

        cla(ax); hold(ax, 'on');
        [tp1, yp1] = decimateForPlot(st.tRef, st.iRefA/1e3, st.maxPlotPoints);
        [tp2, yp2] = decimateForPlot(tShifted, iEPlotA/1e3, st.maxPlotPoints);
        plot(ax, tp1, yp1, 'LineWidth', 1.6, 'DisplayName', 'GUI reference');
        plot(ax, tp2, yp2, 'LineWidth', 1.2, 'DisplayName', signalName);
        grid(ax, 'on'); box(ax, 'on');
        xlabel(ax, 'Time [s]'); ylabel(ax, 'Current [kA]');
        legend(ax, 'show', 'Location', 'best', 'Interpreter', 'none');

        if strcmp(ddView.Value, 'Front detail')
            applyFrontView(st.tRef, st.iRefA, tShifted, iEPlotA);
        else
            xlim(ax, 'auto'); ylim(ax, 'auto');
        end
        hold(ax, 'off');

        alignmentText = 'automatic peak alignment';
        if st.manualAlignment
            alignmentText = 'manual alignment';
        end

        txtLeft.Value = {
            sprintf('GUI signed peak: %.9g A (%.9g kA)', refSignedPeakA, refSignedPeakA/1e3)
            sprintf('EMTP signed peak before normalization: %.9g A (%.9g kA)', rawSignedPeakA, rawSignedPeakA/1e3)
            sprintf('Signed peak error: %.6g %% | Polarity: %s', peakErrPct, polarityText)
            sprintf('Applied time shift: %.12g s', st.shift)
            sprintf('Alignment mode: %s', alignmentText)
            sprintf('Resolved CSV unit: %s', unitResolved)
            };

        txtRight.Value = {
            sprintf('Amplitude normalization factor: %.12g', normFactor)
            sprintf('RMSE: %.9g A (%.9g kA)', rmseA, rmseA/1e3)
            sprintf('Normalized RMSE: %.6g %% of GUI peak magnitude', nrmsePct)
            sprintf('Correlation: %.9g', corrVal)
            sprintf('Common samples used: %d', nCommon)
            sprintf('Current column: %d | %s', ddSignal.Value, signalName)
            sprintf('EMTP source: %s', st.emtpPath)
            };
    end

    function alignPeaksNow()
        st = fig.UserData;
        if ~st.hasSignal, return; end
        [tE, yRaw] = selectedSignal(st);
        [~, ir] = max(abs(st.iRefA));
        [~, ie] = max(abs(yRaw));
        newShift = st.tRef(ir) - tE(ie);
        st.shift = newShift;
        st.manualAlignment = false;
        fig.UserData = st;
        efShift.Value = newShift;
        ensureSliderContains(newShift);
        slShift.Value = clamp(newShift, slShift.Limits(1), slShift.Limits(2));
        refreshAll(true);
    end

    function resetShift()
        st = fig.UserData;
        st.shift = 0;
        st.manualAlignment = true;
        fig.UserData = st;
        efShift.Value = 0;
        ensureSliderContains(0);
        slShift.Value = 0;
        refreshAll(false);
    end

    function onNumericShift()
        st = fig.UserData;
        st.shift = efShift.Value;
        st.manualAlignment = true;
        fig.UserData = st;
        ensureSliderContains(st.shift);
        slShift.Value = clamp(st.shift, slShift.Limits(1), slShift.Limits(2));
        refreshAll(false);
    end

    function onSliderShift()
        setShiftFromSlider(slShift.Value);
    end

    function onSliderChanging(v)
        st = fig.UserData;
        st.shift = v;
        st.manualAlignment = true;
        fig.UserData = st;
        efShift.Value = v;
        refreshPlotOnly();
    end

    function refreshPlotOnly()
        st = fig.UserData;
        if ~st.hasSignal || ~isfield(st, 'cachedTE') || ~isfield(st, 'cachedIEA')
            return;
        end
        tShifted = st.cachedTE + st.shift;
        cla(ax); hold(ax, 'on');
        [tp1, yp1] = decimateForPlot(st.tRef, st.iRefA/1e3, st.maxPlotPoints);
        [tp2, yp2] = decimateForPlot(tShifted, st.cachedIEA/1e3, st.maxPlotPoints);
        plot(ax, tp1, yp1, 'LineWidth', 1.6, 'DisplayName', 'GUI reference');
        plot(ax, tp2, yp2, 'LineWidth', 1.2, 'DisplayName', st.cachedLabel);
        grid(ax, 'on'); box(ax, 'on');
        xlabel(ax, 'Time [s]'); ylabel(ax, 'Current [kA]');
        legend(ax, 'show', 'Location', 'best', 'Interpreter', 'none');
        if strcmp(ddView.Value, 'Front detail')
            applyFrontView(st.tRef, st.iRefA, tShifted, st.cachedIEA);
        else
            xlim(ax, 'auto'); ylim(ax, 'auto');
        end
        hold(ax, 'off');
    end

    function setShiftFromSlider(v)
        st = fig.UserData;
        st.shift = v;
        st.manualAlignment = true;
        fig.UserData = st;
        efShift.Value = v;
        refreshAll(false);
    end

    function ensureSliderContains(v)
        lim = slShift.Limits;
        if v < lim(1) || v > lim(2)
            span = max(abs(v)*1.25, max(abs(lim)));
            if span == 0, span = defaultSpan*0.25; end
            slShift.Limits = [-span span];
        end
    end

    function applyFrontView(tR, iR, tE, iE)
        [~, ir] = max(abs(iR));
        [~, ie] = max(abs(iE));
        tPeakR = tR(ir);
        tPeakE = tE(ie);
        peakT = max(tPeakR, tPeakE);
        left = max(min([tR; tE]), min(tPeakR, tPeakE) - max(peakT*0.35, 5e-6));
        right = min(max([tR; tE]), max(tPeakR, tPeakE) + max(peakT*0.20, 5e-6));
        if isfinite(left) && isfinite(right) && right > left
            xlim(ax, [left right]);
        end
    end
end

function v = getField(row, fieldName, defaultVal)
    if ismember(fieldName, row.Properties.VariableNames)
        v = row.(fieldName)(1);
        if iscell(v), v = v{1}; end
        if isstring(v) && isscalar(v)
            num = str2double(v);
            if isfinite(num), v = num; end
        end
    else
        v = defaultVal;
    end
end

function x = numericColumn(raw)
    if isnumeric(raw) || islogical(raw)
        x = double(raw(:));
    elseif iscell(raw)
        x = NaN(numel(raw),1);
        for k = 1:numel(raw)
            val = raw{k};
            if isnumeric(val) && isscalar(val)
                x(k) = double(val);
            else
                x(k) = str2double(string(val));
            end
        end
    else
        s = string(raw(:));
        x = str2double(s);
    end
end

function [unitName, mult] = detectUnit(yRaw, iRefA)
    pRaw = max(abs(yRaw(isfinite(yRaw))));
    pRef = max(abs(iRefA(isfinite(iRefA))));
    if isempty(pRaw) || pRaw <= 0 || isempty(pRef) || pRef <= 0
        unitName = 'A'; mult = 1; return;
    end
    names = {'A','kA','mA','MA'};
    mults = [1, 1e3, 1e-3, 1e6];
    ratios = abs(log10((pRaw .* mults) ./ pRef));
    [~, ix] = min(ratios);
    unitName = names{ix};
    mult = mults(ix);
end

function [mult, unitName] = unitMultiplier(choice)
    unitName = choice;
    switch choice
        case 'A',  mult = 1;
        case 'kA', mult = 1e3;
        case 'mA', mult = 1e-3;
        case 'MA', mult = 1e6;
        otherwise, mult = 1; unitName = 'A';
    end
end

function [rmseA, nrmsePct, corrVal, nCommon] = computeMetrics(tR, iR, tE, iE)
    lo = max(min(tR), min(tE));
    hi = min(max(tR), max(tE));
    mask = tR >= lo & tR <= hi & isfinite(iR);
    tCommon = tR(mask);
    r = iR(mask);
    if numel(tCommon) < 2
        rmseA = NaN; nrmsePct = NaN; corrVal = NaN; nCommon = 0; return;
    end
    e = interp1(tE, iE, tCommon, 'linear', NaN);
    valid = isfinite(r) & isfinite(e);
    r = r(valid); e = e(valid);
    nCommon = numel(r);
    if nCommon < 2
        rmseA = NaN; nrmsePct = NaN; corrVal = NaN; return;
    end
    rmseA = sqrt(mean((e-r).^2));
    refPeak = max(abs(iR));
    if refPeak > 0, nrmsePct = rmseA/refPeak*100; else, nrmsePct = NaN; end
    if std(r) == 0 || std(e) == 0
        corrVal = NaN;
    else
        C = corrcoef(r, e);
        corrVal = C(1,2);
    end
end

function [tx, yx] = decimateForPlot(t, y, maxPts)
    n = numel(t);
    if n <= maxPts
        tx = t; yx = y; return;
    end
    idx = unique(round(linspace(1, n, maxPts)));
    tx = t(idx); yx = y(idx);
end

function H = local_compute_auto_H(tau1_us, tau2_us, n, t)
    shape = lightning_current(1, 1, tau1_us, tau2_us, n, t);
    H = max(shape);
    if ~isfinite(H) || H <= 0, H = NaN; end
end

function y = clamp(x, a, b)
    y = min(max(x, a), b);
end
