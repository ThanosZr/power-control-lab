function i = lightning_current(Im, H, tau1_us, tau2_us, n, t)
% Heidler lightning current model
% Im is signed. Negative Im generates a negative-polarity impulse.

    tau1 = tau1_us * 1e-6;
    tau2 = tau2_us * 1e-6;

    a = Im / H;
    b = ((t ./ tau1).^n) ./ (1 + (t ./ tau1).^n);
    c = exp(-t ./ tau2);

    i = a .* b .* c;
end
