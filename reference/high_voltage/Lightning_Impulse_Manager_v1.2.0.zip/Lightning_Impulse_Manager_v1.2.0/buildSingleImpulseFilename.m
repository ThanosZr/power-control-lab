function fname = buildSingleImpulseFilename(Trow)
% Build file name T1_<tau1>_T2_<tau2>_Ip_<peak>.csv using target T1/T2 and Im.

    T1 = Trow.T1_target_us(1);
    T2 = Trow.T2_target_us(1);
    Ip = Trow.Im_A(1);

    fname = sprintf('T1_%s_T2_%s_Ip_%s.csv', sanitizeNum(T1), sanitizeNum(T2), sanitizeNum(Ip));
end

function s = sanitizeNum(x)
    s = strrep(sprintf('%.6g', x), '.', 'p');
    s = strrep(s, '+', '');
end
