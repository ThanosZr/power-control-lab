function test_polarity_support()
% Run in MATLAB: test_polarity_support
% Regression checks for signed peaks, invariant timing, fitting and CSVs.
% No GUI interaction is required. This file was not executed in MATLAB in
% the package editing environment because MATLAB was unavailable there.

    % Independent analytic pulse: peak +/-10 A at 2 us; T1=2 us, T2=4 us.
    t = (0:5) * 1e-6;
    y = [0, 5, 10, 8, 5, 0];
    p = waveform_characteristics(t, y);
    m = waveform_characteristics(t, -y);
    assert(p.Ipeak == 10 && m.Ipeak == -10);
    assert(abs(p.T1 - 2e-6) < 1e-15 && abs(p.T2 - 4e-6) < 1e-15);
    assert(abs(m.T1 - p.T1) < 1e-15 && abs(m.T2 - p.T2) < 1e-15);
    assert(m.t_peak == p.t_peak && m.t_virtual_origin == p.t_virtual_origin);

    % Multiple Heidler shapes, including row/column vector inputs.
    t = 0:20e-9:800e-6;
    for exponent = [2, 10]
        y = lightning_current(100e3, 0.93, 5, 200, exponent, t);
        ym = lightning_current(-100e3, 0.93, 5, 200, exponent, t);
        assert(isequal(ym, -y));
        p = waveform_characteristics(t, y);
        m = waveform_characteristics(t(:), ym(:));
        assert(p.Ipeak > 0 && m.Ipeak == -p.Ipeak);
        assert(isfinite(p.T1) && isfinite(p.T2) && p.T1 > 0 && p.T2 > 0);
        assert(p.T1 == m.T1 && p.T2 == m.T2 && p.t_peak == m.t_peak);
    end

    % The same targets must produce the same optimized shape for both signs.
    for mode = {'FixedH', 'AutoH'}
        pos = fit_heidler_impulse(1, 200, 100e3, 0.93, 10, 5, 200, 20e-9, 600e-6, mode{1});
        neg = fit_heidler_impulse(1, 200, -100e3, 0.93, 10, 5, 200, 20e-9, 600e-6, mode{1});
        fields = {'tau1_opt_us','tau2_opt_us','H_used','T1_opt_calc_us','T2_opt_calc_us'};
        for k = 1:numel(fields)
            assert(isfinite(neg.(fields{k})));
            assert(abs(pos.(fields{k}) - neg.(fields{k})) < 1e-9);
        end
        assert(neg.Im_A == -pos.Im_A && neg.peak_opt_A == -pos.peak_opt_A);
        assert(neg.peak_guess_A == -pos.peak_guess_A);
        assert(neg.Peak_guess_err_pct >= 0 && neg.Peak_opt_err_pct >= 0);
        assert(abs(neg.Peak_opt_err_pct - pos.Peak_opt_err_pct) < 1e-10);
        if strcmp(mode{1}, 'AutoH')
            assert(abs(neg.peak_opt_A - neg.Im_A) < 1e-6);
        end
        assert(~strcmp(buildSingleImpulseFilename(pos), buildSingleImpulseFilename(neg)));
        assert(isequal(pos.Properties.VariableNames, neg.Properties.VariableNames));
    end

    % Sign must survive save, reload, and reference-waveform reconstruction.
    csvPath = [tempname, '.csv'];
    cleanup = onCleanup(@()delete(csvPath)); %#ok<NASGU>
    writetable([pos; neg], csvPath);
    restored = readtable(csvPath);
    assert(restored.Im_A(1) > 0 && restored.Im_A(2) < 0);
    row = restored(2,:);
    restoredY = lightning_current(row.Im_A, row.H_used, row.tau1_opt_us, row.tau2_opt_us, row.n, t);
    assert(min(restoredY) < 0 && max(restoredY) <= 0);

    rejectedZero = false;
    try
        fit_heidler_impulse(1, 200, 0, 0.93, 10, 5, 200, 20e-9, 600e-6, 'FixedH');
    catch
        rejectedZero = true;
    end
    assert(rejectedZero, 'Zero current must be rejected.');
    disp('All polarity regression checks passed.');
end
