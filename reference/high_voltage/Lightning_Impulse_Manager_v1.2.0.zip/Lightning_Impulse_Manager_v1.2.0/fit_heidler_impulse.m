function Trow = fit_heidler_impulse(T1_target_us, T2_target_us, Im_A, H_input, n, ...
    tau1_guess_us, tau2_guess_us, dt, tend, H_mode)
% Compute one Heidler impulse and return a one-row table.
% Im_A is signed: positive or negative polarity, but never zero.
%
% H_mode:
%   'FixedH' -> use H_input as-is
%   'AutoH'  -> compute H so that the waveform peak equals Im_A

    if nargin < 8 || isempty(dt)
        dt = 1e-9;
    end
    if nargin < 9 || isempty(tend)
        tend = max(500e-6, 1.5*T2_target_us*1e-6);
    end
    if nargin < 10 || isempty(H_mode)
        H_mode = 'FixedH';
    end

    validateattributes(Im_A, {'numeric'}, {'real','finite','scalar','nonzero'}, ...
        mfilename, 'Im_A');
    positiveInputs = {T1_target_us, T2_target_us, n, tau1_guess_us, tau2_guess_us, dt, tend};
    positiveNames = {'T1_target_us','T2_target_us','n','tau1_guess_us','tau2_guess_us','dt','tend'};
    for k = 1:numel(positiveInputs)
        validateattributes(positiveInputs{k}, {'numeric'}, {'real','finite','scalar','positive'}, ...
            mfilename, positiveNames{k});
    end

    if strcmpi(H_mode, 'FixedH')
        validateattributes(H_input, {'numeric'}, {'real','finite','scalar','positive'}, ...
            mfilename, 'H_input');
    end

    t = 0:dt:tend;

    % ===== Initial waveform =====
    if strcmpi(H_mode, 'AutoH')
        H_guess_used = compute_auto_H(tau1_guess_us, tau2_guess_us, n, t);
    else
        H_guess_used = H_input;
    end

    i_guess = lightning_current(Im_A, H_guess_used, tau1_guess_us, tau2_guess_us, n, t);
    chars_guess = waveform_characteristics(t, i_guess);

    % ===== Optimization target =====
    imp.Im = Im_A;
    imp.H_input = H_input;
    imp.n = n;
    imp.T1_target_us = T1_target_us;
    imp.T2_target_us = T2_target_us;
    imp.H_mode = H_mode;

    x0 = [tau1_guess_us, tau2_guess_us];

    objfun = @(x) objective_heidler_T1T2_only(x, imp, t);

    opts = optimset('Display','off', ...
                    'TolX',1e-9, ...
                    'TolFun',1e-12, ...
                    'MaxFunEvals',5000, ...
                    'MaxIter',5000);

    x_opt = fminsearch(objfun, x0, opts);

    tau1_opt_us = x_opt(1);
    tau2_opt_us = x_opt(2);

    % ===== Final H used =====
    if strcmpi(H_mode, 'AutoH')
        H_used = compute_auto_H(tau1_opt_us, tau2_opt_us, n, t);
    else
        H_used = H_input;
    end

    % ===== Optimized waveform =====
    i_opt = lightning_current(Im_A, H_used, tau1_opt_us, tau2_opt_us, n, t);
    chars_opt = waveform_characteristics(t, i_opt);

    name = sprintf('T1_%s_T2_%s_Ip_%s', ...
        fmtForName(T1_target_us), ...
        fmtForName(T2_target_us), ...
        fmtForName(Im_A));

    source = "computed";
    created_at = string(datetime('now','Format','yyyy-MM-dd HH:mm:ss'));

    Trow = table( ...
        string(name), string(H_mode), H_input, H_used, Im_A, chars_guess.Ipeak, n, ...
        tau1_guess_us, tau2_guess_us, tau1_opt_us, tau2_opt_us, ...
        T1_target_us, T2_target_us, ...
        chars_guess.T1*1e6, chars_guess.T2*1e6, ...
        abs(chars_guess.T1*1e6 - T1_target_us)/T1_target_us*100, ...
        abs(chars_guess.T2*1e6 - T2_target_us)/T2_target_us*100, ...
        abs(chars_guess.Ipeak - Im_A)/abs(Im_A)*100, ...
        chars_opt.Ipeak, chars_opt.T1*1e6, chars_opt.T2*1e6, ...
        abs(chars_opt.T1*1e6 - T1_target_us)/T1_target_us*100, ...
        abs(chars_opt.T2*1e6 - T2_target_us)/T2_target_us*100, ...
        abs(chars_opt.Ipeak - Im_A)/abs(Im_A)*100, ...
        string(source), created_at, ...
        'VariableNames', { ...
        'name','H_mode','H_input','H_used','Im_A','peak_guess_A','n', ...
        'tau1_guess_us','tau2_guess_us','tau1_opt_us','tau2_opt_us', ...
        'T1_target_us','T2_target_us', ...
        'T1_guess_calc_us','T2_guess_calc_us', ...
        'T1_guess_err_pct','T2_guess_err_pct','Peak_guess_err_pct', ...
        'peak_opt_A','T1_opt_calc_us','T2_opt_calc_us', ...
        'T1_opt_err_pct','T2_opt_err_pct','Peak_opt_err_pct', ...
        'source','created_at'});
end

function J = objective_heidler_T1T2_only(x, imp, t)
    tau1_us = x(1);
    tau2_us = x(2);

    if tau1_us <= 0 || tau2_us <= 0 || tau2_us <= tau1_us
        J = 1e12;
        return;
    end

    if strcmpi(imp.H_mode, 'AutoH')
        H_used = compute_auto_H(tau1_us, tau2_us, imp.n, t);
    else
        H_used = imp.H_input;
    end

    i = lightning_current(imp.Im, H_used, tau1_us, tau2_us, imp.n, t);
    chars = waveform_characteristics(t, i);

    if isnan(chars.T1) || isnan(chars.T2) || isnan(chars.Ipeak)
        J = 1e12;
        return;
    end

    eT1 = (chars.T1*1e6 - imp.T1_target_us) / imp.T1_target_us;
    eT2 = (chars.T2*1e6 - imp.T2_target_us) / imp.T2_target_us;

    J = eT1^2 + eT2^2;
end

function H = compute_auto_H(tau1_us, tau2_us, n, t)
% Compute H so that peak current becomes exactly Im_A when using lightning_current(Im_A, H, ...)

    shape = lightning_current(1, 1, tau1_us, tau2_us, n, t);
    H = max(shape);

    if ~isfinite(H) || H <= 0
        H = NaN;
    end
end

function s = fmtForName(x)
    s = strrep(sprintf('%.6g', x), '.', 'p');
    s = strrep(s, '+', '');
end
