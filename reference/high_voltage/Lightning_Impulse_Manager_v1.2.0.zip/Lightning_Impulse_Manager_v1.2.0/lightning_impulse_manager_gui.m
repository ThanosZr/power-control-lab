function lightning_impulse_manager_gui()
% Lightning Impulse Manager GUI
% 2D-only GUI for loading, computing, viewing, merging and EMTP verification.
% Version 1.2.0

    app = struct();
    app.loadedFiles = struct('filePath', {}, 'table', {}, 'tab', {}, 'uitable', {});
    app.currentTabIndex = [];
    app.outputFolder = fullfile(pwd, 'ls_params');
    if ~exist(app.outputFolder, 'dir')
        mkdir(app.outputFolder);
    end

    app.fig = uifigure('Name', 'Lightning Impulse Manager v1.2.0', ...
        'Position', [100 100 1400 820]);

    app.mainGrid = uigridlayout(app.fig, [3 1]);
    app.mainGrid.RowHeight = {148, '1x', 32};
    app.mainGrid.ColumnWidth = {'1x'};
    app.mainGrid.Padding = [8 8 8 8];

    %% Top controls
    app.topPanel = uipanel(app.mainGrid, 'Title', 'Controls');
    app.topPanel.Layout.Row = 1;
    app.topGrid = uigridlayout(app.topPanel, [3 4]);
    app.topGrid.RowHeight = {34, 34, 22};
    app.topGrid.ColumnWidth = {'1x', '1x', '1x', '1x'};
    app.topGrid.RowSpacing = 6;
    app.topGrid.Padding = [8 8 8 8];

    app.btnLoad = uibutton(app.topGrid, 'push', 'Text', 'Load Saved Impulse CSV(s)', ...
        'ButtonPushedFcn', @(~,~)onLoadCSVs());
    app.btnCompute = uibutton(app.topGrid, 'push', 'Text', 'Compute New Impulse', ...
        'ButtonPushedFcn', @(~,~)onComputeNewImpulse());
    app.btnVerify = uibutton(app.topGrid, 'push', 'Text', 'Import EMTP CSV / Verify', ...
        'FontWeight', 'bold', 'BackgroundColor', [0.15 0.40 0.68], ...
        'FontColor', [1 1 1], 'Tag', 'ImportEMTPCSV', ...
        'ButtonPushedFcn', @(~,~)onVerifyAgainstEMTP());
    app.btnDetails = uibutton(app.topGrid, 'push', 'Text', 'Open Details', ...
        'ButtonPushedFcn', @(~,~)onOpenDetails());
    app.btnMerge = uibutton(app.topGrid, 'push', 'Text', 'Merge Selected', ...
        'ButtonPushedFcn', @(~,~)onMergeSelected());
    app.btnSaveSelected = uibutton(app.topGrid, 'push', 'Text', 'Save Selected Rows', ...
        'ButtonPushedFcn', @(~,~)onSaveSelectedRows());
    app.btnReload = uibutton(app.topGrid, 'push', 'Text', 'Reload Current Tab', ...
        'ButtonPushedFcn', @(~,~)onReloadCurrentTab());
    app.btnCloseTab = uibutton(app.topGrid, 'push', 'Text', 'Close Tab ✕', ...
        'ButtonPushedFcn', @(~,~)onCloseCurrentTab());
    app.lblInfo = uilabel(app.topGrid, ...
        'Text', 'Select an impulse row, then Import EMTP CSV / Verify.', ...
        'HorizontalAlignment', 'left');
    app.lblInfo.Layout.Row = 3;
    app.lblInfo.Layout.Column = [1 4];

    %% Center area
    app.centerGrid = uigridlayout(app.mainGrid, [1 2]);
    app.centerGrid.Layout.Row = 2;
    app.centerGrid.ColumnWidth = {'3x', '1.2x'};

    app.tabgroup = uitabgroup(app.centerGrid, 'SelectionChangedFcn', @(src,evt)onTabChanged(evt));

    app.sidePanel = uipanel(app.centerGrid, 'Title', 'Selected Impulse');
    app.sideGrid = uigridlayout(app.sidePanel, [8 1]);
    app.sideGrid.RowHeight = {22, 60, 22, 114, 22, 136, 22, '1x'};
    app.sideGrid.RowSpacing = 6;
    app.sideGrid.Scrollable = 'on';

    uilabel(app.sideGrid, 'Text', 'Loaded file / tab');
    app.txtCurrentFile = uitextarea(app.sideGrid, 'Editable', 'off', 'Value', {'-'});

    uilabel(app.sideGrid, 'Text', 'Selected row summary');
    app.txtSummary = uitextarea(app.sideGrid, 'Editable', 'off', 'Value', {'No selection'});

    uilabel(app.sideGrid, 'Text', 'Actions');
    app.actionGrid = uigridlayout(app.sideGrid, [3 2]);
    app.actionGrid.RowHeight = {34, 34, 34};
    app.actionGrid.ColumnWidth = {'1x', '1x'};
    app.actionGrid.Padding = [6 6 6 6];
    app.actionGrid.RowSpacing = 6;
    uibutton(app.actionGrid, 'push', 'Text', 'Details', 'ButtonPushedFcn', @(~,~)onOpenDetails());
    uibutton(app.actionGrid, 'push', 'Text', 'Recompute', 'ButtonPushedFcn', @(~,~)onRecomputeSelected());
    uibutton(app.actionGrid, 'push', 'Text', 'Plot 2D', 'ButtonPushedFcn', @(~,~)onOpenDetails());
    uibutton(app.actionGrid, 'push', 'Text', 'Remove Row', 'ButtonPushedFcn', @(~,~)onRemoveSelectedRow());
    sideVerify = uibutton(app.actionGrid, 'push', 'Text', 'Import EMTP CSV / Verify', ...
        'FontWeight', 'bold', 'ButtonPushedFcn', @(~,~)onVerifyAgainstEMTP());
    sideVerify.Layout.Row = 3;
    sideVerify.Layout.Column = [1 2];

    app.lblHint = uilabel(app.sideGrid, 'Text', 'Notes');
    app.txtHint = uitextarea(app.sideGrid, 'Editable', 'off', 'Value', {
        '• One computed impulse is saved per CSV file.'
        '• Merge combines selected rows from loaded tabs.'
        '• Details also contains Import EMTP CSV / Verify.'
        '• Choose the EMTP current column yourself; column 1 is time [s].'});

    %% Bottom status
    app.statusLabel = uilabel(app.mainGrid, 'Text', 'Ready.', 'HorizontalAlignment', 'left');
    app.statusLabel.Layout.Row = 3;

    app.fig.UserData = app;

    %% Nested helpers
    function setStatus(msg)
        app = app.fig.UserData;
        app.statusLabel.Text = msg;
        app.lblInfo.Text = msg;
        app.fig.UserData = app;
    end

    function idx = getCurrentTabIndex()
        app = app.fig.UserData;
        idx = [];
        if isempty(app.loadedFiles)
            return;
        end
        selTab = app.tabgroup.SelectedTab;
        for ii = 1:numel(app.loadedFiles)
            if isequal(app.loadedFiles(ii).tab, selTab)
                idx = ii;
                return;
            end
        end
    end

    function [tbl, rowIdx] = getSelectedRowTable()
        tbl = [];
        rowIdx = [];
        app = app.fig.UserData;
        idx = getCurrentTabIndex();
        if isempty(idx)
            return;
        end
        uit = app.loadedFiles(idx).uitable;
        if isempty(uit.Selection)
            return;
        end
        rowIdx = uit.Selection(1);
        tbl = app.loadedFiles(idx).table;
    end

    function refreshSelectionSummary()
        app = app.fig.UserData;
        idx = getCurrentTabIndex();
        if isempty(idx)
            app.txtCurrentFile.Value = {'-'};
            app.txtSummary.Value = {'No tab selected'};
            app.fig.UserData = app;
            return;
        end
        app.txtCurrentFile.Value = {app.loadedFiles(idx).filePath};
        uit = app.loadedFiles(idx).uitable;
        if isempty(uit.Selection)
            app.txtSummary.Value = {'No row selected'};
            app.fig.UserData = app;
            return;
        end
        r = uit.Selection(1);
        row = app.loadedFiles(idx).table(r,:);
        app.txtSummary.Value = buildRowSummary(row);
        app.fig.UserData = app;
    end

    function txt = buildRowSummary(row)
        txt = {
            sprintf('Name: %s', toText(getRowValue(row,'name','-')))
            sprintf('Peak: %s A', num2str(getRowValue(row,'peak_opt_A', getRowValue(row,'Im_A', NaN)), '%.6g'))
            sprintf('Target T1/T2: %s / %s us', ...
                num2str(getRowValue(row,'T1_target_us', NaN), '%.6g'), ...
                num2str(getRowValue(row,'T2_target_us', NaN), '%.6g'))
            sprintf('Opt tau1/tau2: %s / %s us', ...
                num2str(getRowValue(row,'tau1_opt_us', NaN), '%.6g'), ...
                num2str(getRowValue(row,'tau2_opt_us', NaN), '%.6g'))
            sprintf('Opt calc T1/T2: %s / %s us', ...
                num2str(getRowValue(row,'T1_opt_calc_us', NaN), '%.6g'), ...
                num2str(getRowValue(row,'T2_opt_calc_us', NaN), '%.6g'))
            sprintf('Errors T1/T2/Peak: %s%% / %s%% / %s%%', ...
                num2str(getRowValue(row,'T1_opt_err_pct', NaN), '%.6g'), ...
                num2str(getRowValue(row,'T2_opt_err_pct', NaN), '%.6g'), ...
                num2str(getRowValue(row,'Peak_opt_err_pct', NaN), '%.6g'))
        };
    end

    function v = getRowValue(row, fieldName, defaultVal)
        if ismember(fieldName, row.Properties.VariableNames)
            v = row.(fieldName)(1);
            if iscell(v)
                v = v{1};
            end
        else
            v = defaultVal;
        end
    end

    function s = toText(v)
        if isstring(v) || ischar(v)
            s = char(string(v));
        elseif isnumeric(v)
            s = num2str(v);
        else
            s = '-';
        end
    end

    function onLoadCSVs()
        app = app.fig.UserData;
        [files, pathName] = uigetfile({'*.csv','CSV Files (*.csv)'}, ...
            'Select impulse CSV file(s)', 'MultiSelect', 'on');
        if isequal(files,0)
            setStatus('Load canceled.');
            return;
        end
        if ischar(files) || isstring(files)
            files = {files};
        end
        for ii = 1:numel(files)
            fullPath = fullfile(pathName, files{ii});
            try
                T = readtable(fullPath, 'TextType', 'string');
                validateImpulseTable(T);
                addTableAsTab(T, fullPath);
            catch ME
                uialert(app.fig, sprintf('Could not load %s\n\n%s', files{ii}, ME.message), 'Load Error');
            end
        end
        setStatus('CSV file(s) loaded.');
        refreshSelectionSummary();
    end

    function validateImpulseTable(T)
        requiredCols = {'name','T1_target_us','T2_target_us'};
        for jj = 1:numel(requiredCols)
            if ~ismember(requiredCols{jj}, T.Properties.VariableNames)
                error('Missing required column: %s', requiredCols{jj});
            end
        end
    end

    function addTableAsTab(T, filePath)
        app = app.fig.UserData;
        [~, baseName, ext] = fileparts(filePath);
        tabTitle = [baseName ext];
        tab = uitab(app.tabgroup, 'Title', tabTitle);
        grid = uigridlayout(tab, [2 1]);
        grid.RowHeight = {'1x', 28};

        uit = uitable(grid, 'Data', T, 'ColumnSortable', true, ...
            'Multiselect', 'on', 'CellSelectionCallback', @(~,~)refreshSelectionSummary());
        uit.Layout.Row = 1;

        bottomGrid = uigridlayout(grid, [1 3]);
        bottomGrid.ColumnWidth = {180, 180, '1x'};
        uibutton(bottomGrid, 'Text', 'Open Details', 'ButtonPushedFcn', @(~,~)onOpenDetails());
        uibutton(bottomGrid, 'Text', 'Close This Tab ✕', 'ButtonPushedFcn', @(~,~)closeSpecificTab(tab));
        uilabel(bottomGrid, 'Text', filePath, 'HorizontalAlignment', 'left');

        entry.filePath = filePath;
        entry.table = T;
        entry.tab = tab;
        entry.uitable = uit;
        app.loadedFiles(end+1) = entry;
        app.tabgroup.SelectedTab = tab;
        app.fig.UserData = app;
    end

    function closeSpecificTab(tab)
        app = app.fig.UserData;
        idx = [];
        for ii = 1:numel(app.loadedFiles)
            if isequal(app.loadedFiles(ii).tab, tab)
                idx = ii;
                break;
            end
        end
        if isempty(idx)
            return;
        end
        delete(app.loadedFiles(idx).tab);
        app.loadedFiles(idx) = [];
        app.fig.UserData = app;
        refreshSelectionSummary();
        setStatus('Tab closed.');
    end

    function onCloseCurrentTab()
        idx = getCurrentTabIndex();
        if isempty(idx)
            setStatus('No active tab to close.');
            return;
        end
        app = app.fig.UserData;
        closeSpecificTab(app.loadedFiles(idx).tab);
    end

    function onTabChanged(~)
        refreshSelectionSummary();
    end

    function onOpenDetails()
        [tbl, rowIdx] = getSelectedRowTable();
        if isempty(tbl) || isempty(rowIdx)
            setStatus('Select one row first.');
            return;
        end
        row = tbl(rowIdx,:);
        open_impulse_details_gui(row);
        setStatus('Details window opened.');
    end

    function onRecomputeSelected()
        [tbl, rowIdx] = getSelectedRowTable();
        if isempty(tbl) || isempty(rowIdx)
            setStatus('Select one row first.');
            return;
        end
        row = tbl(rowIdx,:);
        open_compute_dialog(row, []);
    end

    function onRemoveSelectedRow()
        app = app.fig.UserData;
        idx = getCurrentTabIndex();
        if isempty(idx)
            return;
        end
        uit = app.loadedFiles(idx).uitable;
        if isempty(uit.Selection)
            setStatus('Select row(s) to remove.');
            return;
        end
        rows = unique(uit.Selection(:,1));
        T = app.loadedFiles(idx).table;
        T(rows,:) = [];
        app.loadedFiles(idx).table = T;
        app.loadedFiles(idx).uitable.Data = T;
        app.loadedFiles(idx).uitable.Selection = [];
        app.fig.UserData = app;
        refreshSelectionSummary();
        setStatus('Selected row(s) removed from current tab.');
    end

    function onReloadCurrentTab()
        app = app.fig.UserData;
        idx = getCurrentTabIndex();
        if isempty(idx)
            setStatus('No active tab.');
            return;
        end
        fp = app.loadedFiles(idx).filePath;
        try
            T = readtable(fp, 'TextType', 'string');
            validateImpulseTable(T);
            app.loadedFiles(idx).table = T;
            app.loadedFiles(idx).uitable.Data = T;
            app.fig.UserData = app;
            refreshSelectionSummary();
            setStatus('Current tab reloaded from file.');
        catch ME
            uialert(app.fig, ME.message, 'Reload Error');
        end
    end

    function onSaveSelectedRows()
        [selectedTbl, count] = collectSelectedRows();
        if count == 0
            setStatus('No selected rows found.');
            return;
        end
        suggest = suggestMergedFilename(app.outputFolder);
        [file, pathName] = uiputfile({'*.csv','CSV Files (*.csv)'}, 'Save selected rows', ...
            fullfile(app.outputFolder, suggest));
        if isequal(file,0)
            setStatus('Save canceled.');
            return;
        end
        writetable(selectedTbl, fullfile(pathName, file));
        setStatus(sprintf('Saved %d selected row(s).', height(selectedTbl)));
    end

    function onMergeSelected()
        [selectedTbl, count] = collectSelectedRows();
        if count == 0
            setStatus('No selected rows found for merge.');
            return;
        end
        app = app.fig.UserData;
        mergeTabName = sprintf('Merged_%d_rows', height(selectedTbl));
        tempPath = fullfile(app.outputFolder, [mergeTabName '.csv']);
        addTableAsTab(selectedTbl, tempPath);
        suggest = suggestMergedFilename(app.outputFolder);
        [file, pathName] = uiputfile({'*.csv','CSV Files (*.csv)'}, 'Save merged CSV', ...
            fullfile(app.outputFolder, suggest));
        if isequal(file,0)
            setStatus('Merge created as tab but save canceled.');
            return;
        end
        writetable(selectedTbl, fullfile(pathName, file));
        setStatus(sprintf('Merged %d selected row(s).', height(selectedTbl)));
    end

    function [selectedTbl, count] = collectSelectedRows()
        app = app.fig.UserData;
        tables = {};
        count = 0;
        for ii = 1:numel(app.loadedFiles)
            uit = app.loadedFiles(ii).uitable;
            if isempty(uit.Selection)
                continue;
            end
            rows = unique(uit.Selection(:,1));
            if isempty(rows)
                continue;
            end
            Ti = app.loadedFiles(ii).table(rows,:);
            tables{end+1} = Ti; %#ok<AGROW>
            count = count + numel(rows);
        end
        if isempty(tables)
            selectedTbl = table();
        else
            selectedTbl = vertcat(tables{:});
        end
    end

    function name = suggestMergedFilename(folderPath)
        k = 1;
        while true
            candidate = sprintf('selected_impulses_%d.csv', k);
            if ~exist(fullfile(folderPath, candidate), 'file')
                name = candidate;
                return;
            end
            k = k + 1;
        end
    end

    function onComputeNewImpulse()
        open_compute_dialog([], []);
    end

    function onVerifyAgainstEMTP()
        [tbl, rowIdx] = getSelectedRowTable();
        if ~isempty(tbl) && ~isempty(rowIdx)
            openVerification(tbl(rowIdx,:));
            return;
        end

        choice = uiconfirm(app.fig, ...
            'No impulse row is selected. Create a new impulse or load a saved parameter CSV first?', ...
            'EMTP Verification', ...
            'Options', {'Create New','Load Saved','Cancel'}, ...
            'DefaultOption', 1, 'CancelOption', 3);

        switch choice
            case 'Create New'
                open_compute_dialog([], @(newRow)openVerification(newRow));
            case 'Load Saved'
                loadSavedThenVerify();
            otherwise
                setStatus('EMTP verification canceled.');
        end
    end

    function openVerification(row)
        try
            verify_emtp_gui(row);
            setStatus('EMTP verification opened. Use Load EMTP CSV to import or change the file.');
        catch ME
            uialert(app.fig, ME.message, 'EMTP Verification Error');
        end
    end

    function loadSavedThenVerify()
        app = app.fig.UserData;
        [file, pathName] = uigetfile({'*.csv','CSV Files (*.csv)'}, 'Load saved impulse parameters');
        if isequal(file,0)
            setStatus('Load saved canceled.');
            return;
        end
        fp = fullfile(pathName, file);
        try
            T = readtable(fp, 'TextType', 'string');
            validateImpulseTable(T);
            if height(T) < 1
                error('Saved parameter CSV contains no rows.');
            end
            addTableAsTab(T, fp);
            refreshSelectionSummary();
            useRow = 1;
            if height(T) > 1
                labels = strings(height(T),1);
                for rr = 1:height(T)
                    labels(rr) = sprintf('%d | %s | T1=%g us | T2=%g us | Im=%g A', ...
                        rr, toText(getRowValue(T(rr,:),'name','-')), ...
                        getRowValue(T(rr,:),'T1_target_us',NaN), ...
                        getRowValue(T(rr,:),'T2_target_us',NaN), ...
                        getRowValue(T(rr,:),'Im_A',NaN));
                end
                [sel, ok] = listdlg('PromptString','Select the saved impulse row to verify:', ...
                    'SelectionMode','single', 'ListString', cellstr(labels), ...
                    'Name','Select Impulse Row', 'ListSize',[520 260]);
                if ~ok || isempty(sel)
                    setStatus('EMTP verification canceled after loading saved parameters.');
                    return;
                end
                useRow = sel;
            end
            verify_emtp_gui(T(useRow,:));
            setStatus('Saved impulse loaded; EMTP verification opened.');
        catch ME
            uialert(app.fig, ME.message, 'Load Saved Error');
        end
    end

    function open_compute_dialog(existingRow, afterComputeFcn)
        if nargin < 2
            afterComputeFcn = [];
        end
        dlg = uifigure('Name', 'Compute Impulse - Positive / Negative', 'Position', [200 100 560 590]);
        g = uigridlayout(dlg, [12 2]);
        g.RowHeight = repmat({36},1,12);
        g.ColumnWidth = {195, '1x'};

        defaults = getDefaults(existingRow);

        makeLabelEdit(g, 1, 'Target T1 (us)', defaults.T1_target_us, 'T1');
        makeLabelEdit(g, 2, 'Target T2 (us)', defaults.T2_target_us, 'T2');
        efIm = makeLabelEdit(g, 3, 'Signed peak current Im (A)', defaults.Im_A, 'Im');
        makeLabelEdit(g, 5, 'H input', defaults.H_input, 'H');
        makeLabelEdit(g, 6, 'n', defaults.n, 'n');
        makeLabelEdit(g, 7, 'Initial tau1 guess (us)', defaults.tau1_guess_us, 'tau1g');
        makeLabelEdit(g, 8, 'Initial tau2 guess (us)', defaults.tau2_guess_us, 'tau2g');
        makeLabelEdit(g, 9, 'Time step dt (s)', defaults.dt, 'dt');
        makeLabelEdit(g, 10, 'End time tend (s)', defaults.tend, 'tend');
        
        lblPolarity = uilabel(g, 'Text', 'Impulse polarity');
        lblPolarity.Layout.Row = 4;
        lblPolarity.Layout.Column = 1;
        ddPolarity = uidropdown(g, 'Items', {'Positive (+)', 'Negative (-)'}, ...
            'ItemsData', [1, -1], 'Value', sign(defaults.Im_A), 'Tag', 'ImpulsePolarity');
        ddPolarity.Layout.Row = 4;
        ddPolarity.Layout.Column = 2;
        efIm.ValueChangedFcn = @(~,~)syncPolarityFromCurrent();
        ddPolarity.ValueChangedFcn = @(~,~)syncCurrentFromPolarity();

        lblMode = uilabel(g, 'Text', 'H mode');
        lblMode.Layout.Row = 11;
        lblMode.Layout.Column = 1;
        
        ddMode = uidropdown(g, 'Items', {'FixedH','AutoH'}, 'Value', defaults.H_mode, 'Tag', 'H_mode');
        ddMode.Layout.Row = 11;
        ddMode.Layout.Column = 2;
        
        btnRun = uibutton(g, 'push', 'Text', 'Run Fit');
        btnRun.Layout.Row = 12; 
        btnRun.Layout.Column = 1;
        
        btnCancel = uibutton(g, 'push', 'Text', 'Cancel', 'ButtonPushedFcn', @(~,~)delete(dlg));
        btnCancel.Layout.Row = 12; 
        btnCancel.Layout.Column = 2;

        btnRun.ButtonPushedFcn = @(~,~)runFitFromDialog();

        function ef = makeLabelEdit(parent, rowNum, labelText, value, tag)
            lbl = uilabel(parent, 'Text', labelText);
            lbl.Layout.Row = rowNum;
            lbl.Layout.Column = 1;

            ef = uieditfield(parent, 'text', 'Value', num2str(value), 'Tag', tag);
            ef.Layout.Row = rowNum;
            ef.Layout.Column = 2;
        end

        function syncPolarityFromCurrent()
            currentValue = str2double(efIm.Value);
            if isreal(currentValue) && isfinite(currentValue) && currentValue ~= 0
                ddPolarity.Value = sign(currentValue);
            end
        end

        function syncCurrentFromPolarity()
            currentValue = str2double(efIm.Value);
            if isreal(currentValue) && isfinite(currentValue)
                efIm.Value = num2str(ddPolarity.Value * abs(currentValue), '%.15g');
            end
        end

        function defs = getDefaults(row)
            defs.T1_target_us = 1;
            defs.T2_target_us = 200;
            defs.Im_A = 100e3;
            defs.H_input = 0.93;
            defs.H_mode = 'FixedH';
            defs.n = 10;
            defs.tau1_guess_us = 5;
            defs.tau2_guess_us = 200;
            defs.dt = 1e-9;
            defs.tend = 500e-6;
        
            if ~isempty(row)
                defs.T1_target_us = getFieldOr(row,'T1_target_us',defs.T1_target_us);
                defs.T2_target_us = getFieldOr(row,'T2_target_us',defs.T2_target_us);
                defs.Im_A = getFieldOr(row,'Im_A',defs.Im_A);
                defs.H_input = getFieldOr(row,'H_input',getFieldOr(row,'H',defs.H_input));
                defs.H_mode = char(string(getFieldOr(row,'H_mode',defs.H_mode)));
                defs.n = getFieldOr(row,'n',defs.n);
                defs.tau1_guess_us = getFieldOr(row,'tau1_opt_us',getFieldOr(row,'tau1_guess_us',defs.tau1_guess_us));
                defs.tau2_guess_us = getFieldOr(row,'tau2_opt_us',getFieldOr(row,'tau2_guess_us',defs.tau2_guess_us));
            end
        end

        function v = getFieldOr(row, fieldName, fallback)
            if ismember(fieldName, row.Properties.VariableNames)
                v = row.(fieldName)(1);
            else
                v = fallback;
            end
        end

        function runFitFromDialog()
            edits = findall(dlg, 'Type', 'uieditfield');
            vals = struct();
            for kk = 1:numel(edits)
                vals.(edits(kk).Tag) = str2double(edits(kk).Value);
            end
        
            dd = findall(dlg, 'Type', 'uidropdown', 'Tag', 'H_mode');
            H_mode = dd.Value;
        
            if any(structfun(@(x) ~isreal(x) || isnan(x) || ~isfinite(x), vals))
                uialert(dlg, 'All numeric values must be finite real numbers.', 'Invalid Input');
                return;
            end
        
            if vals.Im == 0
                uialert(dlg, 'Im must be nonzero. Use a positive or negative current in A.', 'Invalid Current');
                return;
            end
            % The signed field is authoritative; the dropdown edits its sign.
            ddPolarity.Value = sign(vals.Im);

            try
                Trow = fit_heidler_impulse(vals.T1, vals.T2, vals.Im, vals.H, vals.n, ...
                    vals.tau1g, vals.tau2g, vals.dt, vals.tend, H_mode);
        
                app = app.fig.UserData;
                fname = buildSingleImpulseFilename(Trow);
                fpath = fullfile(app.outputFolder, fname);
                writetable(Trow, fpath);
        
                addTableAsTab(Trow, fpath);
                delete(dlg);
                open_impulse_details_gui(Trow);
                setStatus(['Computed and saved: ' fname]);
                if ~isempty(afterComputeFcn)
                    afterComputeFcn(Trow);
                end
            catch ME
                uialert(dlg, ME.message, 'Fit Error');
            end
        end
    end
end
