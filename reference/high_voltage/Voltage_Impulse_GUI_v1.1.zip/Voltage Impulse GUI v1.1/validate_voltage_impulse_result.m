function T = validate_voltage_impulse_result(exact, sampled, cfg, profile)
%VALIDATE_VOLTAGE_IMPULSE_RESULT Cross-check all supported definitions.
%   Returns a table suitable for the GUI. Required rows determine the
%   overall profile compliance result; informative rows are always shown.

    metric = strings(0,1); actual = []; target = []; deviation = [];
    tolerance = strings(0,1); status = strings(0,1); required = false(0,1);
    basis = strings(0,1);

    add('Peak voltage', sampled.Vpeak/1e3, cfg.Vp_kV, ...
        signedError(sampled.Vpeak/1e3,cfg.Vp_kV), sprintf('+/- %.3g %%',cfg.tolPeak_pct), ...
        abs(signedError(sampled.Vpeak/1e3,cfg.Vp_kV)) <= cfg.tolPeak_pct, true, 'Sampled waveform');

    % IEC T1 row
    tT1 = profile.expectedT1_us; reqT1 = strcmp(profile.requiredBasis,'T1_T2');
    if strcmp(profile.code,'CUSTOM') && strcmp(cfg.fitMethod,'IEC_T1_T2')
        tT1 = cfg.targetX_us; reqT1 = true;
    end
    if isfinite(tT1)
        e = signedError(exact.T1*1e6,tT1);
        if strcmp(profile.code,'CUSTOM')
            tm = cfg.tolX_pct; tp = cfg.tolX_pct;
        else
            tm = profile.tolT1_minus_pct; tp = profile.tolT1_plus_pct;
        end
        if isfinite(tm) && isfinite(tp)
            pass = e >= -tm && e <= tp;
            tol = sprintf('-%.3g/+%.3g %%',tm,tp);
        else
            pass = true; tol = 'informative';
        end
    else
        e=NaN; pass=true; tol='informative';
    end
    add('IEC front time T1 (30%-90%)',exact.T1*1e6,tT1,e,tol,pass,reqT1,'Analytic geometry');

    % Virtual-origin T2 row
    tT2 = profile.expectedT2_us;
    if strcmp(profile.code,'CUSTOM'), tT2 = cfg.targetY_us; end
    if isfinite(tT2)
        e=signedError(exact.T2*1e6,tT2);
        if strcmp(profile.code,'CUSTOM'), tolY=cfg.tolY_pct; else, tolY=profile.tolT2_pct; end
        pass=abs(e)<=tolY; tol=sprintf('+/- %.3g %%',tolY);
    else
        e=NaN; pass=true; tol='informative';
    end
    reqVirtualT2 = strcmp(profile.requiredBasis,'T1_T2') || ...
        (strcmp(profile.code,'CUSTOM') && strcmp(cfg.fitMethod,'IEC_T1_T2'));
    add('Time to half-value T2 from O1',exact.T2*1e6,tT2,e,tol,pass,reqVirtualT2,'Analytic geometry');

    % Legacy actual-origin peak time and current virtual-origin diagnostic
    tTp = profile.expectedTp_us; reqTp = strcmp(profile.requiredBasis,'TP_T2');
    if strcmp(profile.code,'CUSTOM') && strcmp(cfg.fitMethod,'TP_T2')
        tTp=cfg.targetX_us; reqTp=true;
    end
    if isfinite(tTp)
        e=signedError(exact.t_peak*1e6,tTp);
        if strcmp(profile.code,'CUSTOM'), tolP=cfg.tolX_pct; else, tolP=profile.tolTp_pct; end
        pass=abs(e)<=tolP; tol=sprintf('+/- %.3g %%',tolP);
    else
        e=NaN; pass=true; tol='informative';
    end
    add('Legacy peak time Tp from t=0',exact.t_peak*1e6,tTp,e,tol,pass,reqTp,'Peak of analytic curve');

    add('Peak time measured from O1',exact.Tp_virtual*1e6,NaN,NaN, ...
        'informative',true,false,'Current virtual-origin diagnostic');

    add('IEC 2025 Annex F estimated Tp',exact.Tp_annexF*1e6,tTp, ...
        errorOrNaN(exact.Tp_annexF*1e6,tTp),'informative',true,false,'Switching-impulse compatibility');

    % Engineering basis rows
    tRise=NaN; tTail=NaN; reqEng=false;
    if strcmp(profile.code,'CUSTOM') && strcmp(cfg.fitMethod,'T10_90_T50')
        tRise=cfg.targetX_us; tTail=cfg.targetY_us; reqEng=true;
    end
    add('Engineering rise t10-90',exact.t10_90*1e6,tRise, ...
        errorOrNaN(exact.t10_90*1e6,tRise),customTol(tRise,cfg.tolX_pct), ...
        passOrTrue(exact.t10_90*1e6,tRise,cfg.tolX_pct),reqEng,'Non-standard diagnostic');
    legacyTailTarget=NaN; reqLegacyTail=false; legacyTailTol=cfg.tolY_pct;
    if strcmp(profile.requiredBasis,'TP_T2')
        legacyTailTarget=profile.expectedT2_us; reqLegacyTail=true; legacyTailTol=profile.tolT2_pct;
    elseif strcmp(profile.code,'CUSTOM') && strcmp(cfg.fitMethod,'TP_T2')
        legacyTailTarget=cfg.targetY_us; reqLegacyTail=true;
    elseif reqEng
        legacyTailTarget=tTail;
    end
    add('Tail crossing t50 from t=0',exact.t50_actual*1e6,legacyTailTarget, ...
        errorOrNaN(exact.t50_actual*1e6,legacyTailTarget),customTol(legacyTailTarget,legacyTailTol), ...
        passOrTrue(exact.t50_actual*1e6,legacyTailTarget,legacyTailTol),reqLegacyTail||reqEng,'Actual-origin diagnostic');

    % Independent sampled checks
    add('Sampled-versus-analytic T1',sampled.T1*1e6,exact.T1*1e6, ...
        signedError(sampled.T1,exact.T1),'+/- 0.1 %', ...
        abs(signedError(sampled.T1,exact.T1))<=0.1,true,'Independent sampled check');
    add('Sampled-versus-analytic T2',sampled.T2*1e6,exact.T2*1e6, ...
        signedError(sampled.T2,exact.T2),'+/- 0.1 %', ...
        abs(signedError(sampled.T2,exact.T2))<=0.1,true,'Independent sampled check');

    if isfinite(profile.overshootMax_pct)
        add('Relative overshoot',0,profile.overshootMax_pct,NaN, ...
            sprintf('<= %.3g %%',profile.overshootMax_pct),true,true,'Smooth double exponential');
    else
        add('Relative overshoot',0,NaN,NaN,'informative',true,false,'Smooth double exponential');
    end

    T = table(metric,actual,target,deviation,tolerance,status,required,basis, ...
        'VariableNames',{'Metric','Actual','Target','Deviation_pct','Tolerance','Status','Required','Basis'});

    function add(m,a,t,e,tol,pass,req,b)
        metric(end+1,1)=string(m); actual(end+1,1)=a; target(end+1,1)=t;
        deviation(end+1,1)=e; tolerance(end+1,1)=string(tol);
        if req
            if pass, status(end+1,1)="PASS"; else, status(end+1,1)="FAIL"; end
        else
            status(end+1,1)="INFO";
        end
        required(end+1,1)=req; basis(end+1,1)=string(b);
    end
end

function e = signedError(a,t)
    e=100*(a-t)/t;
end
function e = errorOrNaN(a,t)
    if isfinite(t), e=signedError(a,t); else, e=NaN; end
end
function s = customTol(t,tol)
    if isfinite(t), s=sprintf('+/- %.3g %%',tol); else, s='informative'; end
end
function p = passOrTrue(a,t,tol)
    if isfinite(t), p=abs(signedError(a,t))<=tol; else, p=true; end
end
