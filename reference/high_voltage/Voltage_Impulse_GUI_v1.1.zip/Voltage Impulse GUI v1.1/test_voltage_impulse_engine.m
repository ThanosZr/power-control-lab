function test_voltage_impulse_engine()
%TEST_VOLTAGE_IMPULSE_ENGINE Regression tests for the numerical core.

    cases = { ...
        struct('code','IEC2025_LI','method','IEC_T1_T2','x',1.2,'y',50,'dt',1e-9,'tend',100e-6), ...
        struct('code','IEC2025_SI','method','IEC_T1_T2','x',170,'y',2500,'dt',100e-9,'tend',5e-3), ...
        struct('code','IEC2010_SI_LEGACY','method','TP_T2','x',250,'y',2500,'dt',100e-9,'tend',5e-3), ...
        struct('code','CUSTOM','method','IEC_T1_T2','x',10,'y',700,'dt',10e-9,'tend',1.5e-3)};

    for k=1:numel(cases)
        q=cases{k};
        cfg=struct('targetX_us',q.x,'targetY_us',q.y,'Vp_kV',100, ...
            'polarity',1,'fitMethod',q.method,'standardCode',q.code, ...
            'alphaGuess',NaN,'betaGuess',NaN,'dt',q.dt,'tend',q.tend, ...
            'tolPeak_pct',3,'tolX_pct',30,'tolY_pct',20);
        [T,V]=fit_voltage_impulse(cfg);
        assert(abs(T.selected_X_err_pct(1))<1e-4,'Selected X fit failed.');
        assert(abs(T.selected_Y_err_pct(1))<1e-4,'Selected Y fit failed.');
        assert(abs(T.analytic_sample_T1_diff_pct(1))<0.1,'Sampled T1 check failed.');
        assert(abs(T.analytic_sample_T2_diff_pct(1))<0.1,'Sampled T2 check failed.');
        assert(all(V.Status(V.Required)=="PASS"),'Required validation row failed.');
    end

    % Known 1.2/50-us coefficient neighborhood for the exact IEC geometry.
    cfg=struct('targetX_us',1.2,'targetY_us',50,'Vp_kV',100,'polarity',1, ...
        'fitMethod','IEC_T1_T2','standardCode','IEC2025_LI','dt',1e-9,'tend',100e-6);
    T=fit_voltage_impulse(cfg);
    assert(abs(T.alpha_s_inv(1)-1.46591e4)/1.46591e4<5e-4,'Unexpected alpha.');
    assert(abs(T.beta_s_inv(1)-2.46893e6)/2.46893e6<5e-4,'Unexpected beta.');

    fprintf('All voltage-impulse engine tests passed.\n');
end
