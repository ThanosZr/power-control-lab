function fname = buildSingleVoltageImpulseFilename(Trow)
%BUILDSINGLEVOLTAGEIMPULSEFILENAME Build a filesystem-safe CSV name.
    Vp = Trow.Vp_target_kV(1);
    x = Trow.target_X_us(1);
    y = Trow.target_Y_us(1);
    method = char(Trow.fit_method(1));
    fname = sprintf('V_%s_kV_X_%s_Y_%s_%s.csv', ...
        clean(Vp),clean(x),clean(y),method);
end
function s=clean(x)
    s=strrep(sprintf('%.6g',x),'.','p');
    s=strrep(s,'+',''); s=strrep(s,'-','m');
end
