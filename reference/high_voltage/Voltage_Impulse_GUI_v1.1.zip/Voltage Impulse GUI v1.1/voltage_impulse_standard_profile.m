function p = voltage_impulse_standard_profile(code)
%VOLTAGE_IMPULSE_STANDARD_PROFILE Standard presets and tolerances.
%   The current IEC 60060-1:2025 switching impulse is 170/2500 us using
%   the 30%-90% front-time definition. The 250/2500 us profile is retained
%   as a legacy peak-time compatibility option.

    code = upper(char(string(code)));
    p = struct('code',code, 'display','', 'defaultMethod','IEC_T1_T2', ...
        'targetX_us',1.2, 'targetY_us',50, 'expectedT1_us',NaN, ...
        'expectedTp_us',NaN, 'expectedT2_us',NaN, ...
        'tolPeak_pct',3, 'tolT1_minus_pct',NaN, 'tolT1_plus_pct',NaN, ...
        'tolTp_pct',NaN, 'tolT2_pct',NaN, 'overshootMax_pct',NaN, ...
        'requiredBasis','CUSTOM', 'note','');

    switch code
        case 'IEC2025_LI'
            p.display = 'IEC 60060-1:2025 full lightning impulse 1.2/50 us';
            p.defaultMethod = 'IEC_T1_T2';
            p.targetX_us = 1.2; p.targetY_us = 50;
            p.expectedT1_us = 1.2; p.expectedT2_us = 50;
            p.tolT1_minus_pct = 30; p.tolT1_plus_pct = 30;
            p.tolT2_pct = 20; p.overshootMax_pct = 10;
            p.requiredBasis = 'T1_T2';
            p.note = 'Current standard LI: T1 by 30%-90% virtual-front geometry.';

        case 'IEC2025_SI'
            p.display = 'IEC 60060-1:2025 switching impulse 170/2500 us';
            p.defaultMethod = 'IEC_T1_T2';
            p.targetX_us = 170; p.targetY_us = 2500;
            p.expectedT1_us = 170; p.expectedTp_us = 250;
            p.expectedT2_us = 2500;
            p.tolT1_minus_pct = 20; p.tolT1_plus_pct = 20;
            p.tolTp_pct = 20; p.tolT2_pct = 60;
            p.requiredBasis = 'T1_T2';
            p.note = 'Current standard SI. Tp is retained as an informative compatibility metric.';

        case 'IEC2010_SI_LEGACY'
            p.display = 'Legacy switching impulse 250/2500 us (Tp/T2)';
            p.defaultMethod = 'TP_T2';
            p.targetX_us = 250; p.targetY_us = 2500;
            p.expectedT1_us = 165; p.expectedTp_us = 250;
            p.expectedT2_us = 2500;
            p.tolTp_pct = 20; p.tolT2_pct = 60;
            p.requiredBasis = 'TP_T2';
            p.note = 'Compatibility profile for the deprecated time-to-peak convention.';

        otherwise
            p.code = 'CUSTOM';
            p.display = 'Custom smooth double-exponential impulse';
            p.defaultMethod = 'IEC_T1_T2';
            p.requiredBasis = 'CUSTOM';
            p.note = 'User targets and symmetric tolerances are applied to the selected fitting basis.';
    end
end
