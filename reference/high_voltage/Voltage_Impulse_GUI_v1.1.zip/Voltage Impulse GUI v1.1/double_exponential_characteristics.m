function c = double_exponential_characteristics(alpha, beta)
%DOUBLE_EXPONENTIAL_CHARACTERISTICS Exact metrics of a smooth impulse.
%   Metrics follow IEC 60060-1:2025 voltage-impulse geometry:
%     T1 = (t90-t30)/0.6
%     O1 = t30 - 0.5*(t90-t30)
%     T2 = t50,tail - O1
%
%   Additional metrics are returned so every supported fitting basis can
%   be checked after optimization.

    if alpha <= 0 || beta <= alpha || ~isfinite(alpha) || ~isfinite(beta)
        error('Require finite beta > alpha > 0.');
    end

    raw = @(t) exp(-alpha .* t) - exp(-beta .* t);
    c.t_peak = log(beta / alpha) / (beta - alpha);
    c.peak_raw = raw(c.t_peak);
    c.K = 1 / c.peak_raw;
    normalized = @(t) raw(t) / c.peak_raw;

    c.t10 = risingCrossing(normalized, 0.10, c.t_peak);
    c.t30 = risingCrossing(normalized, 0.30, c.t_peak);
    c.t90 = risingCrossing(normalized, 0.90, c.t_peak);
    c.t50_tail = fallingCrossing(normalized, 0.50, c.t_peak, alpha);

    c.TAB = c.t90 - c.t30;
    c.T1 = c.TAB / 0.6;
    c.virtual_origin = c.t30 - 0.5 * c.TAB;
    c.T2 = c.t50_tail - c.virtual_origin;

    c.Tp_virtual = c.t_peak - c.virtual_origin;
    c.t10_90 = c.t90 - c.t10;
    c.t50_actual = c.t50_tail;

    % IEC 60060-1:2025 Annex F compatibility estimate for switching
    % impulses. TAB and T2 are inserted in microseconds.
    TAB_us = c.TAB * 1e6;
    T2_us = c.T2 * 1e6;
    annexK = 2.42 - 3.08e-3 * TAB_us + 1.51e-4 * T2_us;
    c.Tp_annexF = annexK * TAB_us * 1e-6;

    % Integral of the normalized smooth impulse in seconds.
    c.normalized_area = c.K * (1 / alpha - 1 / beta);
end

function tc = risingCrossing(fun, level, tPeak)
    tc = fzero(@(t) fun(t) - level, [0, tPeak]);
end

function tc = fallingCrossing(fun, level, tPeak, alpha)
    hi = max(2 * tPeak, 2 / alpha);
    while fun(hi) > level
        hi = 2 * hi;
        if hi > 1e6 / alpha
            error('Could not bracket falling-edge crossing.');
        end
    end
    tc = fzero(@(t) fun(t) - level, [tPeak, hi]);
end
