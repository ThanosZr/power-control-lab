function voltage_impulse_manager_gui()
%VOLTAGE_IMPULSE_MANAGER_GUI Manage smooth double-exponential impulses.
%   Computes alpha/beta using selectable definitions and validates every
%   result using all supported waveform-characterization routes.

    app=struct();
    app.loadedFiles=struct('filePath',{},'table',{},'tab',{},'uitable',{});
    app.outputFolder=fullfile(pwd,'voltage_impulse_params');
    if ~exist(app.outputFolder,'dir'), mkdir(app.outputFolder); end

    app.fig=uifigure('Name','Voltage Impulse Parameter Manager','Position',[70 60 1500 850]);
    main=uigridlayout(app.fig,[3 1]); main.RowHeight={72,'1x',38}; main.Padding=[8 8 8 8];

    top=uipanel(main,'Title','Controls'); top.Layout.Row=1;
    tg=uigridlayout(top,[1 9]); tg.ColumnWidth={125,160,140,145,160,150,165,'1x',120};
    uibutton(tg,'Text','Load CSV(s)','ButtonPushedFcn',@(~,~)loadCSVs());
    uibutton(tg,'Text','Compute New Impulse','ButtonPushedFcn',@(~,~)computeDialog([],[]));
    uibutton(tg,'Text','Open Details','ButtonPushedFcn',@(~,~)openDetails());
    uibutton(tg,'Text','Recompute','ButtonPushedFcn',@(~,~)recomputeSelected());
    uibutton(tg,'Text','Merge Selected','ButtonPushedFcn',@(~,~)mergeSelected());
    uibutton(tg,'Text','Save Selected','ButtonPushedFcn',@(~,~)saveSelected());
    uibutton(tg,'Text','Verify against EMTP','ButtonPushedFcn',@(~,~)verifyAgainstEMTP());
    app.info=uilabel(tg,'Text','Compute a new smooth voltage impulse or load previous CSV results.');
    uibutton(tg,'Text','Close Tab','ButtonPushedFcn',@(~,~)closeCurrentTab());

    center=uigridlayout(main,[1 2]); center.Layout.Row=2; center.ColumnWidth={'3.2x','1.15x'};
    app.tabs=uitabgroup(center,'SelectionChangedFcn',@(~,~)refreshSummary());
    side=uipanel(center,'Title','Selected voltage impulse');
    sg=uigridlayout(side,[8 1]); sg.RowHeight={24,88,24,180,36,36,'1x',30};
    uilabel(sg,'Text','File / tab');
    app.currentFile=uitextarea(sg,'Editable','off','Value',{'-'});
    uilabel(sg,'Text','Selected result');
    app.summary=uitextarea(sg,'Editable','off','Value',{'No selection'});
    uibutton(sg,'Text','Open complete validation','ButtonPushedFcn',@(~,~)openDetails());
    uibutton(sg,'Text','Remove selected row(s)','ButtonPushedFcn',@(~,~)removeRows());
    app.hint=uitextarea(sg,'Editable','off','Value',{ ...
        'Fit routes:'; ...
        '• IEC T1/T2: 30%-90%, virtual origin O1.'; ...
        '• Tp/t50 from t=0: legacy switching-impulse compatibility.'; ...
        '• t10-90/t50: engineering diagnostic.'; ...
        ' '; ...
        'Final validation always evaluates every route and an independent sampled waveform.'});
    uilabel(sg,'Text','');

    app.status=uilabel(main,'Text','Ready.'); app.status.Layout.Row=3;
    app.fig.UserData=app;

    function setStatus(s)
        app=app.fig.UserData; app.status.Text=s; app.info.Text=s; app.fig.UserData=app;
    end

    function idx=currentIndex()
        app=app.fig.UserData; idx=[];
        if isempty(app.loadedFiles), return; end
        tab=app.tabs.SelectedTab;
        for k=1:numel(app.loadedFiles)
            if isequal(app.loadedFiles(k).tab,tab), idx=k; return; end
        end
    end

    function [T,r]=selectedRow()
        T=[]; r=[]; app=app.fig.UserData; idx=currentIndex();
        if isempty(idx), return; end
        sel=app.loadedFiles(idx).uitable.Selection;
        if isempty(sel), return; end
        r=sel(1,1); T=app.loadedFiles(idx).table;
    end

    function refreshSummary()
        app=app.fig.UserData; idx=currentIndex();
        if isempty(idx)
            app.currentFile.Value={'-'}; app.summary.Value={'No tab selected'};
            app.fig.UserData=app; return;
        end
        app.currentFile.Value={app.loadedFiles(idx).filePath};
        sel=app.loadedFiles(idx).uitable.Selection;
        if isempty(sel)
            app.summary.Value={'Select a row to view its parameters.'};
        else
            row=app.loadedFiles(idx).table(sel(1,1),:);
            app.summary.Value=rowSummary(row);
        end
        app.fig.UserData=app;
    end

    function out=rowSummary(row)
        out={sprintf('Name: %s',textVal(getVal(row,'name','-'))), ...
            sprintf('Standard: %s',textVal(getVal(row,'standard_code','-'))), ...
            sprintf('Method: %s',textVal(getVal(row,'fit_method','-'))), ...
            sprintf('Peak: %.8g kV',getVal(row,'Vpeak_calc_kV',NaN)), ...
            sprintf('alpha: %.8g s^-1',getVal(row,'alpha_s_inv',NaN)), ...
            sprintf('beta: %.8g s^-1',getVal(row,'beta_s_inv',NaN)), ...
            sprintf('IEC T1/T2: %.8g / %.8g us',getVal(row,'T1_IEC_us',NaN),getVal(row,'T2_IEC_us',NaN)), ...
            sprintf('Tp: %.8g us',getVal(row,'Tp_virtual_us',NaN)), ...
            sprintf('Selected errors X/Y: %+.4g%% / %+.4g%%', ...
                getVal(row,'selected_X_err_pct',NaN),getVal(row,'selected_Y_err_pct',NaN)), ...
            sprintf('Overall: %s',passText(getVal(row,'overall_pass',false)))};
    end

    function addTab(T,filePath)
        app=app.fig.UserData; [~,base,ext]=fileparts(filePath);
        tab=uitab(app.tabs,'Title',[base ext]); g=uigridlayout(tab,[2 1]); g.RowHeight={'1x',30};
        uit=uitable(g,'Data',T,'ColumnSortable',true,'Multiselect','on', ...
            'CellSelectionCallback',@(~,~)refreshSummary());
        bg=uigridlayout(g,[1 3]); bg.ColumnWidth={170,170,'1x'};
        uibutton(bg,'Text','Open Details','ButtonPushedFcn',@(~,~)openDetails());
        uibutton(bg,'Text','Close This Tab','ButtonPushedFcn',@(~,~)closeSpecific(tab));
        uilabel(bg,'Text',filePath);
        e=struct('filePath',filePath,'table',T,'tab',tab,'uitable',uit);
        app.loadedFiles(end+1)=e; app.tabs.SelectedTab=tab; app.fig.UserData=app;
    end

    function loadCSVs()
        app=app.fig.UserData;
        [files,path]=uigetfile({'*.csv','CSV files'},'Select voltage-impulse results','MultiSelect','on');
        if isequal(files,0), setStatus('Load canceled.'); return; end
        if ischar(files)||isstring(files), files={files}; end
        for k=1:numel(files)
            fp=fullfile(path,files{k});
            try
                T=readtable(fp,'TextType','string'); validateTable(T); addTab(T,fp);
            catch ME
                uialert(app.fig,sprintf('Could not load %s\n\n%s',files{k},ME.message),'Load error');
            end
        end
        refreshSummary(); setStatus('CSV file(s) loaded.');
    end

    function validateTable(T)
        req={'name','alpha_s_inv','beta_s_inv','T1_IEC_us','T2_IEC_us'};
        for k=1:numel(req)
            if ~ismember(req{k},T.Properties.VariableNames), error('Missing required column: %s',req{k}); end
        end
    end

    function openDetails()
        [T,r]=selectedRow();
        if isempty(T), setStatus('Select one result first.'); return; end
        open_voltage_impulse_details_gui(T(r,:)); setStatus('Details and validation opened.');
    end

    function recomputeSelected()
        [T,r]=selectedRow();
        if isempty(T), setStatus('Select one result first.'); return; end
        computeDialog(T(r,:),[]);
    end

    function verifyAgainstEMTP()
        [T,r]=selectedRow();
        if ~isempty(T)
            open_voltage_impulse_verification_gui(T(r,:));
            setStatus('EMTP verification opened for the selected result.');
            return;
        end

        app=app.fig.UserData;
        choice=uiconfirm(app.fig, ...
            ['No voltage-impulse result is selected. Create a new result ' ...
             'or load a saved parameter CSV first.'], ...
            'Select voltage impulse', ...
            'Options',{'Create New','Load Saved','Cancel'}, ...
            'DefaultOption',1,'CancelOption',3);
        switch choice
            case 'Create New'
                computeDialog([],@(row)open_voltage_impulse_verification_gui(row));
            case 'Load Saved'
                loadParameterForVerification();
            otherwise
                setStatus('Verification canceled.');
        end
    end

    function loadParameterForVerification()
        app=app.fig.UserData;
        [file,path]=uigetfile({'*.csv','CSV files'}, ...
            'Select saved voltage-impulse parameters',app.outputFolder);
        if isequal(file,0),setStatus('Verification canceled.');return;end
        fp=fullfile(path,file);
        try
            T=readtable(fp,'TextType','string');
            validateTable(T);
            if isempty(T),error('The selected parameter file contains no rows.');end
            addTab(T,fp);
            if height(T)==1
                open_voltage_impulse_verification_gui(T(1,:));
            else
                chooseVerificationRow(T,fp);
            end
            setStatus('Saved voltage-impulse parameters loaded for verification.');
        catch ME
            uialert(app.fig,sprintf('Could not load %s\n\n%s',file,ME.message), ...
                'Load error');
        end
    end

    function chooseVerificationRow(T,filePath)
        dlg=uifigure('Name','Select voltage impulse for EMTP verification', ...
            'Position',[170 120 1180 560],'WindowStyle','modal');
        g=uigridlayout(dlg,[3 1]);
        g.RowHeight={32,'1x',42}; g.Padding=[8 8 8 8];
        uilabel(g,'Text',sprintf('%s contains %d results. Select one cell in the required row.', ...
            filePath,height(T)));
        uit=uitable(g,'Data',T,'Multiselect','off');
        actions=uigridlayout(g,[1 2]); actions.ColumnWidth={'1x','1x'};
        uibutton(actions,'Text','Continue with selected row', ...
            'ButtonPushedFcn',@(~,~)continueWithRow());
        uibutton(actions,'Text','Cancel','ButtonPushedFcn',@(~,~)delete(dlg));

        function continueWithRow()
            selection=uit.Selection;
            if isempty(selection)
                uialert(dlg,'Select one cell in the required result row.','No row selected');
                return;
            end
            selected=T(selection(1,1),:);
            delete(dlg);
            open_voltage_impulse_verification_gui(selected);
        end
    end

    function removeRows()
        app=app.fig.UserData; idx=currentIndex(); if isempty(idx),return;end
        sel=app.loadedFiles(idx).uitable.Selection;
        if isempty(sel),setStatus('Select row(s) to remove.');return;end
        rows=unique(sel(:,1)); T=app.loadedFiles(idx).table; T(rows,:)=[];
        app.loadedFiles(idx).table=T; app.loadedFiles(idx).uitable.Data=T;
        app.loadedFiles(idx).uitable.Selection=[]; app.fig.UserData=app;
        refreshSummary(); setStatus('Selected row(s) removed from the tab.');
    end

    function closeCurrentTab()
        idx=currentIndex(); if isempty(idx),setStatus('No active tab.');return;end
        app=app.fig.UserData; closeSpecific(app.loadedFiles(idx).tab);
    end

    function closeSpecific(tab)
        app=app.fig.UserData; idx=[];
        for k=1:numel(app.loadedFiles)
            if isequal(app.loadedFiles(k).tab,tab),idx=k;break;end
        end
        if isempty(idx),return;end
        delete(app.loadedFiles(idx).tab); app.loadedFiles(idx)=[]; app.fig.UserData=app;
        refreshSummary(); setStatus('Tab closed.');
    end

    function [Tout,count]=collectRows()
        app=app.fig.UserData; parts={}; count=0;
        for k=1:numel(app.loadedFiles)
            sel=app.loadedFiles(k).uitable.Selection; if isempty(sel),continue;end
            rows=unique(sel(:,1)); parts{end+1}=app.loadedFiles(k).table(rows,:); %#ok<AGROW>
            count=count+numel(rows);
        end
        if isempty(parts),Tout=table();else,Tout=vertcat(parts{:});end
    end

    function saveSelected()
        [T,n]=collectRows(); if n==0,setStatus('No rows selected.');return;end
        [f,p]=uiputfile({'*.csv','CSV files'},'Save selected results', ...
            fullfile(app.outputFolder,'selected_voltage_impulses.csv'));
        if isequal(f,0),setStatus('Save canceled.');return;end
        writetable(T,fullfile(p,f)); setStatus(sprintf('Saved %d row(s).',height(T)));
    end

    function mergeSelected()
        [T,n]=collectRows(); if n==0,setStatus('No rows selected.');return;end
        app=app.fig.UserData; temp=fullfile(app.outputFolder,sprintf('Merged_%d_rows.csv',height(T)));
        addTab(T,temp);
        [f,p]=uiputfile({'*.csv','CSV files'},'Save merged results',temp);
        if isequal(f,0),setStatus('Merged tab created; save canceled.');return;end
        writetable(T,fullfile(p,f));setStatus(sprintf('Merged %d row(s).',height(T)));
    end

    function computeDialog(existingRow,afterCompute)
        screenSize=get(groot,'ScreenSize');
        dlgWidth=min(660,max(420,screenSize(3)-80));
        dlgHeight=min(760,max(480,screenSize(4)-120));
        dlgX=round(screenSize(1)+(screenSize(3)-dlgWidth)/2);
        dlgY=round(screenSize(2)+(screenSize(4)-dlgHeight)/2);
        dlg=uifigure('Name','Compute voltage impulse', ...
            'Position',[dlgX dlgY dlgWidth dlgHeight],'Resize','on');

        outer=uigridlayout(dlg,[2 1]);
        outer.RowHeight={'1x',48}; outer.ColumnWidth={'1x'};
        outer.Padding=[8 8 8 8]; outer.RowSpacing=8;

        g=uigridlayout(outer,[15 2]); g.Layout.Row=1;
        g.RowHeight=[repmat({36},1,14),{90}];
        g.ColumnWidth={245,'1x'}; g.Padding=[10 10 10 10];
        g.RowSpacing=4; g.Scrollable='on';
        d=defaultsFrom(existingRow);

        label(g,1,'Standard profile');
        ddProfile=uidropdown(g,'Items',{'IEC 2025 lightning 1.2/50','IEC 2025 switching 170/2500', ...
            'Legacy switching 250/2500 (Tp)','Custom'}, ...
            'ItemsData',{'IEC2025_LI','IEC2025_SI','IEC2010_SI_LEGACY','CUSTOM'}, ...
            'Value',d.standardCode); place(ddProfile,1);
        label(g,2,'Alpha/beta fitting basis');
        ddMethod=uidropdown(g,'Items',{'IEC T1/T2 (30%-90%, O1)','Peak Tp/t50 from t=0 (legacy SI)', ...
            'Engineering t10-90/t50'},'ItemsData',{'IEC_T1_T2','TP_T2','T10_90_T50'}, ...
            'Value',d.fitMethod); place(ddMethod,2);

        lblX=label(g,3,'Target X [us]'); efX=num(g,3,d.targetX);
        lblY=label(g,4,'Target Y [us]'); efY=num(g,4,d.targetY);
        label(g,5,'Target peak voltage [kV]'); efVp=num(g,5,d.Vp);
        label(g,6,'Polarity'); ddPol=uidropdown(g,'Items',{'Positive','Negative'}, ...
            'ItemsData',[1 -1],'Value',d.polarity); place(ddPol,6);
        label(g,7,'Initial alpha guess [s^-1], 0 = auto'); efA=num(g,7,d.alpha);
        label(g,8,'Initial beta guess [s^-1], 0 = auto'); efB=num(g,8,d.beta);
        label(g,9,'Sampling dt [s]'); efDt=num(g,9,d.dt);
        label(g,10,'Simulation end time [s]'); efEnd=num(g,10,d.tend);
        label(g,11,'Peak tolerance [%]'); efTolP=num(g,11,d.tolPeak);
        label(g,12,'X tolerance [%]'); efTolX=num(g,12,d.tolX);
        label(g,13,'Y tolerance [%]'); efTolY=num(g,13,d.tolY);
        label(g,14,'Current standard note');
        note=uitextarea(g,'Editable','off'); note.Layout.Row=[14 15]; note.Layout.Column=2;

        actions=uigridlayout(outer,[1 2]); actions.Layout.Row=2;
        actions.ColumnWidth={'1x','1x'}; actions.Padding=[0 0 0 0];
        uibutton(actions,'Text','Compute alpha/beta and validate', ...
            'ButtonPushedFcn',@(~,~)run());
        uibutton(actions,'Text','Cancel','ButtonPushedFcn',@(~,~)delete(dlg));

        ddProfile.ValueChangedFcn=@(~,~)profileChanged();
        ddMethod.ValueChangedFcn=@(~,~)methodChanged();
        methodChanged(); updateNote();

        function profileChanged()
            p=voltage_impulse_standard_profile(ddProfile.Value);
            efX.Value=p.targetX_us; efY.Value=p.targetY_us; ddMethod.Value=p.defaultMethod;
            efTolP.Value=p.tolPeak_pct;
            if isfinite(p.tolT1_plus_pct),efTolX.Value=p.tolT1_plus_pct;elseif isfinite(p.tolTp_pct),efTolX.Value=p.tolTp_pct;end
            if isfinite(p.tolT2_pct),efTolY.Value=p.tolT2_pct;end
            if strcmp(p.code,'IEC2025_LI'),efDt.Value=1e-9;efEnd.Value=100e-6;
            elseif ~strcmp(p.code,'CUSTOM'),efDt.Value=100e-9;efEnd.Value=5e-3;end
            methodChanged(); updateNote();
        end
        function methodChanged()
            switch ddMethod.Value
                case 'IEC_T1_T2',lblX.Text='Target IEC T1 [us]';lblY.Text='Target T2 from O1 [us]';
                case 'TP_T2',lblX.Text='Target legacy Tp from t=0 [us]';lblY.Text='Target legacy t50 from t=0 [us]';
                otherwise,lblX.Text='Target rise t10-90 [us]';lblY.Text='Target tail t50 from t=0 [us]';
            end
        end
        function updateNote()
            p=voltage_impulse_standard_profile(ddProfile.Value);
            note.Value={p.display;p.note; ...
                'Use the Custom profile when X/Y are not the nominal values of the selected standard.'; ...
                'The final report always includes IEC T1/T2, actual Tp, Annex-F Tp, t10-90/t50 and sampled-waveform checks.'};
        end
        function run()
            vals=[efX.Value efY.Value efVp.Value efDt.Value efEnd.Value efTolP.Value efTolX.Value efTolY.Value];
            if any(~isfinite(vals))||any(vals<=0),uialert(dlg,'All targets, times and tolerances must be positive.','Invalid input');return;end
            if xor(efA.Value==0,efB.Value==0),uialert(dlg,'Set both alpha and beta guesses to zero, or provide both.','Invalid guesses');return;end
            cfg=struct('targetX_us',efX.Value,'targetY_us',efY.Value,'Vp_kV',efVp.Value, ...
                'polarity',ddPol.Value,'fitMethod',ddMethod.Value,'standardCode',ddProfile.Value, ...
                'alphaGuess',efA.Value,'betaGuess',efB.Value,'dt',efDt.Value,'tend',efEnd.Value, ...
                'tolPeak_pct',efTolP.Value,'tolX_pct',efTolX.Value,'tolY_pct',efTolY.Value);
            if cfg.alphaGuess==0,cfg.alphaGuess=NaN;cfg.betaGuess=NaN;end
            try
                [Trow,~]=fit_voltage_impulse(cfg); app=app.fig.UserData;
                fname=buildSingleVoltageImpulseFilename(Trow); fp=fullfile(app.outputFolder,fname);
                writetable(Trow,fp); addTab(Trow,fp);
                if isempty(afterCompute)
                    open_voltage_impulse_details_gui(Trow);
                else
                    afterCompute(Trow);
                end
                setStatus(['Computed and saved: ' fname]);
                if isvalid(dlg), delete(dlg); end
            catch ME
                errorText=getReport(ME,'extended','hyperlinks','off');
                if isvalid(dlg)
                    uialert(dlg,errorText,'Calculation error');
                else
                    mainApp=app.fig.UserData;
                    if isvalid(mainApp.fig)
                        uialert(mainApp.fig,errorText,'Calculation error');
                    else
                        rethrow(ME);
                    end
                end
            end
        end
        function h=label(parent,rowNum,txt)
            h=uilabel(parent,'Text',txt);h.Layout.Row=rowNum;h.Layout.Column=1;
        end
        function h=num(parent,rowNum,val)
            h=uieditfield(parent,'numeric','Value',val);h.Layout.Row=rowNum;h.Layout.Column=2;
        end
        function place(h,rowNum),h.Layout.Row=rowNum;h.Layout.Column=2;end
    end

    function d=defaultsFrom(row)
        d=struct('standardCode','IEC2025_LI','fitMethod','IEC_T1_T2','targetX',1.2, ...
            'targetY',50,'Vp',100,'polarity',1,'alpha',0,'beta',0,'dt',1e-9, ...
            'tend',100e-6,'tolPeak',3,'tolX',30,'tolY',20);
        if isempty(row),return;end
        d.standardCode=char(string(getVal(row,'standard_code',d.standardCode)));
        d.fitMethod=char(string(getVal(row,'fit_method',d.fitMethod)));
        d.targetX=getVal(row,'target_X_us',d.targetX);d.targetY=getVal(row,'target_Y_us',d.targetY);
        d.Vp=getVal(row,'Vp_target_kV',d.Vp);d.alpha=getVal(row,'alpha_s_inv',0);d.beta=getVal(row,'beta_s_inv',0);
        d.dt=getVal(row,'dt_effective_s',d.dt);d.tend=getVal(row,'tend_effective_s',d.tend);
        d.tolPeak=getVal(row,'tol_peak_pct',d.tolPeak);d.tolX=getVal(row,'tol_X_pct',d.tolX);d.tolY=getVal(row,'tol_Y_pct',d.tolY);
        if strcmpi(char(string(getVal(row,'polarity','Positive'))),'Negative'),d.polarity=-1;end
    end
end

function v=getVal(row,name,default)
    if ismember(name,row.Properties.VariableNames),v=row.(name)(1);if iscell(v),v=v{1};end
    else,v=default;end
end
function s=textVal(v)
    s=char(string(v));
end
function s=passText(v)
    if (islogical(v) && v) || (isnumeric(v) && v~=0) || ...
            (isstring(v) && any(strcmpi(v,["true","pass","1"])))
        s='PASS';
    else
        s='FAIL';
    end
end
