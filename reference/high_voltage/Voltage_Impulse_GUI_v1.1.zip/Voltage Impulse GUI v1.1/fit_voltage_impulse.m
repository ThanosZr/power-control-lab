function [Trow, validationTable] = fit_voltage_impulse(cfg)
%FIT_VOLTAGE_IMPULSE Fit alpha/beta for a smooth impulse-voltage waveform.
%
% Required cfg fields:
%   targetX_us, targetY_us, Vp_kV, polarity, fitMethod, standardCode
%
% fitMethod values:
%   IEC_T1_T2    : IEC 30%-90% virtual front time and virtual-origin T2
%   TP_T2        : legacy time to peak and t50 from the actual origin t=0
%   T10_90_T50   : engineering 10%-90% rise and actual-origin tail t50

    cfg = applyDefaults(cfg);
    validateConfig(cfg);
    profile = voltage_impulse_standard_profile(cfg.standardCode);

    [alpha0, beta0] = initialGuess(cfg);
    q0 = [log(alpha0), log(beta0-alpha0)];
    objective = @(q) objectiveForMethod(q, cfg);
    opts = optimset('Display','off', 'TolX',1e-11, 'TolFun',1e-14, ...
        'MaxFunEvals',10000, 'MaxIter',10000);
    starts = [q0; q0+[log(0.5) log(0.5)]; q0+[log(2) log(2)]; ...
        q0+[0 log(4)]];
    bestJ = Inf; qOpt = q0;
    for kk = 1:size(starts,1)
        qCandidate = fminsearch(objective, starts(kk,:), opts);
        jCandidate = objective(qCandidate);
        if jCandidate < bestJ
            bestJ = jCandidate;
            qOpt = qCandidate;
        end
    end
    [alpha, beta] = decode(qOpt);
    exact = double_exponential_characteristics(alpha, beta);

    % Sample the final waveform as an independent numerical verification.
    effectiveTend = max(cfg.tend, 1.25*exact.t50_tail);
    effectiveDt = cfg.dt;
    maxPoints = 2e6;
    if effectiveTend/effectiveDt + 1 > maxPoints
        effectiveDt = effectiveTend/(maxPoints-1);
    end
    t = 0:effectiveDt:effectiveTend;
    v = double_exponential_voltage(cfg.Vp_kV, cfg.polarity, alpha, beta, t);
    sampled = voltage_impulse_characteristics(t, v);

    [selectedX, selectedY] = selectedMetrics(exact, cfg.fitMethod);
    selectedXErr = pctError(selectedX*1e6, cfg.targetX_us);
    selectedYErr = pctError(selectedY*1e6, cfg.targetY_us);
    peakErr = pctError(sampled.Vpeak/1e3, cfg.Vp_kV);
    if max(abs([selectedXErr selectedYErr])) > 1e-3
        error('Alpha/beta optimization did not converge to the requested time parameters.');
    end

    validationTable = validate_voltage_impulse_result(exact, sampled, cfg, profile);
    overallPass = all(validationTable.Status(validationTable.Required) == "PASS");

    polarityText = "Positive";
    if cfg.polarity < 0, polarityText = "Negative"; end
    name = sprintf('V_%s_kV_X_%s_Y_%s_%s', cleanNum(cfg.Vp_kV), ...
        cleanNum(cfg.targetX_us), cleanNum(cfg.targetY_us), cfg.fitMethod);
    createdAt = string(datetime('now','Format','yyyy-MM-dd HH:mm:ss'));

    Trow = table(string(name), string(profile.code), string(profile.display), ...
        string(cfg.fitMethod), polarityText, cfg.Vp_kV, sampled.Vpeak/1e3, ...
        alpha, beta, exact.K, cfg.targetX_us, cfg.targetY_us, ...
        selectedX*1e6, selectedY*1e6, selectedXErr, selectedYErr, peakErr, ...
        exact.T1*1e6, exact.T2*1e6, exact.Tp_virtual*1e6, ...
        exact.Tp_annexF*1e6, exact.t10_90*1e6, exact.t50_actual*1e6, ...
        exact.t_peak*1e6, exact.virtual_origin*1e6, exact.t30*1e6, ...
        exact.t90*1e6, sampled.T1*1e6, sampled.T2*1e6, ...
        pctDifference(sampled.T1, exact.T1), pctDifference(sampled.T2, exact.T2), ...
        cfg.tolPeak_pct, cfg.tolX_pct, cfg.tolY_pct, effectiveDt, effectiveTend, ...
        overallPass, string(profile.note), "computed", createdAt, ...
        'VariableNames', {'name','standard_code','standard_name','fit_method', ...
        'polarity','Vp_target_kV','Vpeak_calc_kV','alpha_s_inv','beta_s_inv','K', ...
        'target_X_us','target_Y_us','selected_X_calc_us','selected_Y_calc_us', ...
        'selected_X_err_pct','selected_Y_err_pct','peak_err_pct', ...
        'T1_IEC_us','T2_IEC_us','Tp_virtual_us','Tp_AnnexF_us', ...
        't10_90_us','t50_actual_us','t_peak_actual_us','virtual_origin_us', ...
        't30_us','t90_us','T1_sampled_us','T2_sampled_us', ...
        'analytic_sample_T1_diff_pct','analytic_sample_T2_diff_pct', ...
        'tol_peak_pct','tol_X_pct','tol_Y_pct','dt_effective_s','tend_effective_s', ...
        'overall_pass','standard_note','source','created_at'});
end

function cfg = applyDefaults(cfg)
    defaults = struct('targetX_us',1.2, 'targetY_us',50, 'Vp_kV',100, ...
        'polarity',1, 'fitMethod','IEC_T1_T2', 'standardCode','IEC2025_LI', ...
        'alphaGuess',NaN, 'betaGuess',NaN, 'dt',1e-9, 'tend',100e-6, ...
        'tolPeak_pct',3, 'tolX_pct',30, 'tolY_pct',20);
    names = fieldnames(defaults);
    for k = 1:numel(names)
        if ~isfield(cfg,names{k}) || isempty(cfg.(names{k}))
            cfg.(names{k}) = defaults.(names{k});
        end
    end
    cfg.fitMethod = upper(char(string(cfg.fitMethod)));
    cfg.standardCode = upper(char(string(cfg.standardCode)));
end

function validateConfig(cfg)
    vals = [cfg.targetX_us cfg.targetY_us cfg.Vp_kV cfg.dt cfg.tend];
    if any(~isfinite(vals)) || any(vals <= 0)
        error('Target times, peak voltage, dt and end time must be positive.');
    end
    if ~ismember(cfg.polarity,[-1 1])
        error('Polarity must be +1 or -1.');
    end
    if isfinite(cfg.alphaGuess) && isfinite(cfg.betaGuess) && ...
            (cfg.alphaGuess <= 0 || cfg.betaGuess <= cfg.alphaGuess)
        error('Initial guesses must satisfy beta > alpha > 0.');
    end
    allowed = {'IEC_T1_T2','TP_T2','T10_90_T50'};
    if ~ismember(cfg.fitMethod,allowed)
        error('Unknown fit method: %s',cfg.fitMethod);
    end
end

function [a0,b0] = initialGuess(cfg)
    if isfinite(cfg.alphaGuess) && isfinite(cfg.betaGuess) && ...
            cfg.alphaGuess > 0 && cfg.betaGuess > cfg.alphaGuess
        a0 = cfg.alphaGuess; b0 = cfg.betaGuess;
        return;
    end
    y = cfg.targetY_us*1e-6;
    x = cfg.targetX_us*1e-6;
    a0 = 0.7/y;
    switch cfg.fitMethod
        case 'IEC_T1_T2'
            b0 = 3/x;
        case 'TP_T2'
            b0 = 4/x;
        otherwise
            b0 = 2.2/x;
    end
    b0 = max(b0,10*a0);
end

function J = objectiveForMethod(q,cfg)
    try
        [a,b] = decode(q);
        c = double_exponential_characteristics(a,b);
        [x,y] = selectedMetrics(c,cfg.fitMethod);
        ex = (x*1e6-cfg.targetX_us)/cfg.targetX_us;
        ey = (y*1e6-cfg.targetY_us)/cfg.targetY_us;
        J = ex^2 + ey^2;
        if ~isfinite(J), J = 1e12; end
    catch
        J = 1e12;
    end
end

function [a,b] = decode(q)
    a = exp(q(1));
    b = a + exp(q(2));
end

function [x,y] = selectedMetrics(c,method)
    switch upper(method)
        case 'IEC_T1_T2'
            x = c.T1; y = c.T2;
        case 'TP_T2'
            x = c.t_peak; y = c.t50_actual;
        case 'T10_90_T50'
            x = c.t10_90; y = c.t50_actual;
        otherwise
            error('Unknown fitting method.');
    end
end

function e = pctError(actual,target)
    e = 100*(actual-target)/target;
end

function e = pctDifference(a,b)
    e = 100*(a-b)/b;
end

function s = cleanNum(x)
    s = strrep(sprintf('%.6g',x),'.','p');
    s = strrep(s,'+','');
    s = strrep(s,'-','m');
end
