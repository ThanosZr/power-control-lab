function open_voltage_impulse_verification_gui(row)
%OPEN_VOLTAGE_IMPULSE_VERIFICATION_GUI Compare a GUI impulse with EMTP CSV data.
%   The first CSV column is treated as time in seconds. The user selects
%   which remaining column contains the EMTP impulse voltage and its unit.
%   The curves can be aligned automatically at their absolute peaks or by
%   applying a user-controlled time shift.

    state=struct('csvTable',table(),'csvPath','','tRaw',[],'vRaw',[], ...
        'modelT',[],'modelV_kV',[],'autoUnit','');

    alpha=rowValue('alpha_s_inv',NaN);
    beta=rowValue('beta_s_inv',NaN);
    Vp_kV=rowValue('Vp_target_kV',NaN);
    polText=char(string(rowValue('polarity','Positive')));
    polarity=1;
    if strcmpi(polText,'Negative'),polarity=-1;end
    if ~isfinite(alpha)||~isfinite(beta)||beta<=alpha||~isfinite(Vp_kV)
        error('The selected row does not contain valid alpha, beta and peak-voltage values.');
    end

    exact=double_exponential_characteristics(alpha,beta);
    tend=max(rowValue('tend_effective_s',1.25*exact.t50_tail),1.25*exact.t50_tail);
    dt=rowValue('dt_effective_s',tend/2e5);
    if ~isfinite(dt)||dt<=0,dt=tend/2e5;end
    if tend/dt>5e5,dt=tend/5e5;end
    state.modelT=(0:dt:tend).';
    state.modelV_kV=double_exponential_voltage(Vp_kV,polarity,alpha,beta,state.modelT)/1e3;

    fig=uifigure('Name','EMTP Impulse Verification','Position',[85 55 1510 880]);
    root=uigridlayout(fig,[2 2]);
    root.RowHeight={'1x',185}; root.ColumnWidth={'2.55x','1.15x'};
    root.Padding=[8 8 8 8]; root.RowSpacing=8; root.ColumnSpacing=8;

    ax=uiaxes(root); ax.Layout.Row=1; ax.Layout.Column=1;
    grid(ax,'on');box(ax,'on');xlabel(ax,'Time [s]');ylabel(ax,'Voltage [kV]');
    title(ax,'Load an EMTP CSV file to compare the waveforms');

    panel=uipanel(root,'Title','Verification controls');
    panel.Layout.Row=1; panel.Layout.Column=2;
    cg=uigridlayout(panel,[14 2]);
    cg.RowHeight={32,58,24,32,24,32,24,32,24,32,48,32,'1x',24};
    cg.ColumnWidth={150,'1x'}; cg.Padding=[8 8 8 8]; cg.RowSpacing=5;

    btnLoad=uibutton(cg,'Text','Load EMTP CSV','ButtonPushedFcn',@(~,~)loadCSV());
    btnLoad.Layout.Row=1;btnLoad.Layout.Column=[1 2];
    fileText=uitextarea(cg,'Editable','off','Value',{'No EMTP CSV loaded.'});
    fileText.Layout.Row=2;fileText.Layout.Column=[1 2];
    addLabel(3,'Time column (seconds)');
    timeColumn=uilabel(cg,'Text','-','Interpreter','none');place(timeColumn,3);
    addLabel(4,'Voltage column');
    voltageColumn=uidropdown(cg,'Items',{'-'},'Value','-', ...
        'Enable','off','ValueChangedFcn',@(~,~)dataSelectionChanged());place(voltageColumn,4);
    addLabel(5,'CSV voltage unit');
    voltageUnit=uidropdown(cg, ...
        'Items',{'Auto detect','V','kV','MV','mV'}, ...
        'ItemsData',{'AUTO','V','KV','MEGAV','MILLIV'}, ...
        'Value','AUTO','ValueChangedFcn',@(~,~)dataSelectionChanged());place(voltageUnit,5);
    addLabel(6,'Alignment');
    alignment=uidropdown(cg, ...
        'Items',{'Align absolute peaks','Manual time shift'}, ...
        'ItemsData',{'PEAK','MANUAL'},'Value','PEAK', ...
        'ValueChangedFcn',@(~,~)alignmentChanged());place(alignment,6);
    addLabel(7,'EMTP time shift [s]');
    shiftEdit=uieditfield(cg,'numeric','Value',0, ...
        'ValueDisplayFormat','%.12g','ValueChangedFcn',@(~,~)editShiftChanged());place(shiftEdit,7);
    addLabel(8,'Manual shift slider');
    shiftSlider=uislider(cg,'Limits',[-1e-6 1e-6],'Value',0, ...
        'ValueChangedFcn',@(~,evt)sliderShiftChanged(evt.Value), ...
        'ValueChangingFcn',@(~,evt)sliderShiftChanged(evt.Value));place(shiftSlider,8);
    addLabel(9,'Amplitude display');
    normalizePeak=uicheckbox(cg,'Text','Normalize EMTP peak magnitude', ...
        'Value',false,'ValueChangedFcn',@(~,~)refreshPlot());place(normalizePeak,9);
    addLabel(10,'Plot range');
    plotRange=uidropdown(cg,'Items',{'Full waveform','Front detail'}, ...
        'Value','Full waveform','ValueChangedFcn',@(~,~)refreshPlot());place(plotRange,10);

    buttons=uigridlayout(cg,[1 2]);buttons.Layout.Row=11;buttons.Layout.Column=[1 2];
    buttons.ColumnWidth={'1x','1x'};buttons.Padding=[0 0 0 0];
    uibutton(buttons,'Text','Align peaks now','ButtonPushedFcn',@(~,~)alignPeaksNow());
    uibutton(buttons,'Text','Reset shift','ButtonPushedFcn',@(~,~)resetShift());
    cbLegend=uicheckbox(cg,'Text','Show legend','Value',true, ...
        'ValueChangedFcn',@(~,~)refreshPlot());
    cbLegend.Layout.Row=12;cbLegend.Layout.Column=[1 2];
    selectedInfo=uitextarea(cg,'Editable','off');
    selectedInfo.Layout.Row=13;selectedInfo.Layout.Column=[1 2];
    status=uilabel(cg,'Text','Waiting for EMTP CSV.');
    status.Layout.Row=14;status.Layout.Column=[1 2];

    metricsPanel=uipanel(root,'Title','Comparison results');
    metricsPanel.Layout.Row=2;metricsPanel.Layout.Column=[1 2];
    mg=uigridlayout(metricsPanel,[2 1]);mg.RowHeight={'1x',32};mg.Padding=[6 6 6 6];
    metrics=uitable(mg,'ColumnSortable',false);
    metricsNote=uilabel(mg,'Text', ...
        'Default comparison preserves the measured EMTP amplitude. Normalization is optional and affects the displayed comparison metrics.');

    selectedInfo.Value={sprintf('GUI result: %s',asText(rowValue('name','-'))), ...
        sprintf('Polarity: %s',polText),sprintf('Target peak: %.9g kV',Vp_kV), ...
        sprintf('alpha: %.12g s^-1',alpha),sprintf('beta: %.12g s^-1',beta)};
    refreshPlot();
    drawnow;
    loadCSV();

    function loadCSV()
        [file,path]=uigetfile({'*.csv','CSV files'},'Select EMTP waveform CSV');
        if isequal(file,0)
            status.Text='EMTP CSV selection canceled.';
            return;
        end
        fp=fullfile(path,file);
        try
            T=readtable(fp,'TextType','string','VariableNamingRule','preserve');
            if width(T)<2,error('The CSV must contain time plus at least one signal column.');end
            if height(T)<3,error('The CSV must contain at least three data rows.');end
            names=T.Properties.VariableNames;
            t=columnToNumeric(T.(names{1}),names{1});
            if nnz(isfinite(t))<3,error('The first CSV column must contain numeric time values in seconds.');end
            state.csvTable=T;state.csvPath=fp;state.tRaw=t(:);
            timeColumn.Text=names{1};
            voltageColumn.Items=names(2:end);
            initialColumn=chooseInitialVoltageColumn(T,names);
            voltageColumn.Value=names{initialColumn};
            voltageColumn.Enable='on';
            fileText.Value={fp;sprintf('%d rows, %d columns',height(T),width(T))};
            dataSelectionChanged();
        catch ME
            uialert(fig,sprintf('Could not import the EMTP CSV.\n\n%s',ME.message), ...
                'EMTP CSV import error');
            status.Text='EMTP CSV import failed.';
        end
    end

    function idx=chooseInitialVoltageColumn(T,names)
        idx=2;
        priority={'voltage','volt','impulse','vout','v_','u_'};
        for p=1:numel(priority)
            for kk=2:width(T)
                if contains(lower(names{kk}),priority{p})
                    try
                        candidate=columnToNumeric(T.(names{kk}),names{kk});
                        if nnz(isfinite(candidate))>=3,idx=kk;return;end
                    catch
                    end
                end
            end
        end
    end

    function dataSelectionChanged()
        if isempty(state.csvTable),return;end
        try
            names=state.csvTable.Properties.VariableNames;
            idx=find(strcmp(names,voltageColumn.Value),1);
            if isempty(idx),error('The selected voltage-column header was not found.');end
            state.vRaw=columnToNumeric(state.csvTable.(names{idx}),names{idx});
            valid=isfinite(state.tRaw)&isfinite(state.vRaw);
            if nnz(valid)<3,error('The selected voltage column has fewer than three numeric samples.');end
            state.tRaw=state.tRaw(:);
            state.vRaw=state.vRaw(:);
            updateSliderLimits();
            if strcmp(alignment.Value,'PEAK')
                setPeakShift();
            end
            refreshPlot();
        catch ME
            state.vRaw=[];
            refreshPlot();
            uialert(fig,ME.message,'Invalid voltage column');
            status.Text='Select a numeric EMTP voltage column.';
        end
    end

    function alignmentChanged()
        if strcmp(alignment.Value,'PEAK')&&~isempty(state.vRaw)
            setPeakShift();
        end
        refreshPlot();
    end

    function alignPeaksNow()
        if isempty(state.vRaw),return;end
        alignment.Value='PEAK';
        setPeakShift();
        refreshPlot();
    end

    function resetShift()
        alignment.Value='MANUAL';
        setShiftValue(0);
        refreshPlot();
    end

    function editShiftChanged()
        alignment.Value='MANUAL';
        updateSliderLimits();
        setShiftValue(shiftEdit.Value);
        refreshPlot();
    end

    function sliderShiftChanged(value)
        alignment.Value='MANUAL';
        shiftEdit.Value=value;
        refreshPlot();
    end

    function setPeakShift()
        valid=isfinite(state.tRaw)&isfinite(state.vRaw);
        t=state.tRaw(valid);v=state.vRaw(valid);
        [~,iCsv]=max(abs(v));
        setShiftValue(exact.t_peak-t(iCsv));
    end

    function setShiftValue(value)
        if ~isfinite(value),value=0;end
        limits=shiftSlider.Limits;
        if value<limits(1)||value>limits(2)
            span=max(abs(value)*1.25,eps);
            shiftSlider.Limits=[-span span];
        end
        shiftEdit.Value=value;
        shiftSlider.Value=value;
    end

    function updateSliderLimits()
        if isempty(state.tRaw),return;end
        finiteT=state.tRaw(isfinite(state.tRaw));
        if isempty(finiteT),return;end
        duration=max(finiteT)-min(finiteT);
        required=max(abs([shiftEdit.Value,min(finiteT),max(finiteT)]));
        span=max([duration,tend,1.25*required,1e-12]);
        shiftSlider.Limits=[-span span];
        if shiftEdit.Value>=-span&&shiftEdit.Value<=span
            shiftSlider.Value=shiftEdit.Value;
        end
    end

    function refreshPlot()
        cla(ax);hold(ax,'on');
        [modelPlotT,modelPlotV]=plotSamples(state.modelT,state.modelV_kV);
        plot(ax,modelPlotT,modelPlotV,'k','LineWidth',1.8, ...
            'DisplayName','GUI double exponential');
        if isempty(state.vRaw)
            title(ax,'Load an EMTP CSV file to compare the waveforms');
            legend(ax,'off');hold(ax,'off');
            metrics.Data=emptyMetrics();
            return;
        end

        valid=isfinite(state.tRaw)&isfinite(state.vRaw);
        t=state.tRaw(valid);rawV=state.vRaw(valid);
        [v_kV,unitText]=convertToKV(rawV);
        amplitudeFactor=1;
        if normalizePeak.Value
            rawPeak=max(abs(v_kV));
            if rawPeak>0,amplitudeFactor=abs(Vp_kV)/rawPeak;end
        end
        vDisplay=v_kV*amplitudeFactor;
        tDisplay=t+shiftEdit.Value;
        [emtpPlotT,emtpPlotV]=plotSamples(tDisplay,vDisplay);
        plot(ax,emtpPlotT,emtpPlotV,'Color',[0 0.447 0.741],'LineWidth',1.35, ...
            'DisplayName',sprintf('EMTP: %s',voltageColumn.Value));
        xlabel(ax,'Time [s]');ylabel(ax,'Voltage [kV]');grid(ax,'on');box(ax,'on');
        if strcmp(plotRange.Value,'Front detail')
            frontEnd=max(5*exact.T1,2.2*exact.t_peak);
            xlim(ax,[min(0,min(tDisplay)),frontEnd]);
        else
            allT=[state.modelT;tDisplay(:)];
            xlim(ax,[min(allT),max(allT)]);
        end
        title(ax,sprintf('GUI waveform vs EMTP | shift = %.12g s',shiftEdit.Value));
        if cbLegend.Value,legend(ax,'show','Location','best');else,legend(ax,'off');end
        hold(ax,'off');

        metrics.Data=calculateMetrics(tDisplay,vDisplay,v_kV,unitText,amplitudeFactor);
        status.Text=sprintf('Comparing "%s"; unit: %s; shift: %.12g s.', ...
            voltageColumn.Value,unitText,shiftEdit.Value);
    end

    function [v_kV,unitText]=convertToKV(v)
        selected=voltageUnit.Value;
        if strcmp(selected,'AUTO')
            peak=max(abs(v));
            units={'kV','V','MV','mV'};
            scales=[1,1e-3,1e3,1e-6];
            scores=abs(log10(max(peak*scales,realmin)/max(abs(Vp_kV),realmin)));
            [~,idx]=min(scores);
            scale=scales(idx);unitText=[units{idx} ' (auto)'];
            state.autoUnit=units{idx};
        else
            switch selected
                case 'V',scale=1e-3;unitText='V';
                case 'KV',scale=1;unitText='kV';
                case 'MEGAV',scale=1e3;unitText='MV';
                case 'MILLIV',scale=1e-6;unitText='mV';
                otherwise,error('Unknown voltage unit.');
            end
        end
        v_kV=v*scale;
    end

    function M=calculateMetrics(tDisplay,vDisplay,vUnnormalized,unitText,amplitudeFactor)
        [~,iCsv]=max(abs(vUnnormalized));
        modelPeak=polarity*Vp_kV;
        csvPeak=vUnnormalized(iCsv);
        peakErr=100*(abs(csvPeak)-abs(modelPeak))/abs(modelPeak);

        overlap=tDisplay>=state.modelT(1)&tDisplay<=state.modelT(end);
        compareT=tDisplay(overlap);compareV=vDisplay(overlap);
        [compareT,uniqueIdx]=unique(compareT,'stable');
        compareV=compareV(uniqueIdx);
        if numel(compareT)>2e5
            keep=unique(round(linspace(1,numel(compareT),2e5)));
            compareT=compareT(keep);compareV=compareV(keep);
        end
        if numel(compareT)>=3
            modelAtCsv=interp1(state.modelT,state.modelV_kV,compareT,'linear');
            err=compareV-modelAtCsv;
            rmse=sqrt(mean(err.^2,'omitnan'));
            nrmse=100*rmse/abs(Vp_kV);
            good=isfinite(compareV)&isfinite(modelAtCsv);
            if nnz(good)>=3
                C=corrcoef(compareV(good),modelAtCsv(good));
                correlation=C(1,2);
            else
                correlation=NaN;
            end
            overlapCount=nnz(good);
        else
            rmse=NaN;nrmse=NaN;correlation=NaN;overlapCount=0;
        end

        M=table( ...
            ["GUI peak";"EMTP peak";"EMTP peak error";"Applied time shift"; ...
             "Amplitude factor";"RMSE in overlap";"Normalized RMSE"; ...
             "Waveform correlation";"Compared samples"], ...
            [modelPeak;csvPeak;peakErr;shiftEdit.Value;amplitudeFactor;rmse;nrmse;correlation;overlapCount], ...
            ["kV";"kV";"%";"s";"-";"kV";"%";"-";"samples"], ...
            ["GUI parameters";string(unitText);"Unnormalized EMTP amplitude"; ...
             string(alignment.Value);string(logicalText(normalizePeak.Value));"Displayed curves"; ...
             "Relative to GUI peak";"1 means identical shape";"Common time interval"], ...
            'VariableNames',{'Metric','Value','Unit','Basis'});
    end

    function M=emptyMetrics()
        M=table("Waiting for CSV",NaN,"-","-", ...
            'VariableNames',{'Metric','Value','Unit','Basis'});
    end

    function x=columnToNumeric(column,columnName)
        if isnumeric(column)||islogical(column)
            x=double(column);
        elseif isduration(column)
            x=seconds(column);
        else
            s=strip(string(column));
            s=replace(s,',','.');
            x=str2double(s);
        end
        if nnz(isfinite(x))<3
            error('Column "%s" is not a usable numeric signal.',columnName);
        end
    end

    function [xPlot,yPlot]=plotSamples(x,y)
        maxPlotPoints=1e5;
        if numel(x)<=maxPlotPoints
            xPlot=x;yPlot=y;
        else
            keep=unique(round(linspace(1,numel(x),maxPlotPoints)));
            xPlot=x(keep);yPlot=y(keep);
        end
    end

    function v=rowValue(field,default)
        if ismember(field,row.Properties.VariableNames)
            v=row.(field)(1);if iscell(v),v=v{1};end
        else
            v=default;
        end
    end

    function addLabel(rowNumber,textValue)
        h=uilabel(cg,'Text',textValue);h.Layout.Row=rowNumber;h.Layout.Column=1;
    end
    function place(h,rowNumber),h.Layout.Row=rowNumber;h.Layout.Column=2;end
    function s=asText(v),s=char(string(v));end
    function s=logicalText(v)
        if v,s='Peak normalized';else,s='Original amplitude';end
    end
end
