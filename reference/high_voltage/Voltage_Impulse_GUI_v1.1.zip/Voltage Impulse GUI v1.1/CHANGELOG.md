# Changelog

## 1.1.0

- Added **Verify against EMTP** for a selected voltage-impulse result.
- Added a guided create/load flow when no result row is selected.
- Added EMTP CSV import with the first column fixed as time in seconds and a
  dropdown for selecting the voltage column by header name.
- Added automatic voltage-unit detection plus explicit V, kV, MV and mV modes.
- Added absolute-peak time alignment and manual time shifting with an exact
  seconds field and slider.
- Added overlaid GUI/EMTP plots, optional peak normalization and quantitative
  peak, RMSE, normalized-RMSE and correlation results.

## 1.0.2

- The Compute New Impulse dialog is sized from the available screen dimensions
  and opens centered on the screen.
- The parameter area now has vertical scrolling on smaller displays.
- Compute and Cancel remain fixed at the bottom and are always accessible when
  the dialog is resized.

## 1.0.1

- Renamed the details-window layout variable so it no longer shadows MATLAB's
  `grid` plotting function.
- The calculation dialog is now deleted only after the details plot opens
  successfully.
- Error reporting now falls back to the main application window and preserves
  the original exception report.

## 1.0.0

- Initial voltage-impulse parameter manager.
