function c = voltage_impulse_characteristics(t, v)
%VOLTAGE_IMPULSE_CHARACTERISTICS Sampled voltage-impulse measurements.
%   Uses absolute magnitude, so positive and negative impulses are handled
%   identically. t is in seconds and v in volts.

    fields = {'Vpeak','t_peak','t10','t30','t90','t50_tail','TAB','T1', ...
        'virtual_origin','T2','Tp_virtual','Tp_annexF','t10_90', ...
        't50_actual','overshoot_pct'};
    for k = 1:numel(fields)
        c.(fields{k}) = NaN;
    end

    if isempty(t) || isempty(v) || numel(t) ~= numel(v)
        return;
    end
    y = abs(v(:));
    tt = t(:);
    [c.Vpeak, idxPeak] = max(y);
    if ~isfinite(c.Vpeak) || c.Vpeak <= 0 || idxPeak <= 1
        return;
    end
    c.t_peak = tt(idxPeak);

    c.t10 = firstRisingCrossing(tt, y, 0.10*c.Vpeak, idxPeak);
    c.t30 = firstRisingCrossing(tt, y, 0.30*c.Vpeak, idxPeak);
    c.t90 = firstRisingCrossing(tt, y, 0.90*c.Vpeak, idxPeak);
    c.t50_tail = firstFallingCrossing(tt, y, 0.50*c.Vpeak, idxPeak);
    if any(isnan([c.t10 c.t30 c.t90 c.t50_tail]))
        return;
    end

    c.TAB = c.t90 - c.t30;
    c.T1 = c.TAB / 0.6;
    c.virtual_origin = c.t30 - 0.5*c.TAB;
    c.T2 = c.t50_tail - c.virtual_origin;
    c.Tp_virtual = c.t_peak - c.virtual_origin;
    c.t10_90 = c.t90 - c.t10;
    c.t50_actual = c.t50_tail;

    TAB_us = c.TAB * 1e6;
    T2_us = c.T2 * 1e6;
    annexK = 2.42 - 3.08e-3*TAB_us + 1.51e-4*T2_us;
    c.Tp_annexF = annexK * TAB_us * 1e-6;

    % A smooth double exponential has no superimposed overshoot.
    c.overshoot_pct = 0;
end

function tc = firstRisingCrossing(t, y, level, idxPeak)
    idx = find(y(1:idxPeak) >= level, 1, 'first');
    tc = interpolate(t, y, level, idx);
end

function tc = firstFallingCrossing(t, y, level, idxPeak)
    rel = find(y(idxPeak:end) <= level, 1, 'first');
    if isempty(rel)
        tc = NaN;
        return;
    end
    idx = idxPeak + rel - 1;
    tc = interpolate(t, y, level, idx);
end

function tc = interpolate(t, y, level, idx)
    if isempty(idx) || idx <= 1
        tc = NaN;
        return;
    end
    t1 = t(idx-1); t2 = t(idx);
    y1 = y(idx-1); y2 = y(idx);
    if y2 == y1
        tc = t2;
    else
        tc = t1 + (level-y1)*(t2-t1)/(y2-y1);
    end
end
