function v = double_exponential_voltage(Vp_kV, polarity, alpha, beta, t)
%DOUBLE_EXPONENTIAL_VOLTAGE Normalized double-exponential impulse voltage.
%   v = double_exponential_voltage(Vp_kV, polarity, alpha, beta, t)
%   returns v in volts for t in seconds. alpha and beta are in s^-1 and
%   beta must be greater than alpha. polarity is +1 or -1.

    if alpha <= 0 || beta <= alpha
        error('Require beta > alpha > 0.');
    end
    if ~ismember(polarity, [-1 1])
        error('Polarity must be +1 or -1.');
    end

    tp = log(beta / alpha) / (beta - alpha);
    peakRaw = exp(-alpha * tp) - exp(-beta * tp);
    K = 1 / peakRaw;

    v = polarity * Vp_kV * 1e3 .* K .* ...
        (exp(-alpha .* t) - exp(-beta .* t));
    v(t < 0) = 0;
end
