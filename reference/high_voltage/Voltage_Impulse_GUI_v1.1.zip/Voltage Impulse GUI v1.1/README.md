# Voltage Impulse Parameter Manager

Package revision: **1.1.0**.

MATLAB GUI and numerical engine for calculating the parameters of the smooth
double-exponential voltage impulse

\[
v(t)=p\,K\,V_p\left(e^{-\alpha t}-e^{-\beta t}\right),
\qquad \beta>\alpha>0,
\]

where `p` is the polarity and `K` normalizes the waveform so its magnitude
reaches exactly `Vp`.

## Start

Open MATLAB in this folder and run:

```matlab
run_voltage_impulse_manager
```

To check the numerical core independently:

```matlab
test_voltage_impulse_engine
```

The GUI saves one CSV per calculation under `voltage_impulse_params` and can
reload, merge and inspect saved calculations.

## EMTP waveform verification

Select any cell in a calculated or loaded result row and press **Verify against
EMTP**. The verification window then asks for the EMTP waveform CSV and:

- treats the first CSV column as time in seconds;
- lists every other CSV header so the voltage-signal column can be selected;
- accepts `V`, `kV`, `MV` and `mV`, with peak-based automatic unit detection;
- overlays the EMTP signal and the GUI double-exponential waveform in kV, with
  the horizontal axis kept in seconds;
- aligns the absolute peaks automatically, including negative impulses;
- permits an exact manual EMTP time shift in seconds, controlled by both a
  numeric field and a slider;
- preserves the original EMTP amplitude by default and provides optional peak
  normalization for shape-only inspection;
- reports peak error, applied shift, RMSE, normalized RMSE, waveform
  correlation and the number of samples in the common time interval.

Automatic peak alignment changes only the EMTP time coordinate. It does not
hide a peak-voltage error. If no result row is selected, the verification flow
offers to calculate a new impulse or load a saved parameter CSV.

The **Compute New Impulse** dialog adapts to the available screen height. Its
parameter area scrolls vertically when necessary, while the Compute and Cancel
buttons remain fixed and accessible at the bottom of the window.

## Calculation bases

The user selects one basis for fitting `alpha` and `beta`:

1. **IEC T1/T2:** `T1=(t90-t30)/0.6`; the virtual origin is
   `O1=t30-0.5*(t90-t30)` and `T2=t50,tail-O1`.
2. **Legacy Tp/t50:** actual time to the maximum and the falling 50% crossing,
   both measured from the mathematical origin `t=0`. This is retained for
   compatibility with the historical 250/2500-us switching impulse.
3. **Engineering t10-90/t50:** non-standard diagnostic fitting route.

Irrespective of the selected fit basis, the final details window evaluates:

- IEC 30%-90% `T1` and virtual-origin `T2`;
- actual peak time and peak time from `O1`;
- IEC 60060-1:2025 Annex-F switching-impulse `Tp` estimate;
- engineering 10%-90% rise time and actual-origin `t50`;
- independent measurements from a sampled waveform;
- peak normalization and smooth-wave overshoot.

## Included profiles

- IEC 60060-1:2025 full lightning impulse: 1.2/50 us; peak ±3%, `T1` ±30%,
  `T2` ±20%, relative overshoot no more than 10%.
- IEC 60060-1:2025 switching impulse: 170/2500 us; peak ±3%, `T1` ±20%,
  `T2` ±60%.
- Legacy switching-impulse compatibility: 250/2500 us using the actual-origin
  peak-time convention.
- Custom smooth impulse with user tolerances.

When non-nominal `X/Y` values are required, select the Custom profile. Standard
profiles always assess PASS/FAIL against their fixed nominal values even if a
different fitting basis is deliberately selected for comparison.

The 2025 IEC edition replaced the former standard switching-impulse peak-time
description with a 30%-90% front time, so the current standard switching
impulse is 170/2500 us. The older 250/2500-us workflow remains available only
as an explicitly labelled compatibility mode.

## Scope and limitations

This package generates and evaluates a **smooth mathematical impulse**. It does
not implement the complete base-curve/residual filtering workflow needed for a
measured impulse with superimposed oscillations or overshoot. For such measured
records, compliant evaluation software should be validated using the reference
waveforms and acceptance limits of IEC 61083-2.

An ideal controlled source forces the waveform independently of the cable
current. For generator–cable interaction studies, add a realistic Thevenin
output network and measure the waveform at the cable terminal.

## Main files

- `voltage_impulse_manager_gui.m`: manager GUI.
- `fit_voltage_impulse.m`: alpha/beta optimizer and CSV result row.
- `double_exponential_characteristics.m`: exact analytic measurements.
- `voltage_impulse_characteristics.m`: sampled-waveform measurements.
- `validate_voltage_impulse_result.m`: all-route validation table.
- `open_voltage_impulse_details_gui.m`: plots and detailed checks.
- `open_voltage_impulse_verification_gui.m`: EMTP CSV import, alignment,
  overlay and comparison metrics.

## Standards references

- IEC 60060-1:2025, *High-voltage test techniques – Part 1: General
  terminology and test requirements*:
  <https://webstore.iec.ch/en/publication/65088>.
- IEC 61083-2:2013, *Instruments and software used for measurement in
  high-voltage and high-current tests – Part 2: Requirements for software for
  tests with impulse voltages and currents*:
  <https://webstore.iec.ch/en/publication/4471>.
