function open_voltage_impulse_details_gui(row)
%OPEN_VOLTAGE_IMPULSE_DETAILS_GUI Plot and cross-validate one result row.

    fig=uifigure('Name','Voltage Impulse Details','Position',[120 80 1420 820]);
    layout=uigridlayout(fig,[2 3]);
    layout.RowHeight={'1x',42}; layout.ColumnWidth={'2.2x','1.15x','1.65x'};

    ax=uiaxes(layout); ax.Layout.Row=1; ax.Layout.Column=1;
    grid(ax,'on'); box(ax,'on'); xlabel(ax,'Time [\mus]'); ylabel(ax,'Voltage [kV]');

    summaryPanel=uipanel(layout,'Title','Parameters'); summaryPanel.Layout.Row=1; summaryPanel.Layout.Column=2;
    summary=uitextarea(summaryPanel,'Position',[8 8 325 710],'Editable','off');

    validationPanel=uipanel(layout,'Title','All validation routes');
    validationPanel.Layout.Row=1; validationPanel.Layout.Column=3;
    vg=uigridlayout(validationPanel,[2 1]); vg.RowHeight={'1x',95};
    validationUI=uitable(vg,'ColumnSortable',true); validationUI.Layout.Row=1;
    note=uitextarea(vg,'Editable','off'); note.Layout.Row=2;

    controls=uigridlayout(layout,[1 5]); controls.Layout.Row=2; controls.Layout.Column=[1 3];
    controls.ColumnWidth={170,170,170,170,'1x'};
    cbPoints=uicheckbox(controls,'Text','Show characteristic points','Value',true);
    cbVirtual=uicheckbox(controls,'Text','Show virtual front line','Value',true);
    ddScale=uidropdown(controls,'Items',{'Full waveform','Front detail'},'Value','Full waveform');
    btnRefresh=uibutton(controls,'Text','Refresh','ButtonPushedFcn',@(~,~)refresh());
    uilabel(controls,'Text','PASS/FAIL uses the selected standard profile; INFO rows are cross-checks.');

    refresh();

    function refresh()
        alpha=get('alpha_s_inv',NaN); beta=get('beta_s_inv',NaN);
        Vp=get('Vp_target_kV',NaN); polText=char(string(get('polarity','Positive')));
        polarity=1; if strcmpi(polText,'Negative'), polarity=-1; end
        exact=double_exponential_characteristics(alpha,beta);
        tend=max(get('tend_effective_s',1.25*exact.t50_tail),1.25*exact.t50_tail);
        dt=get('dt_effective_s',tend/2e5);
        if tend/dt>5e5, dt=tend/5e5; end
        t=0:dt:tend; v=double_exponential_voltage(Vp,polarity,alpha,beta,t);
        sampled=voltage_impulse_characteristics(t,v);

        cfg=struct('targetX_us',get('target_X_us',NaN),'targetY_us',get('target_Y_us',NaN), ...
            'Vp_kV',Vp,'fitMethod',char(string(get('fit_method','IEC_T1_T2'))), ...
            'tolPeak_pct',get('tol_peak_pct',3),'tolX_pct',get('tol_X_pct',30), ...
            'tolY_pct',get('tol_Y_pct',20));
        profile=voltage_impulse_standard_profile(char(string(get('standard_code','CUSTOM'))));
        VT=validate_voltage_impulse_result(exact,sampled,cfg,profile);
        validationUI.Data=VT;
        validationUI.ColumnWidth={190,80,80,90,100,60,60,160};

        cla(ax); hold(ax,'on');
        plot(ax,t*1e6,v/1e3,'k','LineWidth',1.7,'DisplayName','Double exponential');
        sgn=polarity;
        if cbPoints.Value
            ptsT=[exact.t30 exact.t90 exact.t50_tail exact.t_peak]*1e6;
            ptsV=[0.3 0.9 0.5 1.0]*Vp*sgn;
            colors={[0 0.45 0.74],[0.47 0.67 0.19],[0.49 0.18 0.56],[0.85 0.33 0.10]};
            for kk=1:numel(ptsT)
                plot(ax,ptsT(kk),ptsV(kk),'o','MarkerSize',7, ...
                    'MarkerFaceColor',colors{kk},'MarkerEdgeColor',colors{kk}, ...
                    'HandleVisibility','off');
            end
            text(ax,ptsT,ptsV,{' 30%',' 90%',' 50% tail',' peak'},'FontSize',11);
        end
        if cbVirtual.Value
            m=(0.9-0.3)*Vp*sgn/((exact.t90-exact.t30)*1e6);
            tx=linspace(exact.virtual_origin*1e6, ...
                (exact.virtual_origin+exact.T1)*1e6,120);
            vy=m*(tx-exact.virtual_origin*1e6);
            plot(ax,tx,vy,'--r','LineWidth',1.2,'DisplayName','Virtual front line');
        end
        if strcmp(ddScale.Value,'Front detail')
            xlim(ax,[min(0,exact.virtual_origin*1e6),max(5*exact.T1*1e6,2*exact.t_peak*1e6)]);
        else
            xlim(ax,[0,tend*1e6]);
        end
        title(ax,sprintf('%s | a=%.6g s^{-1}, b=%.6g s^{-1}',profile.display,alpha,beta));
        legend(ax,'show','Location','best'); hold(ax,'off');

        summary.Value={sprintf('Name: %s',txt(get('name','-'))),' ', ...
            sprintf('Standard: %s',profile.display),sprintf('Fit method: %s',cfg.fitMethod), ...
            sprintf('Polarity: %s',polText),sprintf('Target peak: %.8g kV',Vp),' ', ...
            sprintf('alpha = %.12g s^-1',alpha),sprintf('beta  = %.12g s^-1',beta), ...
            sprintf('K = %.12g',exact.K),' ', ...
            sprintf('IEC T1 = %.9g us',exact.T1*1e6),sprintf('IEC T2 = %.9g us',exact.T2*1e6), ...
            sprintf('Tp from O1 = %.9g us',exact.Tp_virtual*1e6), ...
            sprintf('Tp Annex F = %.9g us',exact.Tp_annexF*1e6), ...
            sprintf('t10-90 = %.9g us',exact.t10_90*1e6), ...
            sprintf('t50 from t=0 = %.9g us',exact.t50_actual*1e6),' ', ...
            sprintf('t30 = %.9g us',exact.t30*1e6),sprintf('t90 = %.9g us',exact.t90*1e6), ...
            sprintf('O1 = %.9g us',exact.virtual_origin*1e6), ...
            sprintf('Actual peak time = %.9g us',exact.t_peak*1e6), ...
            sprintf('Sample dt = %.6g s',dt)};
        note.Value={profile.note; ...
            'The sampled-waveform rows independently verify the analytic solution.'; ...
            'A smooth double exponential has zero superimposed overshoot.'};
    end

    function v=get(field,default)
        if ismember(field,row.Properties.VariableNames)
            v=row.(field)(1); if iscell(v),v=v{1};end
        else
            v=default;
        end
    end
    function s=txt(v)
        s=char(string(v));
    end
end
