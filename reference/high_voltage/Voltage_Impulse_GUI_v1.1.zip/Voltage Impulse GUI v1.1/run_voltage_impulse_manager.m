clear; clc;
voltage_impulse_manager_gui();
